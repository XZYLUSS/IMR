"""Exact constructions and transports. TRUSTED bank data only; see grading.py for responses."""
from __future__ import annotations
import json
import sympy as s

VERSION = '2.0.0'
KINDS = ('QD', 'LG', 'AN', 'AM', 'BV', 'TN')
z = s.symbols('z0:3')
q = s.symbols('q0:2'); v = s.symbols('v0:2'); a = s.symbols('a0:2')
j = s.symbols('j0:2'); u4 = s.symbols('s0:2')
JETS = q + v + a + j + u4
LOCALS = {str(x): x for x in z + JETS}
t = s.Symbol('t', real=True)
LOCALS['t'] = t

def expr(x):
    value = s.sympify(x, locals=LOCALS)
    return value.xreplace({symbol: LOCALS[str(symbol)] for symbol in value.free_symbols if str(symbol) in LOCALS})

def mat(x):
    if isinstance(x, s.MatrixBase): return x.applyfunc(expr)
    return s.Matrix([[expr(entry) for entry in row] for row in x])

def clean(x):
    if isinstance(x, s.MatrixBase): return x.applyfunc(s.cancel)
    return s.cancel(x)

def pack(x):
    if isinstance(x, s.MatrixBase): return [[str(clean(y)) for y in row] for row in x.tolist()]
    if isinstance(x, s.Basic): return str(clean(x))
    if isinstance(x, dict): return {k: pack(vv) for k, vv in x.items()}
    if isinstance(x, (tuple, list)): return [pack(vv) for vv in x]
    return x

def dumps(x): return json.dumps(pack(x), sort_keys=True, indent=2) + '\n'

def same(x, y):
    if isinstance(x, dict): return isinstance(y, dict) and x.keys() == y.keys() and all(same(x[k], y[k]) for k in x)
    if isinstance(x, (list, tuple)): return isinstance(y, (list, tuple)) and len(x) == len(y) and all(same(xx, yy) for xx, yy in zip(x,y))
    if isinstance(x, s.MatrixBase) or isinstance(y, s.MatrixBase):
        xx, yy = mat(x), mat(y)
        return xx.shape == yy.shape and all(s.simplify(aa-bb) == 0 for aa,bb in zip(xx,yy))
    return s.simplify(expr(x)-expr(y)) == 0

def vec(xs): return s.Matrix(xs)

def shear(n, i, k, c=1):
    out = s.eye(n); out[i,k] = c
    return out

def symplectic_J(n):
    m = n//2
    return s.zeros(m).row_join(s.eye(m)).col_join((-s.eye(m)).row_join(s.zeros(m)))

def fourier_coefficients(f):
    out = {}
    for term in s.Add.make_args(s.expand(f)):
        powers = term.as_powers_dict()
        key = tuple(int(powers.get(zz,0)) for zz in z)
        coeff = s.cancel(term / s.prod(zz**kk for zz,kk in zip(z,key)))
        assert not coeff.free_symbols.intersection(z)
        out[key] = out.get(key,0) + coeff
    return {key:s.simplify(value) for key,value in out.items() if value != 0}

def constant(f): return fourier_coefficients(f).get((0,0,0), s.Integer(0))

def D(f):
    return s.expand(sum(yy*s.diff(f,xx) for xx,yy in zip(q+v+a+j, v+a+j+u4)))

def jet_sub(C):
    return {xx:yy for block in (q,v,a,j,u4) for xx,yy in zip(block,C*vec(block))}

def solve(kind, data):
    if kind == 'QD':
        edges = [mat(e) for e in data['edges']]; n = edges[0].rows
        H = s.eye(n)
        for e in edges: H = e*H
        R = s.eye(n)-H
        return {'holonomy':clean(H), 'response':clean(R.inv()*mat(data['source'])), 'resolvent_det':R.det()}
    if kind == 'LG':
        A,C = mat(data['alpha']),mat(data['beta'])
        p, c = A.applyfunc(constant),C.applyfunc(constant)
        return {'periods':p, 'fluxes':c, 'pairing':constant((A.T*C)[0])}
    if kind == 'AN':
        cs=[]
        for k in range(data['order']+1):
            value=0
            for comp in data['components']:
                w,r,d = [expr(comp[key]) for key in ('weight','rate','shift')]
                poly=s.Poly(expr(comp['polynomial'])*(t+d)**k,t)
                value += w*sum(coeff*s.factorial(mon[0])/r**(mon[0]+1) for mon,coeff in poly.terms())/s.factorial(k)
            cs.append(s.cancel(value))
        return {'jet':vec(cs)}
    if kind == 'AM':
        K=mat(data['precision']); source=mat(data['source']); p=data['observed_dim']
        hidden=K[p:,p:]; coupling=K[:p,p:]
        return {'mean':clean((K.inv()*source)[:p,:]), 'precision':clean(K[:p,:p]-coupling*hidden.inv()*coupling.T), 'amplitude_squared':clean(expr(data['weight'])**2/hidden.det())}
    if kind == 'BV':
        L=expr(data['lagrangian'])
        R=vec([s.diff(L,aa) for aa in a])
        P=vec([s.diff(L,vv)-D(rr) for vv,rr in zip(v,R)])
        E=vec([s.diff(L,qq)-D(pp) for qq,pp in zip(q,P)])
        return {'euler':clean(E), 'momentum':clean(P), 'acceleration_momentum':clean(R)}
    if kind == 'TN':
        W=mat(data['probes']); J=symplectic_J(W.rows)
        vv=clean((W.T*J.T).inv()*mat(data['pairings_v']))
        uu=clean((W.T*J.T).inv()*mat(data['pairings_u']))
        Q=clean(W.T.inv()*mat(data['probe_gram'])*W.inv())
        return {'charge_v':vv, 'charge_u':uu, 'quadratic_form':Q, 'dsz':(vv.T*J*uu)[0]}
    raise ValueError(kind)

def transform_input(kind, data, par):
    if kind == 'QD':
        P=[mat(x) for x in par['frames']]; edges=[mat(e) for e in data['edges']]
        return {'edges':[clean(P[(i+1)%len(P)]*e*P[i].inv()) for i,e in enumerate(edges)], 'source':clean(P[0]*mat(data['source']))}
    if kind == 'LG':
        A=mat(par['matrix']); sub={z[i]:s.prod(z[k]**A[i,k] for k in range(3)) for i in range(3)}
        alpha=mat(data['alpha']).applyfunc(lambda f:s.expand(f.subs(sub,simultaneous=True)))
        beta=mat(data['beta']).applyfunc(lambda f:s.expand(f.subs(sub,simultaneous=True)))
        return {'alpha':clean(A.T*alpha), 'beta':clean(A.det()*A.inv()*beta)}
    if kind == 'AN':
        aa,bb=expr(par['scale']),expr(par['shift']); comps=[]
        for c in data['components']:
            comps.append({'weight':aa*expr(c['weight']), 'rate':aa*expr(c['rate']), 'shift':(expr(c['shift'])+bb)/aa, 'polynomial':expr(c['polynomial']).subs(t,aa*t)})
        return {'order':data['order'],'components':comps}
    if kind == 'AM':
        P,b=mat(par['matrix']),mat(par['offset']); p=data['observed_dim']; K=mat(data['precision']); src=mat(data['source'])
        B=s.diag(P.inv(),s.eye(K.rows-p)); d=(-P.inv()*b).col_join(s.zeros(K.rows-p,1))
        return {'observed_dim':p, 'precision':clean(B.T*K*B), 'source':clean(B.T*(src-K*d)), 'constant':clean(expr(data['constant'])+(d.T*K*d)[0]-2*(src.T*d)[0]), 'weight':expr(data['weight'])/abs(P.det())}
    if kind == 'BV':
        C=mat(par['matrix']); F=expr(par['boundary_function'])
        return {'lagrangian':s.expand(expr(data['lagrangian']).subs(jet_sub(C),simultaneous=True)+D(F))}
    if kind == 'TN':
        M=mat(par['matrix'])
        return {**data,'probes':clean(M*mat(data['probes']))}
    raise ValueError(kind)

def transport(kind, answer, par):
    if kind == 'QD':
        P=mat(par['frames'][0])
        return {'holonomy':clean(P*mat(answer['holonomy'])*P.inv()), 'response':clean(P*mat(answer['response'])), 'resolvent_det':expr(answer['resolvent_det'])}
    if kind == 'LG':
        A=mat(par['matrix']); det=A.det()
        return {'periods':clean(A.T*mat(answer['periods'])), 'fluxes':clean(det*A.inv()*mat(answer['fluxes'])), 'pairing':det*expr(answer['pairing'])}
    if kind == 'AN':
        aa,bb=expr(par['scale']),expr(par['shift']); c=mat(answer['jet'])
        return {'jet':vec([s.expand(aa**(-k)*sum(bb**(k-i)/s.factorial(k-i)*c[i] for i in range(k+1))) for k in range(c.rows)])}
    if kind == 'AM':
        P,b=mat(par['matrix']),mat(par['offset'])
        return {'mean':clean(P*mat(answer['mean'])+b), 'precision':clean(P.T.inv()*mat(answer['precision'])*P.inv()), 'amplitude_squared':expr(answer['amplitude_squared'])/P.det()**2}
    if kind == 'BV':
        C=mat(par['matrix']); F=expr(par['boundary_function']); sub=jet_sub(C)
        out={key:clean(C.T*mat(value).applyfunc(lambda f:s.expand(f.subs(sub,simultaneous=True)))) for key,value in answer.items()}
        out['momentum']+=vec([s.diff(F,qq) for qq in q]); out['acceleration_momentum']+=vec([s.diff(F,vv) for vv in v])
        return {key:clean(value) for key,value in out.items()}
    if kind == 'TN':
        M=mat(par['matrix'])
        return {'charge_v':clean(M*mat(answer['charge_v'])), 'charge_u':clean(M*mat(answer['charge_u'])), 'quadratic_form':clean(M.T.inv()*mat(answer['quadratic_form'])*M.inv()), 'dsz':expr(answer['dsz'])}
    raise ValueError(kind)

def inverse(kind, par):
    if kind=='QD': return {'frames':[mat(P).inv() for P in par['frames']]}
    if kind=='AN':
        aa,bb=expr(par['scale']),expr(par['shift']); return {'scale':1/aa,'shift':-bb/aa}
    M=mat(par['matrix']); out={'matrix':M.inv()}
    if kind=='AM': out['offset']=-M.inv()*mat(par['offset'])
    if kind=='BV': out['boundary_function']=-expr(par['boundary_function']).subs(jet_sub(M.inv()),simultaneous=True)
    return out

def compose(kind, first, second):
    """Parameters for applying first, THEN second; pullbacks reverse matrix order."""
    if kind=='QD': return {'frames':[mat(b)*mat(a) for a,b in zip(first['frames'],second['frames'])]}
    if kind=='AN': return {'scale':expr(first['scale'])*expr(second['scale']), 'shift':expr(first['shift'])+expr(first['scale'])*expr(second['shift'])}
    A,B=mat(first['matrix']),mat(second['matrix'])
    out={'matrix':A*B if kind in ('LG','BV') else B*A}
    if kind=='AM': out['offset']=B*mat(first['offset'])+mat(second['offset'])
    if kind=='BV': out['boundary_function']=expr(first['boundary_function']).subs(jet_sub(B),simultaneous=True)+expr(second['boundary_function'])
    return out

def make_instance(kind, index):
    k=index
    if kind=='QD':
        n=3+(k==4); count=3+(k%2); edges=[]
        for i in range(count):
            diag=s.diag(*[s.Rational(2+i+j+k,5+i+j+k) for j in range(n)])
            edges.append(shear(n,i%n,(i+1)%n,1)*diag*shear(n,(i+1)%n,(i+2)%n,-1))
        data={'edges':edges,'source':vec([(-1)**i*(i+k) for i in range(n)])}
        first={'frames':[shear(n,i%n,(i+1)%n,k)*s.diag(*([2]+[1]*(n-1))) for i in range(count)]}
        second={'frames':[shear(n,(i+1)%n,i%n,1)*s.diag(*([1]*(n-1)+[3])) for i in range(count)]}
    elif kind=='LG':
        modes=[vec([1,k,0]),vec([0,1,1]),vec([1,0,1]),vec([1,-1,k])][:3+(k%2)]
        waves=[(s.prod(zz**kk for zz,kk in zip(z,mode))+1)**2/s.prod(zz**kk for zz,kk in zip(z,mode)) for mode in modes]
        alpha=sum(((i+1)*wave*mode for i,(wave,mode) in enumerate(zip(waves,modes))),s.zeros(3,1))
        beta=sum(((i+k)*waves[i]*waves[(i+1)%len(modes)]*modes[i].cross(modes[(i+1)%len(modes)]) for i in range(len(modes))),s.zeros(3,1))
        # A closed constant component avoids a degenerate top pairing in all instances.
        beta+=vec([k+1,2*k+1,3*k+2])
        data={'alpha':alpha,'beta':beta}
        first={'matrix':s.Matrix([[1,1,0],[0,1,1],[0,0,1]])}
        second={'matrix':s.Matrix([[-1,0,0],[1,1,0],[0,k,1]])}
    elif kind=='AN':
        data={'order':3+(k%3),'components':[{'weight':s.Rational(k+i, i+1), 'rate':s.Rational(k+i+1,2), 'shift':s.Rational(i+k-1,2), 'polynomial':1+(i+1)*t+(k+i)*t**2} for i in range(1,3+(k==4))]}
        first={'scale':s.Integer(2),'shift':s.Integer(1)}
        second={'scale':s.Rational(3,2),'shift':s.Integer(k+1)}
    elif kind=='AM':
        p=2+(k==4); h=2+(k==3); n=p+h
        T=s.eye(n)
        for row in range(n):
            for col in range(row+1,n): T[row,col]=(-1)**(row+col)*(k+row+col)%4-1
        K=T.T*s.diag(*range(k+1,k+n+1))*T; mu=vec([s.Rational(i-k,2) for i in range(n)]); src=K*mu
        data={'observed_dim':p,'precision':K,'source':src,'constant':(mu.T*K*mu)[0],'weight':s.Rational(k+1,2)}
        first={'matrix':shear(p,0,1,1)*s.diag(2,*([1]*(p-1))),'offset':vec(list(range(1,p+1)))}
        second={'matrix':shear(p,1,0,k)*s.diag(*([1]*(p-1)),3),'offset':vec([(-1)**i for i in range(p)])}
    elif kind=='BV':
        H=s.Matrix([[k+2,1],[1,k+3]]); B=s.Matrix([[q[0]+k,q[1]],[q[0]-q[1],k*q[0]]])
        M=s.Matrix([[1+q[0]**2,q[0]*q[1]],[q[0]*q[1],2+q[1]**2]])
        V=(q[0]**2+k*q[1]**2)/2+(q[0]+q[1])**4/4
        L=(vec(a).T*H*vec(a))[0]/2+(vec(v).T*M*vec(v))[0]/2+(vec(a).T*B*vec(v))[0]-V
        data={'lagrangian':s.expand(L)}
        first={'matrix':s.Matrix([[1,1],[0,1]]),'boundary_function':k*q[0]*v[1]+q[1]*v[0]**2/2}
        second={'matrix':s.Matrix([[1,0],[k,1]]),'boundary_function':q[0]**2*v[0]+q[1]*v[1]}
    elif kind=='TN':
        n=4; J=symplectic_J(n); W=shear(n,0,2,k)*shear(n,3,1,1)*shear(n,1,0,-1)*shear(n,2,3,2)
        vv=vec([k,2,1,-k-1]); uu=vec([1,-k,3,k+2]); T=shear(n,0,1,k)*shear(n,2,3,1)*shear(n,1,3,1)
        Q=T.T*s.diag(k+1,2,3,4)*T
        data={'probes':W,'pairings_v':W.T*J.T*vv,'pairings_u':W.T*J.T*uu,'probe_gram':W.T*Q*W}
        B=s.Matrix([[1,k],[k,0]]); C=s.Matrix([[0,1],[1,k]])
        first={'matrix':s.eye(2).row_join(B).col_join(s.zeros(2).row_join(s.eye(2)))}
        second={'matrix':s.eye(2).row_join(s.zeros(2)).col_join(C.row_join(s.eye(2)))}
    else: raise ValueError(kind)
    return {'id':f'IMR-H2-{kind}-{k:03}', 'construction_cluster':kind, 'instance_index':k, 'input':pack(data), 'T1':pack(first), 'T2':pack(second)}

def all_instances(): return [make_instance(kind,k) for kind in KINDS for k in range(1,5)]

def answer_schema(answer):
    return {key:{'shape':list(value.shape) if isinstance(value,s.MatrixBase) else [], 'entry_type':'rational polynomial in q0,q1,v0,v1,a0,a1,j0,j1,s0,s1' if key in ('euler','momentum','acceleration_momentum') else 'exact rational'} for key,value in answer.items()}

def prompt(kind,data,paraphrase=False):
    descriptions={
      'QD': 'A directed cycle has edges E_i from vertex i to i+1 modulo the edge count, acting on column vectors. Set H=E_(k-1)...E_0. A stationary driven vector obeys x=H*x+source. Compute holonomy H, response x, and det(I-H). Matrix multiplication order matters.',
      'LG': 'On the oriented torus R^3/(2*pi Z)^3, write z_j=exp(i*x_j). The input gives coefficients of alpha=sum A_j dx_j and beta=C_0 dx_1 wedge dx_2 + C_1 dx_2 wedge dx_0 + C_2 dx_0 wedge dx_1. These forms are real and closed. Compute the period vector p (integrals on positively oriented coordinate circles divided by 2*pi), the flux vector c (integrals on complementary coordinate 2-tori with the displayed orientations divided by (2*pi)^2), and r=integral(alpha wedge beta)/(2*pi)^3. Use the displayed coordinate orientation. Return periods, fluxes, pairing.',
      'AN': 'For n tending to positive infinity on x>=0, f_n(x)=n*sum_i weight_i*exp(-rate_i*(n*x-shift_i))*P_i(n*x-shift_i)*1_{n*x>=shift_i}; polynomial encodes P_i(t). For every smooth compactly supported test function phi on R, find c_0,...,c_m such that integral_0^infinity f_n(x)*phi(x) dx=sum_{k=0}^m c_k*n^(-k)*phi^(k)(0)+O(n^(-m-1)), where m=order. Return jet as a column. The coefficients multiply derivatives of phi, with no additional factorial or distributional sign.',
      'AM': 'Consider the positive finite-dimensional Gaussian density weight*exp[-(x^T precision x-2 source^T x+constant)/2] dx. The first observed_dim coordinates are z, the remaining h coordinates are u. Integrating over u in R^h gives (2*pi)^(h/2)*a*exp[-(z-mean)^T S (z-mean)/2] dz, with a>0. Return mean, precision=S, amplitude_squared=a^2, including the Lebesgue measure normalization. This is a finite-dimensional measure calculation.',
      'BV': 'For two real coordinates q0,q1 let v=Dq, a=Dv, j=Da, s=Dj, where D is total time differentiation. The input is L(q,v,a). Determine the polynomial column vectors E,P,R in the exact signed identity delta L=E^T delta q+D(P^T delta q+R^T delta v). Return euler=E, momentum=P, acceleration_momentum=R. Use exactly q0,q1,v0,v1,a0,a1,j0,j1,s0,s1 as polynomial variables. Endpoints and variations are unrestricted; boundary terms must be retained.',
      'TN': 'On Q^4 in coordinate order (electric_1,electric_2,magnetic_1,magnetic_2), fix J=[[0,I_2],[-I_2,0]] and Omega(v,w)=v^T J w. Columns of probes are w_i. Data pairings_v and pairings_u have entries Omega(v,w_i), Omega(u,w_i). The symmetric matrix probe_gram has entries w_i^T Q w_j for an unknown positive quadratic form Q. Reconstruct charge_v, charge_u, quadratic_form=Q, and dsz=Omega(v,u). Keep both the pairing convention and covariance of Q.'}
    paraphrases={
      'QD': 'Starting at vertex zero, traverse the supplied cycle once, applying each edge to a column in traversal order. Edge i leads from i to i+1 modulo the number of edges. Find the resulting return map, the unique stationary column obtained when source is added after every circuit, and the determinant of identity minus the return map. Name these holonomy, response, and resolvent_det, respectively.',
      'LG': 'Use coordinates x0,x1,x2 of period 2*pi with positive volume dx0 wedge dx1 wedge dx2, and abbreviate exp(i*x_j) by z_j. The alpha column multiplies dx0,dx1,dx2; the beta column multiplies dx1 wedge dx2,dx2 wedge dx0,dx0 wedge dx1. Both forms are closed and real. Recover their normalized coordinate-cycle integrals (periods divided by 2*pi and complementary fluxes divided by (2*pi)^2), and the integral of alpha wedge beta divided by (2*pi)^3. Report columns periods and fluxes and scalar pairing; complementary cycles use the indicated ordered orientations.',
      'AN': 'Each component describes a thin profile on the half-line: n*weight*exp[-rate*(n*x-shift)] times polynomial(t) evaluated at t=n*x-shift, and zero for n*x<shift. Add all components. Integrate the result against any smooth compactly supported phi on R, over x from zero to infinity. Through order n^(-order), recover the column jet whose kth entry multiplies n^(-k)*phi^(k)(0), k starting at zero. Do not insert an extra factorial or a distributional sign into the output convention; the omitted term must be O(n^(-order-1)).',
      'AM': 'Partition x into its first observed_dim entries z and the remaining h entries u. Integrate weight*exp[-x^T precision x/2+source^T x-constant/2] over all u with ordinary Lebesgue measure. Express the surviving density against dz as (2*pi)^(h/2)*a*exp[-(z-mean)^T S (z-mean)/2], with positive a. Give mean, precision (meaning S), and amplitude_squared (meaning a^2). All normalization factors are part of this finite-dimensional problem.',
      'BV': 'Vary the displayed two-coordinate Lagrangian without imposing endpoint conditions. Consecutive time derivatives of q are denoted v,a,j,s, with component indices 0 and 1. Integrate by parts until delta L consists of an Euler coefficient times delta q and one total time derivative. In the convention delta L=euler^T delta q+D(momentum^T delta q+acceleration_momentum^T delta v), report all three polynomial columns, retaining every boundary contribution. The allowed variables are q0,q1,v0,v1,a0,a1,j0,j1,s0,s1.',
      'TN': 'Unknown columns v and u and a symmetric positive matrix Q are measured in the probe basis whose vectors are the columns w_i of probes. The supplied pairing columns are v^T J w_i and u^T J w_i; probe_gram contains w_i^T Q w_j. In the coordinate order (electric_1,electric_2,magnetic_1,magnetic_2), use J with blocks [[0,I_2],[-I_2,0]]. Recover v as charge_v, u as charge_u, Q as quadratic_form, and the signed pairing v^T J u as dsz.'}
    intro='Solve the following exact reconstruction problem.\n' if paraphrase else 'Compute the following exact mathematical quantities.\n'
    schema=answer_schema(solve(kind,data))
    return intro+(paraphrases if paraphrase else descriptions)[kind]+'\n\nInput:\n'+dumps(data)+'\nReturn only a JSON object with exactly the following keys and shapes. Scalars are exact rational strings (for example "-3/7"); matrices, including columns, are nested arrays of strings. BV entries may be rational polynomial strings using +, -, *, / by rational constants, ** with nonnegative integer powers, and parentheses. No decimal approximations.\n'+dumps(schema)
