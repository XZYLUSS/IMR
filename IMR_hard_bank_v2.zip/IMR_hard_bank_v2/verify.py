"""Read-only full bundle verification; optional machine-readable report output."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
from core import *
from certificates import require,certify
from freeze_manifest import included_files
from grading import grade
ROOT=Path(__file__).resolve().parent

def verify_manifest(root=ROOT):
    manifest=root/'MANIFEST.sha256'; records={}
    for line in manifest.read_text().splitlines():
        digest,name=line.split('  ',1)
        require(name not in records,'duplicate manifest member')
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe manifest path')
        require(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'hash mismatch '+name)
        records[name]=digest
    require(set(records)=={p.relative_to(root).as_posix() for p in included_files(root)},'manifest coverage')
    return len(records)

def verify_source():
    pin=json.loads((ROOT/'PROVENANCE.json').read_text())
    source=ROOT.parent/pin['source_relative_to_workspace']
    if not source.is_dir(): return {'status':'not_available_in_this_location','expected_manifest_sha256':pin['source_manifest_sha256']}
    manifest=source/'MANIFEST.sha256'
    require(hashlib.sha256(manifest.read_bytes()).hexdigest()==pin['source_manifest_sha256'],'original manifest changed')
    count=0
    for line in manifest.read_text().splitlines():
        h,name=line.split('  ',1);require(hashlib.sha256((source/name).read_bytes()).hexdigest()==h,'original file changed '+name);count+=1
    review=ROOT.parent/pin['review_archive']
    require(hashlib.sha256(review.read_bytes()).hexdigest()==pin['review_archive_sha256'],'review archive changed')
    return {'status':'verified_unchanged','manifest_entries':count,'manifest_sha256':pin['source_manifest_sha256'],'review_archive_unchanged':True}

def verify_exports():
    safe=json.loads((ROOT/'model_prompts.json').read_text());private=json.loads((ROOT/'presentations.json').read_text())
    require(set(safe)=={'schema_version','prompts'},'public top-level schema')
    pub={r['prompt_id']:r for r in safe['prompts']};priv={r['prompt_id']:r for r in private['presentations']}
    require(len(pub)==len(safe['prompts'])==120 and pub.keys()==priv.keys(),'120 unique public/private prompt IDs')
    for row in safe['prompts']:
        require(set(row)=={'prompt_id','prompt'},'unexpected public payload fields')
        record=priv[row['prompt_id']];kind=record['construction_cluster'];arm=record['arm'];data=record['input']
        require(row['prompt']==prompt(kind,data,arm=='paraphrase'),'public prompt not reproducible from input/schema')
        gold=solve(kind,data)
        require(same(pack(gold),record['gold']),'private presentation gold')
        require(grade(dumps(gold),gold)['correct'],'round-trip gold through safe response parser')
    flat=ROOT/'families_repo'/'all_files'; count=0
    for folder in sorted((ROOT/'families_repo').glob('IMR-H2-*')):
        for p in folder.iterdir():
            require((flat/p.name).read_bytes()==p.read_bytes(),'flat artifact byte mismatch');count+=1
        problem=json.loads((folder/(folder.name+'-problem.json')).read_text())
        require(problem['confirmatory_eligible'] is False and problem['calibration_status']=='not_run','premature confirmatory admission')
    require(count==len(list(flat.iterdir()))==72,'flat artifact count')
    return {'model_prompts':120,'exact_gold_parser_acceptances':120,'flat_byte_identical_artifacts':72}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--write-report',action='store_true');parser.add_argument('--skip-manifest',action='store_true');parser.add_argument('--skip-certificates',action='store_true');args=parser.parse_args()
    report={'bank_version':VERSION,'python':platform.python_version(),'sympy':s.__version__,'empirical_model_runs':0,'construction_clusters':6,'instances':24}
    report['source_preservation']=verify_source();print('Source preservation:',report['source_preservation']['status'],flush=True)
    report['exports']=verify_exports();print('Exports and 72 byte-identical copies verified',flush=True)
    suites=ET.parse(ROOT/'TEST_RESULTS.xml').getroot().findall('testsuite')
    test_counts={key:sum(int(suite.attrib.get(key,0)) for suite in suites) for key in ('tests','failures','errors','skipped')}
    require(test_counts['tests']>0 and test_counts['failures']==test_counts['errors']==test_counts['skipped']==0,'test report contains failures, errors, skips or no tests')
    report['test_report']=test_counts
    synthetic=json.loads((ROOT/'audit'/'SYNTHETIC_GRADER_CHECK.json').read_text())
    require(synthetic['model_runs']==0 and synthetic['fixtures']['all_gold']['correct']==120 and synthetic['fixtures']['copy_canonical']['correct']==48,'synthetic grader report')
    report['synthetic_grader_check']=synthetic
    if not args.skip_certificates:
        count=0
        for path in sorted((ROOT/'families_repo').glob('IMR-H2-*/*-certificate.sympy')):
            result=subprocess.run([sys.executable,str(path)],text=True,capture_output=True)
            require(result.returncode==0,result.stdout+result.stderr)
            print(result.stdout.strip(),flush=True);count+=1
        require(count==24,'certificate count');report['certificate_entrypoints_passed']=count
    if not args.skip_manifest: report['manifest_entries']=verify_manifest()
    report['status']='PASS'
    if args.write_report:
        require(args.skip_manifest,'write report before freezing manifest, using --skip-manifest')
        (ROOT/'VALIDATION.json').write_text(dumps(report))
    print(json.dumps(report,sort_keys=True,indent=2))
if __name__=='__main__': main()
