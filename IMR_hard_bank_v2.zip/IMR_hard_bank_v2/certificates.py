"""Replayable exact certificates, analytic hypotheses, and adversarial witnesses."""
import hashlib
import json
from pathlib import Path
import sympy as s
from core import *
from grading import grade

class CertificateFailure(AssertionError): pass

def require(condition, message):
    if not condition: raise CertificateFailure(message)

def check_equal(left,right,message): require(same(left,right),message)

def positive_definite(M):
    return M==M.T and all(M[:k,:k].det()>0 for k in range(1,M.rows+1))

def generic_answer(kind,gold):
    answer={}
    for key,value in gold.items():
        if isinstance(value,s.MatrixBase):
            if kind=='BV': answer[key]=s.Matrix(value.rows,value.cols,lambda i,j:s.Function(f'{key}_{i}_{j}')(*JETS))
            else: answer[key]=s.Matrix(value.rows,value.cols,lambda i,j:s.Symbol(f'{key}_{i}_{j}'))
        else: answer[key]=s.Symbol(key)
    return answer

def mathematical_checks(kind,data,gold):
    """Independent defining equations, beyond merely matching transported gold."""
    checks=[]
    if kind=='QD':
        edges=[mat(e) for e in data['edges']]; H=gold['holonomy']; x=gold['response']; f=mat(data['source'])
        require(all(e.det()!=0 for e in edges),'edge invertibility')
        require((s.eye(H.rows)-H).det()!=0,'resolvent invertibility')
        check_equal(gold['resolvent_det'],(s.eye(H.rows)-H).det(),'reported resolvent determinant')
        check_equal((s.eye(H.rows)-H)*x,f,'driven equation')
        # Propagate a generic vector through each edge to verify ordered holonomy.
        vv=vec(s.symbols(f'b0:{H.rows}')); end=vv
        for edge in edges: end=edge*end
        check_equal(H*vv,end,'ordered graph propagation')
        checks=['invertible edges','nonresonant resolvent','ordered graph propagation','driven equation']
    elif kind=='LG':
        A,C=mat(data['alpha']),mat(data['beta'])
        deriv=lambda f,i:s.I*z[i]*s.diff(f,z[i])
        for i in range(3):
            for jj in range(i+1,3): check_equal(deriv(A[jj],i),deriv(A[i],jj),'closed one-form')
        check_equal(sum(deriv(C[i],i) for i in range(3)),0,'closed two-form')
        for f in list(A)+list(C):
            cf=fourier_coefficients(f)
            for k,c in cf.items(): check_equal(c,s.conjugate(cf.get(tuple(-kk for kk in k),0)),'reality')
        alpha_coeff=[fourier_coefficients(f) for f in A]; beta_coeff=[fourier_coefficients(f) for f in C]
        check_equal(gold['periods'],vec([cf.get((0,0,0),0) for cf in alpha_coeff]),'reported periods')
        check_equal(gold['fluxes'],vec([cf.get((0,0,0),0) for cf in beta_coeff]),'reported fluxes')
        modes=set().union(*(set(cf) for cf in alpha_coeff+beta_coeff))
        for mode in modes-{(0,0,0)}:
            k=vec(mode); norm=(k.T*k)[0]
            aa=vec([cf.get(mode,0) for cf in alpha_coeff]); cc=vec([cf.get(mode,0) for cf in beta_coeff])
            phi=(k.T*aa)[0]/(s.I*norm)
            eta=s.I*k.cross(cc)/norm
            check_equal(s.I*k*phi,aa,'explicit exact primitive for alpha mode')
            check_equal(s.I*k.cross(eta),cc,'explicit exact primitive for beta mode')
        check_equal(gold['pairing'],(gold['periods'].T*gold['fluxes'])[0],'cohomological pairing')
        checks=['closed forms','real Fourier coefficients','modewise exact primitives','constant terms','cohomological pairing']
    elif kind=='AN':
        require(isinstance(data['order'],int) and 0<=data['order']<=8,'jet order')
        bound=0; m=data['order']; h=s.Symbol('h'); generating=0
        # Positive integer moments obey I_0=1/r and I_j=j*I_(j-1)/r by integration by parts.
        for comp in data['components']:
            w,r,d=[expr(comp[key]) for key in ('weight','rate','shift')]
            require(r>0 and d>=0,'positive decay and nonnegative support shift')
            P=s.Poly(expr(comp['polynomial']),t)
            require(P.domain.is_QQ or P.domain.is_ZZ,'rational polynomial')
            generating+=w*s.exp(d*h)*sum(coeff*s.factorial(mon[0])/(r-h)**(mon[0]+1) for mon,coeff in P.terms())
            rvar=s.Symbol('r',positive=True)
            for power in range(m+P.degree()+2):
                I=s.factorial(power)/rvar**(power+1)
                if power==0: check_equal(I,1/rvar,'moment base')
                else: check_equal(I,power/rvar*s.factorial(power-1)/rvar**power,'moment recurrence')
                # Construct and differentiate an antiderivative, not just the recurrence.
                anti=-s.exp(-rvar*t)*sum(s.factorial(power)/s.factorial(power-h)*t**(power-h)/rvar**(h+1) for h in range(power+1))
                check_equal(s.diff(anti,t),s.exp(-rvar*t)*t**power,'moment antiderivative')
            absP=sum(abs(c)*t**mon[0] for mon,c in P.terms())
            poly=s.Poly(absP*(t+d)**(m+1),t)
            bound+=abs(w)*sum(c*s.factorial(mon[0])/r**(mon[0]+1) for mon,c in poly.terms())/s.factorial(m+1)
        require(bound>0,'finite positive Taylor remainder constant')
        derivative=generating
        for degree in range(m+1):
            check_equal(gold['jet'][degree],derivative.subs(h,0)/s.factorial(degree),'independent exponential moment generating function')
            derivative=s.diff(derivative,h)
        checks=['positive decay','support tracked','factorial moment antiderivatives','independent exponential moment generating function','Taylor remainder bound R='+str(bound)]
    elif kind=='AM':
        K=mat(data['precision']); src=mat(data['source']); mu=K.inv()*src; p=data['observed_dim']
        require(positive_definite(K),'full precision SPD')
        require(expr(data['weight'])>0,'positive density weight')
        check_equal(expr(data['constant']),(src.T*mu)[0],'zero completed-square constant')
        check_equal(gold['mean'],mu[:p,:],'reported marginal mean')
        require(positive_definite(gold['precision']),'Schur complement SPD')
        check_equal(K.det(),K[p:,p:].det()*gold['precision'].det(),'Schur determinant')
        xx=vec(s.symbols(f'x0:{K.rows}')); centered=xx-mu
        hidden=centered[p:,:]+K[p:,p:].inv()*K[p:,:p]*centered[:p,:]
        original=(xx.T*K*xx)[0]-2*(src.T*xx)[0]+expr(data['constant'])
        square=(centered[:p,:].T*gold['precision']*centered[:p,:])[0]+(hidden.T*K[p:,p:]*hidden)[0]
        check_equal(original,square,'completed-square polynomial identity')
        check_equal(gold['amplitude_squared']*K[p:,p:].det(),expr(data['weight'])**2,'marginal normalization')
        checks=['Sylvester SPD','completed-square identity','Schur determinant','Lebesgue Gaussian normalization (positive root)']
    elif kind=='BV':
        L=expr(data['lagrangian']); h=s.symbols('h0:2'); h1=s.symbols('h10:12'); h2=s.symbols('h20:22')
        delta=sum(s.diff(L,x)*hh for block,hblock in ((q,h),(v,h1),(a,h2)) for x,hh in zip(block,hblock))
        E,P,R=[gold[key] for key in ('euler','momentum','acceleration_momentum')]
        boundary=sum(P[i]*h[i]+R[i]*h1[i] for i in range(2))
        total=D(boundary)+sum(s.diff(boundary,h[i])*h1[i]+s.diff(boundary,h1[i])*h2[i] for i in range(2))
        check_equal(delta,sum(E[i]*h[i] for i in range(2))+total,'signed off-shell first variation')
        require(s.Poly(L,*JETS).total_degree()<=8,'polynomial degree contract')
        checks=['off-shell first-variation polynomial identity','both boundary coefficients retained']
    elif kind=='TN':
        W=mat(data['probes']); J=symplectic_J(W.rows); vv,uu=gold['charge_v'],gold['charge_u']; Q=gold['quadratic_form']
        require(W.det()!=0,'probe basis invertible')
        check_equal(W.T*J.T*vv,mat(data['pairings_v']),'first probe data')
        check_equal(W.T*J.T*uu,mat(data['pairings_u']),'second probe data')
        check_equal(W.T*Q*W,mat(data['probe_gram']),'quadratic probe data')
        check_equal(gold['dsz'],(vv.T*J*uu)[0],'reported DSZ pairing')
        require(positive_definite(Q),'reconstructed form SPD')
        require(all(x.is_Integer for x in list(vv)+list(uu)),'integral charges')
        checks=['invertible probes','both symplectic probe equations','quadratic probe equation','SPD','integral charges']
    return checks

def domain_checks(kind,par):
    if kind=='QD': require(all(mat(P).det()!=0 for P in par['frames']),'invertible vertex frames')
    elif kind=='LG':
        M=mat(par['matrix']);require(abs(M.det())==1 and all(x.is_Integer for x in M),'integer torus automorphism')
    elif kind=='AN': require(expr(par['scale'])>0 and expr(par['shift'])>=0,'administered affine support transform')
    elif kind=='TN':
        M=mat(par['matrix']);J=symplectic_J(M.rows)
        require(all(x.is_Integer for x in M),'integral symplectic matrix')
        check_equal(M.T*J*M,J,'symplectic identity')
    else: require(mat(par['matrix']).det()!=0,'invertible frame matrix')
    if kind=='BV':
        F=expr(par['boundary_function']); require(F.free_symbols<=set(q+v),'boundary function depends only on q,v')
        check_equal(solve('BV',{'lagrangian':D(F)})['euler'],s.zeros(2,1),'total derivative has zero Euler derivative')

def nearby_control(kind,data,gold):
    other=json.loads(dumps(data))
    if kind=='QD':
        other['edges'][-1]=pack(2*mat(other['edges'][-1])); name='trace of holonomy'; old=s.trace(gold['holonomy']); new=2*old
    elif kind=='LG':
        A=mat(other['alpha']); c=gold['fluxes']; i=next(i for i in range(3) if c[i]!=0)
        delta=1
        while (gold['pairing']+delta*c[i])**2==gold['pairing']**2: delta+=1
        A[i]+=delta;other['alpha']=pack(A);name='squared oriented top pairing';old=gold['pairing']**2;new=(gold['pairing']+delta*c[i])**2
    elif kind=='AN':
        other['components'][0]['weight']=str(2*expr(other['components'][0]['weight']));name='zeroth moment';old=gold['jet'][0];new=solve(kind,other)['jet'][0]
    elif kind=='AM':
        other['weight']=str(2*expr(other['weight']));name='mass squared divided by (2*pi)^full_dim';old=gold['amplitude_squared']/gold['precision'].det();new=4*old
    elif kind=='BV':
        other['lagrangian']=str(expr(other['lagrangian'])+q[0]**6);name='maximum total degree of Euler vector';old=max(s.Poly(x,*JETS).total_degree() for x in gold['euler']);new=max(s.Poly(x,*JETS).total_degree() for x in solve(kind,other)['euler'])
    elif kind=='TN':
        J=symplectic_J(4);uu=gold['charge_u'];i=next(i for i in range(4) if (J*uu)[i]!=0);dv=s.zeros(4,1);dv[i]=1
        other['pairings_v']=pack(mat(other['pairings_v'])+mat(other['probes']).T*J.T*dv);name='DSZ pairing';old=gold['dsz'];new=old+(dv.T*J*uu)[0]
    require(old!=new,'non-equivalence witness must differ')
    mathematical_checks(kind,other,solve(kind,other))
    return {'input':other,'witness_name':name,'original':str(old),'perturbed':str(new),'equivalence_scope':'Only the transformation class explicitly defined for this construction; see DESIGN_AND_PROOFS.md.'}

def error_control(kind,gold,par):
    bad=transport(kind,gold,par)
    if kind=='QD':
        P=mat(par['frames'][0]);bad['holonomy']=P.inv()*gold['holonomy']*P
        name='inverse conjugation order'
    elif kind=='LG':
        bad['fluxes']=-bad['fluxes'];bad['pairing']=-bad['pairing'];name='omit orientation sign'
    elif kind=='AN':
        bad=transport(kind,gold,{'scale':par['scale'],'shift':0});name='drop boundary-layer support shift'
    elif kind=='AM': bad['amplitude_squared']=gold['amplitude_squared'];name='omit Jacobian determinant'
    elif kind=='BV':
        bad=transport(kind,gold,{**par,'boundary_function':0});name='drop total-derivative boundary terms'
    elif kind=='TN':
        M=mat(par['matrix']);bad['quadratic_form']=M*gold['quadratic_form']*M.T;name='use vector covariance for quadratic form'
    return name,bad

def certify(row, include_generic=True):
    kind=row['construction_cluster']; data=row['input']; gold=solve(kind,data)
    require(row['id'].startswith('IMR-H2-'+kind+'-'),'ID/cluster binding')
    checks=mathematical_checks(kind,data,gold); first,second=row['T1'],row['T2']; composite=compose(kind,first,second)
    records={};rejects=0
    generic=generic_answer(kind,gold) if include_generic else None
    for name,par in [('T1',first),('T2',second),('T2_after_T1',composite)]:
        domain_checks(kind,par)
        transformed=transform_input(kind,data,par); recomputed=solve(kind,transformed); transported=transport(kind,gold,par)
        check_equal(recomputed,transported,'independent transformed solution '+name)
        require(not same(gold,recomputed),'nonidentity gold transport '+name)
        check_equal(transform_input(kind,transformed,inverse(kind,par)),data,'input inverse '+name)
        if generic is not None:
            check_equal(transport(kind,transport(kind,generic,par),inverse(kind,par)),generic,'left inverse on formal arbitrary answers '+name)
            check_equal(transport(kind,transport(kind,generic,inverse(kind,par)),par),generic,'right inverse on formal arbitrary answers '+name)
        require(not grade(dumps(gold),recomputed)['correct'],'reject copied canonical answer '+name);rejects+=1
        mathematical_checks(kind,transformed,recomputed)
        records[name]={'parameters':pack(par),'input':pack(transformed),'gold':pack(recomputed)}
    check_equal(transform_input(kind,transform_input(kind,data,first),second),transform_input(kind,data,composite),'input composition')
    if generic is not None: check_equal(transport(kind,transport(kind,generic,first),second),transport(kind,generic,composite),'composition on formal arbitrary answers')
    reverse=transport(kind,transport(kind,gold,second),first); target=solve(kind,records['T2_after_T1']['input'])
    require(not grade(dumps(reverse),target)['correct'],'reject reversed composition');rejects+=1
    # T2 reverses torus orientation; use it for all module-specific controls.
    control_name,bad=error_control(kind,gold,second); second_gold=solve(kind,records['T2']['input'])
    require(not grade(dumps(bad),second_gold)['correct'],'reject '+control_name);rejects+=1
    nearby=nearby_control(kind,data,gold)
    return {'id':row['id'],'construction_cluster':kind,'status':'PASS','mathematical_checks':checks,'generic_transport_laws':bool(include_generic),'transformed_arms':3,'rejected_answer_controls':rejects,'module_error':control_name,'nearby_non_equivalence':nearby,'gold':pack(gold),'arms':records}

def replay_file(path,expected_sha256=None):
    path=Path(path);raw=path.read_bytes()
    if expected_sha256 is not None: require(hashlib.sha256(raw).hexdigest()==expected_sha256,'certificate input hash mismatch')
    row=json.loads(raw)['construction']
    result=certify(row)
    problem=json.loads(raw)
    check_equal(result['gold'],problem['gold'],'stored canonical gold')
    transforms=json.loads(path.with_name(path.name.replace('-problem.json','-transform.json')).read_text())
    for arm,record in result['arms'].items():
        require(dumps(record)==dumps(transforms['arms'][arm]),'stored arm differs '+arm)
    return result
