"""Strict exact-response parser. Never evaluate or sympify untrusted model text."""
import ast
import json
import re
from math import comb
import sympy as s
from core import JETS, same

RATIONAL = re.compile(r'-?\d+(?:/[1-9]\d*)?\Z')
VARIABLES = {str(x): x for x in JETS}
MAX_RESPONSE_BYTES = 262144
MAX_ENTRY_CHARS = 24000
MAX_AST_NODES = 3000

class InvalidResponse(ValueError): pass

def parse_entry(text, polynomial=False):
    if not isinstance(text,str) or len(text)>MAX_ENTRY_CHARS:
        raise InvalidResponse('Entries must be bounded exact strings')
    if not polynomial:
        if len(text)>160 or not RATIONAL.fullmatch(text): raise InvalidResponse('Expected exact rational string')
        numerator, _, denominator = text.partition('/')
        return s.Rational(int(numerator),int(denominator) if denominator else 1)
    try: tree=ast.parse(text,mode='eval')
    except (SyntaxError,ValueError,RecursionError) as exc: raise InvalidResponse('Invalid polynomial syntax') from exc
    if sum(1 for _ in ast.walk(tree))>MAX_AST_NODES: raise InvalidResponse('Expression is too large')
    def walk(node):
        if isinstance(node,ast.Constant) and type(node.value) is int and len(str(abs(node.value)))<=80:
            return s.Integer(node.value)
        if isinstance(node,ast.Name) and node.id in VARIABLES: return VARIABLES[node.id]
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            value=walk(node.operand); return value if isinstance(node.op,ast.UAdd) else -value
        if isinstance(node,ast.BinOp):
            left,right=walk(node.left),walk(node.right)
            lp,rp=s.Poly(left,*JETS),s.Poly(right,*JETS)
            if isinstance(node.op,ast.Mult) and (lp.total_degree()+rp.total_degree()>8 or len(lp.terms())*len(rp.terms())>1600):
                raise InvalidResponse('Product exceeds expansion bounds')
            if isinstance(node.op,ast.Pow) and right.is_Integer and 0<=right<=8:
                if lp.total_degree()*int(right)>8 or comb(len(lp.terms())+int(right)-1,int(right))>1600:
                    raise InvalidResponse('Power exceeds expansion bounds')
            if isinstance(node.op,ast.Add): value=left+right
            elif isinstance(node.op,ast.Sub): value=left-right
            elif isinstance(node.op,ast.Mult): value=left*right
            elif isinstance(node.op,ast.Div) and right.is_Rational and right!=0: value=left/right
            elif isinstance(node.op,ast.Pow) and right.is_Integer and 0<=right<=8: value=left**right
            else: raise InvalidResponse('Unsupported operation or denominator')
            poly=s.Poly(value,*JETS)
            if poly.total_degree()>8 or len(poly.terms())>800: raise InvalidResponse('Polynomial exceeds bounds')
            if any(len(str(abs(c.p)))>160 or len(str(c.q))>160 for c in poly.coeffs()): raise InvalidResponse('Coefficient exceeds bounds')
            return poly.as_expr()
        raise InvalidResponse('Only rational polynomial arithmetic is allowed')
    try: return walk(tree.body)
    except (RecursionError,OverflowError,s.PolynomialError) as exc: raise InvalidResponse('Invalid or excessive expression') from exc

def unique_object(pairs):
    out={}
    for key,value in pairs:
        if key in out: raise InvalidResponse('Duplicate JSON key')
        out[key]=value
    return out

def parse_response(raw, gold):
    if not isinstance(raw,str) or len(raw.encode('utf8'))>MAX_RESPONSE_BYTES: raise InvalidResponse('Response too large')
    try: data=json.loads(raw,object_pairs_hook=unique_object)
    except (ValueError,RecursionError) as exc: raise InvalidResponse('Expected one JSON object') from exc
    if not isinstance(data,dict) or data.keys()!=gold.keys(): raise InvalidResponse('Wrong answer keys')
    out={}
    for key,target in gold.items():
        polynomial=key in ('euler','momentum','acceleration_momentum')
        value=data[key]
        if isinstance(target,s.MatrixBase):
            if not isinstance(value,list) or len(value)!=target.rows or any(not isinstance(row,list) or len(row)!=target.cols for row in value): raise InvalidResponse('Wrong matrix shape')
            out[key]=s.Matrix([[parse_entry(entry,polynomial) for entry in row] for row in value])
        else: out[key]=parse_entry(value,polynomial)
    return out

def grade(raw,gold):
    try:
        answer=parse_response(raw,gold)
        return {'valid':True,'correct':same(answer,gold),'reason':'exact symbolic comparison'}
    except InvalidResponse as exc:
        return {'valid':False,'correct':False,'reason':str(exc)}
