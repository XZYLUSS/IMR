"""Offline grader for JSONL {prompt_id, response}; no model calls or raw-text eval."""
import argparse
import json
from pathlib import Path
from core import solve,dumps,transport,compose,all_instances
from grading import grade,parse_response,InvalidResponse
ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('responses',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    private=json.loads((ROOT/'presentations.json').read_text())['presentations'];index={r['prompt_id']:r for r in private};seen=set();results=[];answers={}
    for line_number,line in enumerate(args.responses.read_text().splitlines(),1):
        if not line.strip(): continue
        row=json.loads(line);pid=row['prompt_id']
        if pid not in index or pid in seen: raise ValueError(f'Unknown or duplicate prompt_id on line {line_number}')
        seen.add(pid);p=index[pid];gold=solve(p['construction_cluster'],p['input']);out=grade(row['response'],gold)
        results.append({'prompt_id':pid,'construction_cluster':p['construction_cluster'],**out})
        if out['valid']: answers[pid]=parse_response(row['response'],gold)
    # Consistency is separate from correctness and can hold for incorrect answers.
    consistency=[]
    from core import same
    for row in all_instances():
        fid=row['id'];kind=row['construction_cluster'];base=answers.get(fid+'/canonical')
        for arm in ('T1','T2','T2_after_T1'):
            other=answers.get(fid+'/'+arm)
            par=compose(kind,row['T1'],row['T2']) if arm=='T2_after_T1' else row[arm]
            if base is not None and other is not None: consistency.append({'instance_id':fid,'arm':arm,'consistent':same(transport(kind,base,par),other)})
    report={'responses':len(results),'correct':sum(r['correct'] for r in results),'invalid':sum(not r['valid'] for r in results),'missing_prompt_ids':sorted(set(index)-seen),'results':results,'transport_consistency':consistency,'statistical_unit_warning':'Six construction templates; 24 instances and their arms are dependent. No inferential p-value is produced.'}
    args.output.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(f'{report["correct"]}/{report["responses"]} correct; {report["invalid"]} invalid; {len(report["missing_prompt_ids"])} missing')
if __name__=='__main__':main()
