# Calibration and admission plan

## Current status

This version is a mathematically certified **candidate hard bank**, not an empirically validated solution to the reported accuracy ceiling. No model API calls, raw model responses, or accuracy measurements were produced in this task. All `confirmatory_eligible` flags remain false. The original bank is retained for calibration comparisons; the new bank has changed content and cannot be pooled with it as though the two versions measured an identical construct.

The 24 instances comprise four parameter instances in each of six construction templates. Their 120 presentations are dependent. Instances are not independent families for statistical purposes, and six templates do not establish broad coverage or support strong population-level confidence claims. Repeated sampling increases within-problem information, not the number of independent constructions.

## Fixed administration protocol

1. Freeze and record the bank manifest hash before any evaluation. Record the model identifier/version, date, reasoning settings, temperature, seed if supported, token budget, system prompt, tool policy, retries, and wall-time limit.
2. Send only an individual `prompt` from `model_prompts.json` to the model. Do not expose `presentations.json`, construction parameters, gold files, certificates, proofs, grader source, or the response to another arm in the same conversation. A model with workspace access would be able to read the answers; use isolated administration.
3. Use independently reset conversations for canonical, T1, T2, composite, and paraphrase arms; randomize their order using a recorded seed. Keep the exact payload and raw response. Blind the evaluator to model identity where practical. This bank is not a blind holdout for anyone who has inspected its gold files or construction code.
4. Treat the visible output schema as part of the protocol. Permit equivalent exact rational values and expanded/factored polynomials inside the safe parser's bounds. Do not silently repair a malformed answer or round decimals. Record invalid-format rate separately from mathematical wrong-answer rate. If a retry policy is desired, specify it before collecting data and retain every attempt.
5. For a tool-enabled condition, provide the same permitted symbolic tools and budgets to all models. Keep this distinct from the no-tool condition. The equations are exact and computationally tractable; tool-enabled models may still saturate.
6. Save UTF-8 JSONL records of the form `{"prompt_id":"IMR-H2-QD-001/canonical","response":"<raw JSON text>"}`. Metadata and prompts should be archived alongside the records. Run `grade_responses.py` to grade locally without model calls.

## Quantities to report

Report full-answer exact accuracy, invalid-format frequency, and per-key correctness if subsequently added to the grader. Keep canonical, each transformed arm, composite, and paraphrase results separate. Report all six template-level summaries as well as descriptive micro averages. Do not count 120 presentations as 120 independent observations.

Transport consistency is a separate outcome: compare the transformed response with τ applied to the model's canonical response whenever both are well formed. Incorrect answers can be transport-consistent. Therefore report correctness and consistency jointly, and report the denominator excluded because one response was invalid or missing. The supplied grader reports paired consistency without claiming it is correctness.

Include paired paraphrase agreement and accuracy to distinguish wording sensitivity from representation sensitivity. Inspect errors at the actual stage: ordered product versus resolvent (QD); periods versus cofactor/orientation (LG); support shift versus factorial convention (AN); Schur complement versus normalization (AM); Euler versus either boundary momentum (BV); probe inversion versus quadratic-form covariance (TN). The current exact grader gives whole-answer correctness; stage attribution requires inspecting the recorded component answers, not inferring it from a final score.

## Proposed design targets, not validated admission rules

Before running models, agree on target difficulty for the intended population. A possible exploratory target is canonical accuracy between 0.20 and 0.80 on at least some constructions, with room to distinguish canonical success from composite or boundary-sensitive failures. These thresholds are design choices, not statistical results or universal standards. A new ceiling should trigger a documented revision; pervasive failure should trigger checks for ambiguity, excessive arithmetic, output-format burden, or inadequate time budgets before being interpreted as conceptual difficulty.

Use a development panel for selection and a genuinely untouched evaluation set for confirmation. Generate and audit fresh instances or new constructions after selection; merely choosing another numeric seed does not establish independent construction coverage. Any expanded confirmatory set needs its own freeze, references, admissibility checks, gold checks and calibration. Do not use repeated resampling of these six templates to imply 24 independent conceptual mechanisms.

Admission requires independent mathematical/evaluator review, successful artifact replay, an agreed administration protocol, recorded model runs, and a prospectively fixed analysis plan. Promotion is a separate, explicit decision; these files do not alter the existing calibration bank's admissions.
