# Retained development diagnostics

Two issues were found and corrected before freezing this candidate bank.

1. The first torus reality certificate failed. An early matrix loader parsed string entries before applying the intended symbolic namespace, producing different SymPy symbol identities. Initial transport-only checks could therefore agree on a wrong interpretation. The loader now parses entries before constructing matrices and canonicalizes symbols; Fourier extraction has a hand-checked constant-term regression test, while the certificates check closure, reality and every nonzero-mode primitive. All later torus certificates passed. This is why transport agreement is not used as the sole correctness criterion.
2. The first full pytest run had 88 passes and one failure, retained in `INITIAL_TEST_RESULTS.txt`. A hand-written scalar fixture expected 26/27, while both direct SymPy integration and the factorial-moment formula returned 28/27. The correct integral is 2*(1/3+1/9+2/27)=28/27. Only that expected test value was corrected; the solver and generated golds did not change for this issue.

These diagnostics are development findings, not observed model errors. Final executed results are in the root validation and test reports.
