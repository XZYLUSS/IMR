"""End-to-end fixtures, explicitly not model-evaluation results."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from core import dumps

def main():
    rows=json.loads((ROOT/'presentations.json').read_text())['presentations']
    canonical={r['instance_id']:r['gold'] for r in rows if r['arm']=='canonical'}
    results={}
    with tempfile.TemporaryDirectory(prefix='imr-hard-grader-') as temp:
        temp=Path(temp)
        for fixture in ('all_gold','copy_canonical'):
            source=temp/(fixture+'.jsonl');output=temp/(fixture+'-scores.json')
            source.write_text(''.join(json.dumps({'prompt_id':r['prompt_id'],'response':dumps(r['gold'] if fixture=='all_gold' else canonical[r['instance_id']])})+'\n' for r in rows))
            proc=subprocess.run([sys.executable,str(ROOT/'grade_responses.py'),str(source),'--output',str(output)],capture_output=True,text=True,check=True)
            report=json.loads(output.read_text());expected=120 if fixture=='all_gold' else 48
            assert report['correct']==expected and report['responses']==120 and report['invalid']==0 and not report['missing_prompt_ids']
            consistent=sum(r['consistent'] for r in report['transport_consistency'])
            assert len(report['transport_consistency'])==72 and consistent==(72 if fixture=='all_gold' else 0)
            results[fixture]={'responses':120,'correct':report['correct'],'invalid':0,'transport_pairs':72,'consistent_pairs':consistent}
    report={'kind':'synthetic_end_to_end_grader_fixtures','model_runs':0,'fixtures':results}
    (ROOT/'audit'/'SYNTHETIC_GRADER_CHECK.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,sort_keys=True,indent=2))
if __name__=='__main__':main()
