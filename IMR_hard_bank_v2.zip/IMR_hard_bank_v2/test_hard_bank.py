import json
from pathlib import Path
import pytest
import sympy as s
from core import *
from certificates import CertificateFailure,certify,replay_file,nearby_control,mathematical_checks
from grading import InvalidResponse,parse_entry,grade
from verify import verify_exports,verify_manifest
from freeze_manifest import freeze
ROOT=Path(__file__).resolve().parent
ROWS=all_instances()

@pytest.mark.parametrize('row',ROWS,ids=lambda r:r['id'])
def test_certificate_laws_and_negative_controls(row):
    report=certify(row)
    assert report['generic_transport_laws'] and report['rejected_answer_controls']==5
    assert report['nearby_non_equivalence']['original']!=report['nearby_non_equivalence']['perturbed']

@pytest.mark.parametrize('row',ROWS,ids=lambda r:r['id'])
def test_generated_artifacts_match_construction(row):
    fid=row['id'];folder=ROOT/'families_repo'/fid
    problem=json.loads((folder/(fid+'-problem.json')).read_text())
    assert problem['construction']==row
    assert same(problem['gold'],pack(solve(row['construction_cluster'],row['input'])))
    assert problem['confirmatory_eligible'] is False
    transforms=json.loads((folder/(fid+'-transform.json')).read_text())
    for arm,par in [('T1',row['T1']),('T2',row['T2']),('T2_after_T1',compose(row['construction_cluster'],row['T1'],row['T2']))]:
        assert dumps(transforms['arms'][arm]['parameters'])==dumps(par)

@pytest.mark.parametrize('kind',KINDS)
def test_paraphrase_preserves_input_and_has_different_wording(kind):
    row=make_instance(kind,1)
    p1=prompt(kind,row['input']);p2=prompt(kind,row['input'],True)
    assert p1.split('Input:')[1]==p2.split('Input:')[1]
    assert p1.split('Input:')[0]!=p2.split('Input:')[0]

def test_fourier_constant_symbol_identity_regression():
    serialized={'alpha':[['(z0+1)**2/z0'],['0'],['0']],'beta':[['3'],['0'],['0']]}
    answer=solve('LG',serialized)
    assert answer=={'periods':vec([2,0,0]),'fluxes':vec([3,0,0]),'pairing':6}
    assert constant(z[0]+2+z[0]**-1)==2
    assert constant((z[0]+z[1])*(z[0]**-1+z[1]**-1))==2
    assert fourier_coefficients(mat(serialized['alpha'])[0])=={(1,0,0):1,(0,0,0):2,(-1,0,0):1}

def test_explicit_fourier_primitives_and_orientation():
    data={'alpha':vec([2+z[0]+1/z[0],3,0]),'beta':vec([5,0,7])}
    gold=solve('LG',data);mathematical_checks('LG',data,gold)
    T={'matrix':s.diag(-1,1,1)}
    assert solve('LG',transform_input('LG',data,T))['pairing']==-10

def test_analytic_moments_against_direct_symbolic_integration():
    data={'order':4,'components':[{'weight':2,'rate':3,'shift':s.Rational(1,2),'polynomial':1+t+t**2}]}
    gold=solve('AN',data)['jet']
    for k in range(5):
        direct=2*s.integrate(s.exp(-3*t)*(1+t+t**2)*(t+s.Rational(1,2))**k,(t,0,s.oo))/s.factorial(k)
        assert gold[k]==direct
    assert gold[0]==s.Rational(28,27)

def test_gaussian_marginal_hand_case():
    K=s.Matrix([[3,1],[1,2]]);mu=vec([2,-1]);src=K*mu
    data={'observed_dim':1,'precision':K,'source':src,'constant':(mu.T*K*mu)[0],'weight':3}
    gold=solve('AM',data)
    assert gold=={'mean':vec([2]),'precision':s.Matrix([[s.Rational(5,2)]]),'amplitude_squared':s.Rational(9,2)}
    y=transport('AM',gold,{'matrix':s.Matrix([[-2]]),'offset':vec([1])})
    assert y['mean']==vec([-3]) and y['amplitude_squared']==s.Rational(9,8)
    assert y['precision']==s.Matrix([[s.Rational(5,8)]])

def test_higher_derivative_boundary_hand_case():
    L=(a[0]**2+v[0]**2-q[0]**2)/2
    gold=solve('BV',{'lagrangian':L})
    assert gold=={'euler':vec([-q[0]-a[0]+u4[0],0]),'momentum':vec([v[0]-j[0],0]),'acceleration_momentum':vec([a[0],0])}
    F=q[0]*v[0]
    result=solve('BV',{'lagrangian':L+D(F)})
    assert result['euler']==gold['euler']
    assert result['momentum']==gold['momentum']+vec([v[0],0])
    assert result['acceleration_momentum']==gold['acceleration_momentum']+vec([q[0],0])

def test_symplectic_probe_sign_hand_case():
    J=symplectic_J(4);vv=vec([1,2,3,4]);uu=vec([4,3,2,1]);Q=s.diag(1,2,3,4)
    data={'probes':s.eye(4),'pairings_v':J.T*vv,'pairings_u':J.T*uu,'probe_gram':Q}
    gold=solve('TN',data)
    assert gold['charge_v']==vv and gold['charge_u']==uu and gold['quadratic_form']==Q and gold['dsz']==-20

def test_ordered_holonomy_hand_case():
    E0=s.Matrix([[1,1],[0,1]]);E1=s.diag(2,3)
    gold=solve('QD',{'edges':[E0,E1],'source':vec([1,1])})
    assert gold['holonomy']==s.Matrix([[2,2],[0,3]])
    assert gold['response']==vec([0,s.Rational(-1,2)]) and gold['resolvent_det']==2

@pytest.mark.parametrize('raw',["__import__('os').system('echo bad')",'q0.__class__','q0[0]','sin(q0)','1/q0','q0**-1','q0**9','True','1.0','1e100','q0**1000000','(q0+q1+v0+v1+a0+a1+j0+j1+s0+s1)**8','(1/0)','lambda: 1'])
def test_untrusted_polynomial_syntax_is_rejected(raw):
    with pytest.raises(InvalidResponse): parse_entry(raw,True)

@pytest.mark.parametrize('raw',['nan','inf','1.0','1/0','1/-2','1e-3','2+3','True'])
def test_rational_parser_rejects_invalid_forms(raw):
    with pytest.raises(InvalidResponse): parse_entry(raw)

def test_equivalent_polynomial_response_is_accepted():
    assert parse_entry('(q0+q1)**2-q0**2-q1**2',True)==2*q[0]*q[1]
    assert grade('{"x":"2/4"}',{'x':s.Rational(1,2)})['correct']

def test_schema_and_duplicate_keys_are_rejected():
    assert not grade('{"x":"1","x":"2"}',{'x':s.Integer(2)})['valid']
    assert not grade('{"x":1}',{'x':s.Integer(1)})['valid']
    assert not grade('{"x":["1","2"]}',{'x':vec([1,2])})['valid']
    assert not grade('{"x":"1","explanation":"hi"}',{'x':s.Integer(1)})['valid']

def test_canonical_answer_mutation_rejected():
    row=make_instance('QD',1);gold=solve('QD',row['input']);bad={**gold,'resolvent_det':gold['resolvent_det']+1}
    assert not grade(dumps(bad),gold)['correct']

MUTATIONS=[(kind,key) for kind in KINDS for key in solve(kind,make_instance(kind,1)['input'])]
@pytest.mark.parametrize('kind,key',MUTATIONS)
def test_independent_definitions_reject_each_corrupted_answer_field(kind,key):
    data=make_instance(kind,1)['input'];gold=solve(kind,data);bad=dict(gold)
    if isinstance(gold[key],s.MatrixBase):
        bad[key]=gold[key].copy();bad[key][0]+=1
    else: bad[key]=gold[key]+1
    with pytest.raises(CertificateFailure): mathematical_checks(kind,data,bad)

def test_bound_certificate_rejects_tampering(tmp_path):
    row=make_instance('QD',1);fid=row['id'];source=ROOT/'families_repo'/fid/(fid+'-problem.json')
    import hashlib
    digest=hashlib.sha256(source.read_bytes()).hexdigest();target=tmp_path/source.name;target.write_bytes(source.read_bytes()+b' ')
    with pytest.raises(CertificateFailure,match='hash mismatch'): replay_file(target,digest)

def test_manifest_detects_modification_and_extra_file(tmp_path):
    target=tmp_path/'data.json';target.write_text('{}');freeze(tmp_path);assert verify_manifest(tmp_path)==1
    target.write_text('{"modified":true}')
    with pytest.raises(CertificateFailure,match='hash mismatch'):verify_manifest(tmp_path)
    target.write_text('{}');(tmp_path/'extra.json').write_text('{}')
    with pytest.raises(CertificateFailure,match='coverage'):verify_manifest(tmp_path)

def test_gold_free_exports_and_flat_copies():
    assert verify_exports()['model_prompts']==120
