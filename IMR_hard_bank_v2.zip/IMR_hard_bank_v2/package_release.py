"""Package the already frozen bank and byte-check every archive member."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
from freeze_manifest import included_files
from verify import verify_manifest
ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT.parent/(ROOT.name+'.zip'));args=parser.parse_args()
    count=verify_manifest(ROOT);files=sorted(included_files(ROOT)+[ROOT/'MANIFEST.sha256'])
    with zipfile.ZipFile(args.output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in files:
            info=zipfile.ZipInfo(ROOT.name+'/'+path.relative_to(ROOT).as_posix(),date_time=(2026,10,17,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            archive.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(args.output) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist())==len(files)
        for path in files:
            assert archive.read(ROOT.name+'/'+path.relative_to(ROOT).as_posix())==path.read_bytes()
    digest=hashlib.sha256(args.output.read_bytes()).hexdigest()
    args.output.with_suffix(args.output.suffix+'.sha256').write_text(digest+'  '+args.output.name+'\n')
    print(json.dumps({'archive':str(args.output),'archive_sha256':digest,'byte_verified_members':len(files),'manifest_entries':count,'manifest_sha256':hashlib.sha256((ROOT/'MANIFEST.sha256').read_bytes()).hexdigest()},indent=2))
if __name__=='__main__':main()
