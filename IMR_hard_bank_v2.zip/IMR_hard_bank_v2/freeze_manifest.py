"""Freeze after materialization, tests, documentation, and validation have finished."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent
EXCLUDED_DIRS={'__pycache__','.pytest_cache','.git','.venv'}
def included_files(root=ROOT):
    return sorted(p for p in root.rglob('*') if p.is_file() and not p.is_symlink() and not EXCLUDED_DIRS.intersection(p.relative_to(root).parts) and p.name not in {'MANIFEST.sha256','.DS_Store'})
def freeze(root=ROOT):
    files=included_files(root)
    (root/'MANIFEST.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in files))
    print('Frozen',len(files),'files; manifest SHA256',hashlib.sha256((root/'MANIFEST.sha256').read_bytes()).hexdigest())
if __name__=='__main__': freeze()
