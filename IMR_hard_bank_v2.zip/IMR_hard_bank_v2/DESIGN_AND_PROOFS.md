# IMR hard bank v2: mathematical specification and certificates

Version 2.0.0, 17 October 2026. This is a separate research candidate bank. The repaired calibration bank and its admissions are unchanged. There are **six constructions, four explicit instances per construction, and five presentations per instance**. The 24 instances are nested within six template clusters; statistical independence is not established even between those clusters.

## 1. What is certified

Let X be a problem, Sol(X) its uniquely specified answer, T an admissible change of presentation, and τ_T the declared answer map. The central obligations are

\[
\mathrm{Sol}(TX)=\tau_T(\mathrm{Sol}(X)),\qquad
\tau_{T^{-1}}\tau_T=\mathrm{id}=\tau_T\tau_{T^{-1}},\qquad
\tau_{T_2T_1}=\tau_{T_2}\tau_{T_1}.
\]

The inverse and composition statements concern **all answers in the declared algebraic answer space**, including incorrect answers. They are stronger than checking a round trip on a gold answer. Scalar consistency relations between answer fields are imposed only on correct answers. For example, an arbitrary holonomy answer need not have its reported determinant equal to the determinant computed from its reported matrix.

`certificates.py` checks the identities on formal independent symbols, and on arbitrary formal functions of the jets for BV. It independently solves each transformed input, checks defining equations, rejects copied and incorrectly transported answers, and constructs inequivalent nearby problems. This document supplies the general algebraic proofs and the analytic lemmas. SymPy checks finite exact identities and hypotheses; it is **not** a formal proof assistant, nor does a successful run by itself prove an analytic convergence theorem. No numerical tolerance is used.

Each `.sympy` file binds the corresponding problem JSON by SHA-256 and replays the shared engine. It also checks the stored transformed inputs and answers. The certificate is portable **with the bundle**, not as an isolated file. `MANIFEST.sha256` binds the shared code, proofs, and generated artifacts; cryptographic integrity does not constitute independent mathematical peer review.

Composition in filenames means T1 first, T2 second. For pullbacks, the coordinate matrices consequently multiply in the opposite order to pushforward matrices. Every instance has a nonzero answer difference under T1, T2, and T2-after-T1, and a different answer under the reversed composition.

## 2. QD: ordered graph holonomy and driven response

**Domain.** A directed cycle has k invertible matrices E_i∈GL(d,Q), acting on columns from vertex i to i+1 modulo k. Define H=E_{k−1}⋯E_0 and assume det(I−H)≠0. The supplied driving column is f∈Q^d. The problem asks for

\[
(H,x,\Delta),\qquad x=(I-H)^{-1}f,\quad\Delta=\det(I-H).
\]

**Answer space.** Mat_d(Q)×Q^d×Q. The matrix in an arbitrary answer need not be invertible. The administered instances have d=3 or 4 and three or four edges.

**Input transformation and transport.** Choose invertible vertex frames P_i. Then

\[
E_i'=P_{i+1}E_iP_i^{-1},\quad f'=P_0f,
\quad\tau_P(H,x,\Delta)=(P_0HP_0^{-1},P_0x,\Delta).
\]

All intermediate P_i^{-1}P_i factors cancel in the cycle product. Also (I−P_0HP_0^{-1})P_0x=P_0(I−H)x=P_0f. Invertibility and determinant are preserved by conjugation, proving the solution law and uniqueness. Frame inverses give a two-sided inverse for every answer. Applying P and then Q is equivalent to vertex frames Q_iP_i, proving composition without assuming the answer is correct.

**Physical intuition and scope.** Components of a returning vector and the matrix representing parallel transport depend on the local frame; conjugacy invariants do not. The driven response forces the model to keep both covariance and ordered propagation. These are general linear graph transports, not a claim that the supplied rational matrices are unitary Wilson loops of a particular gauge theory. The gauge-theoretic comparison is the endpoint transformation law for Wilson lines [1, §2.1.3]; the exact finite-matrix proof above is sufficient here.

**Certificates and controls.** Replay checks edge determinants, the ordered action on an arbitrary column, the driven equation, and nonresonance. Replacing the final edge by twice itself changes tr(H), an invariant under the permitted frame transformations; the new problem is checked for admissibility. An inverse-conjugation error and reversed composition are rejected.

## 3. LG: Fourier forms, global periods, and orientation on T³

**Domain and notation.** Coordinates x_j have period 2π; z_j=e^{ix_j}. Orient the torus by dx_0∧dx_1∧dx_2. The input consists of finite Laurent-polynomial forms

\[
\alpha=\sum_{j=0}^2 A_j(z)dx_j,\qquad
\beta=C_0(z)dx_1\wedge dx_2+C_1(z)dx_2\wedge dx_0+C_2(z)dx_0\wedge dx_1.
\]

The coefficients are real on the torus, dα=dβ=0, and their Fourier coefficients are rational. The answer is (p,c,r)∈Q³×Q³×Q: normalized coordinate periods, complementary oriented fluxes, and (2π)^{-3}∫α∧β. All triples are allowed as candidate answers; correctness additionally implies r=p^Tc.

**Why constant coefficients give the global answer.** Write A(z)=Σ_k A_k z^k and C(z)=Σ_k C_k z^k. Closedness gives k×A_k=0 and k^TC_k=0. For each nonzero integer k set

\[
\phi_k=\frac{k^TA_k}{i|k|^2},\qquad
\eta_k=\frac{i\,k\times C_k}{|k|^2}.
\]

Then ikφ_k=A_k and ik×η_k=C_k. The second identity follows from k×(k×C_k)=k(k^TC_k)−|k|²C_k. Consequently α=A_0·dx+dφ and β=β(C_0)+dη, with globally periodic primitives given by finite sums. Exact terms have zero periods on closed cycles. Stokes' theorem also eliminates exact terms from the integral of α∧β because both forms are closed. Hence p=A_0, c=C_0 and r=A_0^TC_0. This explicit Fourier proof specializes de Rham cohomology and Stokes' theorem [2, chapters on differential forms, integration and de Rham cohomology]; the topology of torus cohomology is discussed in [3, Chapter 3]. No infinite Fourier-series convergence claim is needed.

**Transformations.** Pull back along x=Ay, A∈GL(3,Z), det A=±1. Substitute z_j=∏_ℓ w_ℓ^{A_{jℓ}}. The new one-form and two-form coefficient columns are A^T A_old(z(w)) and (det A)A^{-1}C_old(z(w)). Thus

\[
\tau_A(p,c,r)=(A^Tp,(\det A)A^{-1}c,(\det A)r).
\]

The cofactor law for two-forms follows by expanding the wedges of dx_i=Σ_j A_{ij}dy_j. The normalized integral changes by the degree det A of this oriented torus diffeomorphism. Since A^T is invertible, its action on frequencies sends zero only to zero, so the constant coefficients obey the same law directly. Inverse A^{-1} gives the inverse transport on arbitrary triples. Pullback first by A then by B gives coordinate map AB and τ_Bτ_A=τ_{AB}.

**Physical intuition.** Local exact fluctuations do not determine global fluxes. Periods transform as one-form components, complementary fluxes by the cofactor representation, and the top pairing remembers orientation. The task therefore combines local closure, global information and distinct tensor representations.

**Certificates and controls.** The engine checks closure, Fourier reality A_{−k}=conjugate(A_k), explicit primitives for every nonzero mode, constant coefficients, and the top pairing. T2 reverses orientation. Omitting that sign is rejected. Adding a suitable constant component to α changes r², which is invariant under the entire declared GL(3,Z) action, and witnesses non-equivalence. The chosen two-form inputs are closed because each nonconstant term is f(k·x)g(ℓ·x)(k·dx)∧(ℓ·dx); differentiation repeats k·dx or ℓ·dx.

## 4. AN: translated boundary layers and asymptotic jets

**Domain.** For x≥0 and n>0,

\[
f_n(x)=n\sum_i w_i e^{-r_i(nx-d_i)}P_i(nx-d_i)\mathbf1_{nx\ge d_i},
\quad r_i>0,\ d_i\ge0,
\]

where weights, rates, shifts and polynomial coefficients are rational. The test function φ is smooth and compactly supported on R. The required answer c∈Q^{m+1}, m between 3 and 5 in the bank, satisfies

\[
\int_0^\infty f_n(x)\phi(x)dx
=\sum_{k=0}^{m}c_kn^{-k}\phi^{(k)}(0)+O(n^{-m-1}).
\]

The answer multiplies derivatives of φ; it is not the coefficient convention for derivatives of the delta distribution. In that alternative convention the kth coefficient would carry (−1)^k.

**Derivation and rigorous remainder.** Substituting u=nx−d_i yields

\[
c_k=\frac1{k!}\sum_i w_i\int_0^\infty e^{-r_iu}P_i(u)(u+d_i)^kdu.
\]

Every integral reduces to ∫_0^∞e^{-ru}u^jdu=j!/r^{j+1}. For j=0 integrate directly; integration by parts gives the recurrence for j>0. Endpoint terms vanish because r>0. The certificate differentiates an explicit exponential-polynomial antiderivative for every required degree.

As a separate check of the assembled jet, write P_i(u)=Σ_ℓ p_{iℓ}u^ℓ and form

\[
G(h)=\sum_i w_i e^{d_i h}\sum_\ell\frac{p_{i\ell}\ell!}{(r_i-h)^{\ell+1}}.
\]

The coefficient of h^k is c_k, by expansion of the finite rational/exponential generating expression at h=0. The engine computes G^(k)(0)/k! and compares it with the independently assembled polynomial moments. This formal coefficient identity requires no extra exchange of infinite sums and integrals.

Taylor's theorem on the segment from 0 to (u+d_i)/n gives an absolute remainder bounded by

\[
\frac{\|\phi^{(m+1)}\|_\infty}{(m+1)!n^{m+1}}
\sum_i|w_i|\int_0^\infty e^{-r_iu}|P_i(u)|(u+d_i)^{m+1}du.
\]

Replacing each polynomial coefficient by its absolute value gives an explicit finite rational bound R, recorded in the certificate. This proves the stated O estimate without exchanging a nonuniform pointwise limit and integration. Laplace-integral asymptotics and remainder bounds provide the broader context [4, §2.3(i)–(ii)]; the proof here needs only the displayed Taylor bound and elementary moments.

**Transformations.** Extend the profiles by zero outside their stated support and define

\[
(T_{a,b}f)_n(x)=a f_n(ax-b/n),\qquad a>0,
\]

with b≥0 for administered forward maps. Component parameters become w'=aw, r'=ar, d'=(d+b)/a, P'(u)=P(au). Their asymptotic jets obey

\[
(\tau_{a,b}c)_k=a^{-k}\sum_{j=0}^{k}\frac{b^{k-j}}{(k-j)!}c_j.
\]

This follows by substituting x=(u+b/n)/a in the pairing, Taylor expanding the shifted test function, and collecting powers of 1/n. Equivalently it follows by the finite binomial expansion of the exact moments. The matrix is lower triangular with diagonal a^{-k}, hence invertible on **all** Q^{m+1}. Applying (a₁,b₁) then (a₂,b₂) gives (a₁a₂,b₁+a₁b₂); the inverse parameters are (1/a,−b/a). Direct multiplication of the finite triangular matrices proves both identities.

The inverse shift can be negative. It is an inverse from the transformed input back to its original admissible input; we do not claim b≥0 defines a group. For more general input maps require each resulting d'≥0. The answer map itself remains an everywhere-defined rational linear isomorphism for any rational b and a≠0 (positive a is needed for the stated input interpretation).

**Physical intuition and controls.** A layer of width 1/n can keep finite mass even when its pointwise limit vanishes. Its translated location is also O(1/n), so that translation mixes successive distributional moments. Ignoring the support shift is an actual asymptotic error. Mass c₀ is preserved by all admitted changes; doubling a component changes c₀ and proves the nearby problem is inequivalent.

## 5. AM: marginal Gaussian measures and nontrivial Jacobians

**Scope.** AM retains a legacy mnemonic for the measure-related slot. This is an exact finite-dimensional bosonic Gaussian calculation. It is **not** an axial-anomaly calculation, an infinite-dimensional determinant regularization, or a promotion of an L1 anomaly claim to L2. Its coverage differs from that of the original calibration bank.

**Domain.** Let x=(z,u)∈R^{p+h}, K symmetric positive definite over Q, j rational, w>0 rational and c=j^TK^{-1}j. Consider

\[
w\exp[-(x^TKx-2j^Tx+c)/2],dz,du.
\]

Put μ=K^{-1}j and partition K by observed/hidden coordinates. Completing the square gives

\[
x^TKx-2j^Tx+c=(z-\mu_z)^TS(z-\mu_z)
+\left[u-\mu_u+K_{uu}^{-1}K_{uz}(z-\mu_z)\right]^T
K_{uu}\left[u-\mu_u+K_{uu}^{-1}K_{uz}(z-\mu_z)\right],
\]

where S=K_zz−K_zu K_uu^{-1}K_uz. Integration over u therefore gives (2π)^{h/2}a exp[−(z−μ_z)^TS(z−μ_z)/2]dz, where a=w/√det K_uu. Return (μ_z,S,a²); the positive-root convention makes a² unambiguous.

For completeness, the one-dimensional Gaussian integral follows by squaring it and using polar coordinates: ∫R e^{-t²/2}dt=√(2π). Orthogonal diagonalization of a real SPD matrix and rescaling each coordinate gives ∫exp(−u^TK_uu u/2)du=(2π)^{h/2}/√det K_uu. Block completion of the square proves S positive definite and det K=det K_uu det S. These identities and conventional Gaussian marginalization are documented in [5, §§8.1.1–8.1.2, 9.1.5].

**Answer space.** Q^p×Mat_p(Q)×Q, allowing arbitrary candidate matrices and scalars. Correct answers have SPD S and a²>0. Rational output avoids numerical logs and square roots without discarding the positive amplitude.

**Transformation.** Push the observed density forward by y=Pz+b, P∈GL(p,Q), b∈Q^p. For the full input set B=diag(P^{-1},I_h) and d=(−P^{-1}b,0). Then

\[
K'=B^TKB,\quad j'=B^T(j-Kd),\quad c'=c+d^TKd-2j^Td,\quad w'=w/|\det P|.
\]

The resulting answer map is

\[
\tau_{P,b}(\mu,S,a^2)=(P\mu+b,P^{-T}SP^{-1},a^2/(\det P)^2).
\]

The determinant factor comes from dz=|det P|^{-1}dy. Composition is (P₂P₁,P₂b₁+b₂); the inverse is (P^{-1},−P^{-1}b). Substitution proves both on arbitrary candidate answers, independently of positivity. SPD and the zero completed-square constant are preserved on actual problems.

**Physical intuition and controls.** Integrating out hidden coordinates induces a Schur complement; changing observed coordinates changes both the quadratic exponent and the measure. A correct exponent with the old amplitude describes a different measure. The invariant a²/det S equals total mass squared divided by (2π)^{p+h}. Doubling w multiplies this invariant by four, proving non-equivalence. Certificates check positive principal minors, completion of the square as a polynomial identity, normalization and the determinant identity; the omitted-Jacobian answer is rejected.

## 6. BV: higher-derivative variation with both boundary momenta

**Domain.** Two component coordinates have formal jets q,v,a,j,s representing derivatives through fourth order. L(q,v,a) is a rational polynomial. Define D by the chain rule Dq=v, Dv=a, Da=j, Dj=s, extending to higher jets when necessary. For the expressions used here, derivatives through s suffice. The answer consists of polynomial columns

\[
R=L_a,\qquad P=L_v-DL_a,\qquad E=L_q-DL_v+D^2L_a.
\]

The exact off-shell identity is

\[
\delta L=E^T\delta q+D(P^T\delta q+R^T\delta v).
\]

It follows by applying the product rule first to L_a^Tδa and then to (L_v−DL_a)^Tδv. This also proves uniqueness of the displayed coefficients when the independent variation jets δq,δv,δa are compared. No boundary conditions are imposed. The physical importance of total derivatives, boundary terms and generating functions is discussed for canonical mechanics in [6, §4.4]; the higher-derivative identity used here is derived explicitly above.

**Answer space.** Three copies of Q[q0,q1,v0,v1,a0,a1,j0,j1,s0,s1]^2, restricted to degree at most eight for the benchmark's response contract. Gold degrees are lower. Linear substitutions preserve degree and the administered boundary shifts have degree at most two. Parser limits on expression length and expansion size are additional encoding limits, not a claim that every syntactic representation of a polynomial is accepted.

**Transformations.** Let q=CQ, with C∈GL(2,Q), and add the total derivative of a cubic-or-lower F(Q,V):

\[
L'(Q,V,A)=L(CQ,CV,CA)+DF(Q,V).
\]

The output transport is

\[
E'=C^TE(CQ,CV,CA,CJ,CS),
\quad P'=C^TP(C\cdot)+F_Q,
\quad R'=C^TR(C\cdot)+F_V.
\]

Indeed variations transform by C, and δ(DF)=D(δF)=D(F_Q^TδQ+F_V^TδV). Therefore the Euler expression gains nothing while both boundary momenta can change. This proof applies to arbitrary polynomial candidate E,P,R as an algebraic map, regardless of whether they arise from a Lagrangian.

Applying (C₁,F₁) then (C₂,F₂) gives

\[
C_{12}=C_1C_2,\qquad F_{12}(Q,V)=F_1(C_2Q,C_2V)+F_2(Q,V).
\]

The inverse is (C^{-1},−F(C^{-1}Q,C^{-1}V)). The chain rule cancels the affine boundary shifts in both orders; the linear substitutions compose to the identity. This proves total inverse and composition laws, including for incorrect answers.

**Physical intuition and controls.** Equal bulk Euler equations alone do not specify the endpoint response. The task combines coupled fourth-order bulk equations with two distinct boundary covectors. A model dropping DF can reproduce transformed bulk equations while still failing the physically relevant boundary data. Certificates compare all coefficients of the off-shell variation, verify E(DF)=0, and recompute L' directly. Adding q0^6 raises the maximum degree of the Euler vector from three to five. Invertible linear jet substitutions preserve the highest nonzero degree and total derivatives have zero Euler derivative, so the perturbed L is inequivalent under the stated transformation class.

## 7. TN: symplectic reconstruction from probe data

**Domain.** On Q⁴ in the ordered coordinates (electric₁,electric₂,magnetic₁,magnetic₂), fix

\[
J=\begin{pmatrix}0&I_2\\-I_2&0\end{pmatrix},\qquad\Omega(v,w)=v^TJw.
\]

An invertible probe matrix W has columns w_i. The input supplies d_v=W^TJ^Tv, d_u=W^TJ^Tu, and G=W^TQW, with Q SPD. The exact answer is

\[
v=(W^TJ^T)^{-1}d_v,\quad u=(W^TJ^T)^{-1}d_u,\quad Q=W^{-T}GW^{-1},\quad\kappa=v^TJu.
\]

The administered instances have integral charges. The answer space is Q⁴×Q⁴×Mat_4(Q)×Q; arbitrary candidates need not satisfy the pairing relation or symmetry.

**Transformations.** For M∈Sp(4,Z), M^TJM=J, change W to MW and keep the measured columns and Gram matrix fixed. Then

\[
\tau_M(v,u,Q,\kappa)=(Mv,Mu,M^{-T}QM^{-1},\kappa).
\]

The defining probe equations are preserved because M^TJ^TM=J^T; the Gram matrix is preserved by the contragredient transformation of Q. Invertibility of W gives uniqueness. Applying M₁ then M₂ gives M₂M₁; M^{-1} supplies the inverse on arbitrary answers. The antisymmetric form and symplectic coordinate changes are standard in mechanics [6, §4.4]; electric/magnetic pairing terminology is motivated by charge lattices [1, §2.6]. The bank does not assert that all these lattice basis changes are realized dynamical dualities of a specified quantum field theory.

**Physical intuition and controls.** Probe measurements are invariant data, while the reconstructed vectors and the quadratic form transform differently. Recovering both charges and the metric exposes incorrect transposes and inverses that a single invariant scalar would conceal. Replay checks the symplectic identity, both measured pairing columns, the Gram matrix, positive definiteness, and integral charges. A charge perturbation changes κ, an invariant of every allowed symplectic change, proving non-equivalence. Treating Q as a vector-covariant matrix MQM^T is rejected.

## 8. What the hardening establishes—and what still needs measurement

Every problem asks for several coupled exact quantities. Relative to an identity-answer design, these constructions require ordered matrix products, global form periods and complementary fluxes, asymptotic jets with moving support, Schur complements with Jacobians, higher-derivative boundary data, or probe reconstruction in distinct tensor representations. Noncommuting composite arms require correct order. None of these facts proves a particular model will fail.

The executable adversarial audit rejects 72 copied canonical answers, 24 reversed-order answers, and 24 construction-specific erroneous answers. It also supplies 24 admissible nearby problems with exact invariant witnesses against the declared equivalence classes. These are engineered negative controls, **not model responses or observed accuracy measurements**. Scalar invariant fields are intentionally unchanged where the mathematics requires it; nonidentity applies to the full graded answer, not necessarily to each field.

The six constructions are explicit, reproducible design contributions. The references establish the underlying mathematical concepts; they do not report benchmark results for this bank. No claims of psychometric difficulty, saturation removal, discriminative power, or generalization are made without the calibration in `CALIBRATION.md`.

## References

1. David Tong, *Gauge Theory*, Cambridge lecture notes, especially §§2.1.3 and 2.6. [Author-hosted PDF](https://www.damtp.cam.ac.uk/user/tong/gaugetheory/gt.pdf).
2. John M. Lee, *Introduction to Smooth Manifolds*, 2nd ed., Graduate Texts in Mathematics 218, Springer, 2012 (publisher's publication year). [Publisher and DOI](https://link.springer.com/book/10.1007/978-1-4419-9982-5).
3. Allen Hatcher, *Algebraic Topology*, Cambridge University Press, 2002, Chapter 3. [Author's book page](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html).
4. NIST, *Digital Library of Mathematical Functions*, §2.3, “Integrals of a Real Variable,” especially (i) and (ii). [DLMF §2.3](https://dlmf.nist.gov/2.3).
5. Kaare Brandt Petersen and Michael Syskind Pedersen, *The Matrix Cookbook*, version 15 November 2012, §§8.1 and 9.1.5. [PDF](https://www.math.uwaterloo.ca/~hwolkowi/matrixcookbook.pdf).
6. David Tong, *Classical Dynamics*, Chapter 4, “The Hamiltonian Formalism,” especially §§4.3–4.4. [Author-hosted chapter](https://www.damtp.cam.ac.uk/user/tong/dynamics/dynhtml/S4.html).

All linked sources were checked during preparation. The deductions and instance certificates in this bundle are self-contained specializations rather than quotations from those references.
