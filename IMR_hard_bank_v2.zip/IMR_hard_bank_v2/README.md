# IMR hard bank v2

A separate hard-bank candidate containing **24 exact problem instances in six construction templates**, **120 gold-free prompts**, **72 nonidentity transformed answers**, and **24 replayable symbolic certificates**. The repaired 24-family calibration bank is preserved unchanged.

The hardening replaces invariant-answer-only tasks with coupled quantities whose components genuinely transform. It adds two noncommuting transformations and a composite presentation to every instance. Mathematical validity and resistance to copying a canonical answer are verified; reduced model saturation remains unmeasured.

| Cluster | Required calculation | Nonidentity answer transport |
|---|---|---|
| QD | Ordered graph holonomy and a driven fixed point | Matrix conjugation and vector covariance |
| LG | Periods, complementary fluxes and top pairing on a three-torus | Covector/cofactor actions and orientation |
| AN | Boundary-layer asymptotic jet through order 3–5 | Triangular mixing of moments under translation and scaling |
| AM | Marginal Gaussian precision, mean and amplitude | Affine mean, inverse congruence and measure Jacobian |
| BV | Coupled higher-derivative Euler expressions and both boundary momenta | Jet substitution, covector action and additive boundary shifts |
| TN | Charges and a positive quadratic form reconstructed from probes | Symplectic vector action and inverse congruence |

AM is a finite-dimensional measure construction. It does not certify a quantum anomaly. These are six templates with four instances each; they are not 24 independent statistical clusters.

Concrete T2 examples from instance 001 illustrate what changes:

| Quantity | Canonical | Transformed |
|---|---|---|
| LG period column | (16, −2, 18) | (−18, 16, 18) |
| LG top pairing | 492 | −492 |
| AN first-derivative coefficient | 2051/216 | 4099/324 |
| AM amplitude squared | 1/165 | 1/1485 |
| TN first charge column | (1, 2, 1, −2) | (1, 2, 3, 1) |

The AM change includes the factor 1/9 required by a coordinate map of determinant 3. The AN mass remains 128/27 while higher coefficients mix. Full inputs, transformed outputs and the exact transport laws are provided in the per-instance files and proof document.

## Read first

- `DESIGN_AND_PROOFS.md`: domains, answer spaces, exact maps, inverse/composition proofs, analytic remainder bounds, physical interpretation, certificate limits, and verified references.
- `CALIBRATION.md`: administration protocol, scoring distinctions, dependence structure and conditions for future empirical admission.
- `VALIDATION.json`, `TEST_RESULTS.txt`, and `CERTIFICATE_RESULTS.json`: executed checks and exact counts.
- `PROVENANCE.json`: original bank and review-archive hash pins.
- `DIFFICULTY_AUDIT.json`: structural dimensions and prompt lengths, with no invented difficulty scores.

## Model-facing and grader-facing files

**Give models only individual `prompt` strings from `model_prompts.json`.** Its 120 records contain only `prompt_id` and `prompt`, with no gold answers or transport solutions. Each instance has canonical, T1, T2, T2-after-T1 and paraphrase presentations.

`presentations.json`, all per-family problem/transform JSON files, `CERTIFICATE_RESULTS.json`, and the source code are evaluator material. They expose solutions or their derivation. An agent with unrestricted access to this folder does not constitute a blind test subject.

Each `families_repo/IMR-H2-<cluster>-<index>/` contains:

- `<ID>-problem.json`: input, construction parameters, canonical gold, output schema and research-only admission status.
- `<ID>-transform.json`: transformed inputs and golds, composed parameters, and an inequivalent nearby control with an invariant witness.
- `<ID>-certificate.sympy`: hash-bound certificate entrypoint importing the shared engine.

`families_repo/all_files/` holds 72 byte-identical flat copies. Both layouts require the bundle's shared Python files. No network access or model call is needed to replay certificates.

## Reproduce

Tested with Python 3.13.7, SymPy 1.14.0 and pytest 9.1.1. `requirements.txt` pins direct mathematical/test dependencies, `requirements-lock.txt` also pins the installed transitive packages, and `ENVIRONMENT.json` records the tested platform. Use your own Python environment if these are already installed. A fresh virtual environment can be prepared with:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python verify.py
.venv/bin/python -m pytest -q
```

`verify.py` checks the frozen manifest, exports, all 24 certificate entrypoints, 72 flat copies, and the original bank when its pinned workspace location is available. Outside that workspace it explicitly reports the source bank as unavailable, while still checking the self-contained new bundle. Each certificate can also be replayed individually with Python.

Regeneration deliberately precedes freezing:

```sh
python materialize_families.py
python -m pytest -q --junitxml=TEST_RESULTS.xml > TEST_RESULTS.txt 2>&1
python verify.py --skip-manifest --write-report
python freeze_manifest.py
python verify.py
```

The first command recomputes and certifies all golds, updates only the named v2 files, and synchronizes their flat copies. Unrecognized files in `all_files` cause an error. Finish any source or documentation edits before the final manifest freeze. The manifest excludes itself, Python/test caches, `.venv`, `.git` and `.DS_Store`.

After freezing, `python package_release.py --output /path/to/new-bank.zip` creates a new archive, checks every archived member against the local bytes, and writes a SHA-256 sidecar. It refuses to overwrite an existing archive. Use `requirements-lock.txt` when reproducing the recorded dependency versions.

For real collected responses:

```sh
python grade_responses.py responses.jsonl --output scores.json
```

The offline grader rejects malformed schemas, duplicate response keys, approximate numeric syntax, code calls, attributes, variable denominators, and excessive polynomial expansion. It compares exact values and reports transport consistency separately from correctness. Keep run outputs outside the frozen bundle, or freeze a separately versioned evaluation package containing them.

## Interpretation

The audit rejects 72 canonical-answer copies, 24 reversed-composition answers and 24 construction-specific wrong answers. Each of 24 nearby controls is admissible and has an exact invariant witnessing non-equivalence under its declared transformation class. These are constructed checks, not measured model failures. The 120-prompt answer and transport checks do not demonstrate that any current model avoids a ceiling. All instances remain `confirmatory_eligible: false` pending calibration and independent review.
