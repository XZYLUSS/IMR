"""Generate only the named v2 artifacts. Re-running synchronizes owned copies."""
from pathlib import Path
import hashlib
import json
from core import *
from certificates import certify

ROOT=Path(__file__).resolve().parent

def write_json(path,value): path.write_text(dumps(value),encoding='utf8')

def main():
    repo=ROOT/'families_repo';repo.mkdir(exist_ok=True)
    flat=repo/'all_files';flat.mkdir(exist_ok=True)
    rows=all_instances(); expected={row['id']+suffix for row in rows for suffix in ('-problem.json','-transform.json','-certificate.sympy')}
    unexpected={p.name for p in flat.iterdir()}-expected
    if unexpected: raise RuntimeError('Unowned files in all_files: '+str(sorted(unexpected)))
    prompts=[];presentations=[];results=[]
    for row in rows:
        result=certify(row);fid=row['id'];kind=row['construction_cluster'];folder=repo/fid;folder.mkdir(exist_ok=True)
        problem={'schema_version':'imr-hard-2','construction':row,'gold':result['gold'],'answer_schema':answer_schema(solve(kind,row['input'])),'confirmatory_eligible':False,'calibration_status':'not_run','construction_cluster':kind}
        problem_path=folder/(fid+'-problem.json');write_json(problem_path,problem)
        transforms={'schema_version':'imr-hard-2','id':fid,'arms':result['arms'],'nearby_non_equivalence_control':result['nearby_non_equivalence'],'composition_order':'T1 first, then T2','scope_document':'DESIGN_AND_PROOFS.md'}
        write_json(folder/(fid+'-transform.json'),transforms)
        digest=hashlib.sha256(problem_path.read_bytes()).hexdigest()
        certificate='''# Bundle-relative certificate: exact symbolic replay, no network or model calls.
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
ROOT = next(parent for parent in HERE.parents if (parent / "certificates.py").is_file())
sys.path.insert(0, str(ROOT))
from certificates import replay_file
result = replay_file(HERE / %r, %r)
print(result["id"], result["status"], "formal inverses/composition and independent solution identities verified")
'''%(problem_path.name,digest)
        (folder/(fid+'-certificate.sympy')).write_text(certificate,encoding='utf8')
        for suffix in ('-problem.json','-transform.json','-certificate.sympy'):
            p=folder/(fid+suffix); (flat/p.name).write_bytes(p.read_bytes())
        arm_inputs={'canonical':row['input'],**{name:record['input'] for name,record in result['arms'].items()},'paraphrase':row['input']}
        for arm,data in arm_inputs.items():
            prompt_id=fid+'/'+arm
            prompts.append({'prompt_id':prompt_id,'prompt':prompt(kind,data,arm=='paraphrase')})
            presentations.append({'prompt_id':prompt_id,'instance_id':fid,'construction_cluster':kind,'arm':arm,'problem_file':str(problem_path.relative_to(ROOT)),'gold':pack(solve(kind,data)),'input':pack(data)})
        results.append({key:value for key,value in result.items() if key not in ('gold','arms','nearby_non_equivalence')})
        print(fid,'materialized and certified',flush=True)
    write_json(ROOT/'model_prompts.json',{'schema_version':'imr-hard-prompts-2','prompts':prompts})
    write_json(ROOT/'presentations.json',{'schema_version':'imr-hard-grader-2','presentations':presentations})
    write_json(ROOT/'CERTIFICATE_RESULTS.json',{'instances':24,'construction_clusters':6,'certificates':results,'transformed_answer_copy_rejections':72,'wrong_order_rejections':24,'module_error_rejections':24,'nearby_non_equivalence_witnesses':24,'empirical_model_runs':0})
    print('24 instances, 120 prompts, 72 flat artifacts. Freeze manifest only after final validation.',flush=True)

if __name__=='__main__': main()
