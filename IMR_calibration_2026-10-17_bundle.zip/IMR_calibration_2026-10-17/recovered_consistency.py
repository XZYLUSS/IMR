"""Post-observation hard-bank transports of complete explicitly supplied answers."""
import json, sys
from study import ROOT, BANKS, jsonl, write_json

sys.path.insert(0, str(BANKS['hard']))
from core import all_instances, solve, transport, compose, same
from grading import parse_response, InvalidResponse


def main():
    rows = jsonl(ROOT / 'graded_hard.jsonl')
    audits = {r['run_id']: r for r in jsonl(ROOT / 'hard_format_audit.jsonl')}
    presentations = {r['prompt_id']: r for r in json.loads(
        (BANKS['hard'] / 'presentations.json').read_text())['presentations']}
    output = []

    def answer(row):
        if row is None or row['status'] != 'completed':
            return None
        p = presentations[row['prompt_id']]
        target = solve(p['construction_cluster'], p['input'])
        if row['grade']['valid']:
            return parse_response(row['response'], target)
        audit = audits.get(row['run_id'], {})
        explicit = audit.get('normalized_answer', {})
        # Exact parsing requires every coordinate and the declared shapes.
        # Wrong complete answers are retained; missing values are never filled.
        if set(explicit) != set(target):
            return None
        try:
            return parse_response(json.dumps(explicit), target)
        except InvalidResponse:
            return None

    for model in sorted({r['model'] for r in rows}):
        index = {r['prompt_id']: r for r in rows
                 if r['model'] == model and r['replicate'] == 0}
        for instance in all_instances():
            fid, kind = instance['id'], instance['construction_cluster']
            canonical = index.get(fid + '/canonical')
            base = answer(canonical)
            for arm in ['T1', 'T2', 'paraphrase', 'T2_after_T1']:
                other = index.get(fid + '/' + arm)
                observed = answer(other)
                result = {'model': model, 'family_id': fid, 'arm': arm,
                          'consistent': None, 'canonical_correct': None,
                          'arm_correct': None, 'post_observation': True,
                          'canonical_run_id': canonical['run_id'] if canonical else None,
                          'arm_run_id': other['run_id'] if other else None}
                if base is not None and observed is not None:
                    transform = (compose(kind, instance['T1'], instance['T2'])
                                 if arm == 'T2_after_T1' else instance.get(arm))
                    predicted = base if arm == 'paraphrase' else transport(kind, base, transform)
                    result['consistent'] = same(predicted, observed)
                    for key, value, row in [('canonical_correct', base, canonical),
                                            ('arm_correct', observed, other)]:
                        p = presentations[row['prompt_id']]
                        result[key] = same(value, solve(kind, p['input']))
                    if result['canonical_correct'] and result['arm_correct']:
                        assert result['consistent'], 'Two correct answers must satisfy certified transport'
                    if result['canonical_correct'] != result['arm_correct']:
                        assert not result['consistent'], 'Bijective transport cannot relate exactly one correct answer'
                output.append(result)
    write_json(ROOT / 'consistency_hard_recovered.json', output)
    print('recovered pairs', len(output), 'complete',
          sum(r['consistent'] is not None for r in output))


if __name__ == '__main__':
    main()
