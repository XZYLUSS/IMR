"""Native-answer transport consistency at replicate zero, separately from accuracy."""
import argparse,json,sys
from study import ROOT,BANKS,jsonl,write_json

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--bank',choices=['original','hard'],required=True);args=ap.parse_args();bank=args.bank
 sys.path.insert(0,str(BANKS[bank]));rows=jsonl(ROOT/f'graded_{bank}.jsonl');models=['gpt-6.1-sol','gpt-6-luna'];out=[]
 if bank=='original':
  from families import build_corpus
  instances=build_corpus()
 else:
  from core import all_instances,solve,transport,compose,same
  from grading import parse_response,InvalidResponse
  instances={r['id']:r for r in all_instances()}
  presentations={r['prompt_id']:r for r in json.loads((BANKS['hard']/'presentations.json').read_text())['presentations']}
 for model in models:
  index={r['prompt_id']:r for r in rows if r['model']==model and r['replicate']==0}
  for fid,instance in instances.items():
   canonical=index.get(fid+'/canonical');base=None
   if canonical and canonical['status']=='completed' and canonical['grade']['valid']:
    if bank=='original':base=instance.normalizer(canonical['response'])[0]
    else:
     p=presentations[fid+'/canonical'];base=parse_response(canonical['response'],solve(p['construction_cluster'],p['input']))
   for arm in ['T1','T2','paraphrase']+(['T2_after_T1'] if bank=='hard' else []):
    other=index.get(fid+'/'+arm);consistent=None
    if base is not None and other and other['status']=='completed' and other['grade']['valid']:
     if bank=='original':
      answer=instance.normalizer(other['response'])[0]
      expected=base if arm=='paraphrase' else next(t for t in instance.transforms if t.tid==arm).tau(base)
      consistent=instance.eqf(expected,answer)
     else:
      p=presentations[fid+'/'+arm];answer=parse_response(other['response'],solve(p['construction_cluster'],p['input']))
      kind=instance['construction_cluster'];expected=base if arm=='paraphrase' else transport(kind,base,compose(kind,instance['T1'],instance['T2']) if arm=='T2_after_T1' else instance[arm])
      consistent=same(expected,answer)
    out.append({'model':model,'bank':bank,'family_id':fid,'arm':arm,'consistent':consistent,'canonical_correct':canonical['grade']['correct'] if canonical else None,'arm_correct':other['grade']['correct'] if other else None,'eligible_pair':True,'interpretation':'Native parseable answers only; consistency can hold for incorrect answers.'})
 write_json(ROOT/f'consistency_{bank}.json',out)
 print('pairs',len(out),'parseable',sum(x['consistent'] is not None for x in out))
if __name__=='__main__':main()
