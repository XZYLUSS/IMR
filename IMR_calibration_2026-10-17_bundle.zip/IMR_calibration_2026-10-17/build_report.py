"""Reproducible local reporting. Incomplete schedules are explicitly inconclusive."""
import json,subprocess,sys,collections,statistics,datetime
from study import ROOT,jsonl,write_json
from analyze import analyze,summary

def pct(x):return '—' if x is None else f'{100*x:.1f}%'
def main():
 for bank in ['original','hard']:
  subprocess.run([sys.executable,str(ROOT/'grade_batch.py'),'--bank',bank,'--input',str(ROOT/'responses.jsonl'),'--output',str(ROOT/f'graded_{bank}.jsonl')],check=True)
  subprocess.run([sys.executable,str(ROOT/'consistency.py'),'--bank',bank],check=True)
 for script in ['audit_original.py','audit_hard.py','recovered_consistency.py','entry_diagnostics.py','check_defining_equations.py','verify_results.py']:
  subprocess.run([sys.executable,str(ROOT/script)],check=True,stdout=subprocess.DEVNULL)
 plan=jsonl(ROOT/'plan.jsonl');records=jsonl(ROOT/'graded_original.jsonl')+jsonl(ROOT/'graded_hard.jsonl')
 strict=analyze(plan,records);write_json(ROOT/'analysis_native.json',strict)
 audits={r['run_id']:r for f in ['original_notation_audit.jsonl','hard_format_audit.jsonl'] for r in jsonl(ROOT/f)}
 manual={r['run_id']:r for r in jsonl(ROOT/'manual_adjudications.jsonl')} if (ROOT/'manual_adjudications.jsonl').exists() else {}
 recovered=[]
 for r in records:
  r={**r,'grade':dict(r['grade'])};a=audits.get(r['run_id']);m=manual.get(r['run_id'])
  if m:
   assert m['response_sha256']==r['response_sha256'];classification=m['classification']
  else:classification=a['classification'] if a else None
  if classification in ['correct_after_format_recovery','correct_after_notation_recovery','manually_verified_correct']:
   r['grade'].update(category='correct',correct=True,adjudication='post_observation')
  elif classification in ['explicit_mathematical_error','manually_verified_wrong']:
   r['grade'].update(category='mathematical_or_native_label_error',correct=False,adjudication='post_observation')
  recovered.append(r)
 sensitivity=analyze(plan,recovered);sensitivity['analysis_status']='post_observation_adjudication_sensitivity';write_json(ROOT/'analysis_adjudicated.json',sensitivity)
 subprocess.run([sys.executable,str(ROOT/'all_success_bounds.py')],check=True)
 mechanical=[]
 for r in records:
  r={**r,'grade':dict(r['grade'])};a=audits.get(r['run_id'])
  semantic=bool(a and any(v.get('rule')=='semantic_synonym_requires_manual_review' for v in a.get('coordinates',{}).values()))
  if a and not semantic:
   if a['classification'] in ['correct_after_format_recovery','correct_after_notation_recovery']:r['grade'].update(category='correct',correct=True,adjudication='exact_recovery_only')
   elif a['classification']=='explicit_mathematical_error':r['grade'].update(category='mathematical_or_native_label_error',correct=False,adjudication='exact_recovery_only')
  mechanical.append(r)
 machine_analysis=analyze(plan,mechanical);machine_analysis['analysis_status']='post_observation_exact_recovery_without_semantic_or_manual_judgments';write_json(ROOT/'analysis_symbolic_only.json',machine_analysis)
 (ROOT/'graded_adjudicated.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in recovered))
 verification=json.loads((ROOT/'VERIFICATION.json').read_text());complete=verification['complete_schedule']
 lines=['# IMR harder-bank empirical calibration','',f'Generated: {datetime.datetime.now(datetime.timezone.utc).isoformat()}', '',f'**Status: {len(records)} of {len(plan)} scheduled responses recorded.**']
 if not complete:lines+=['','**The experiment is still incomplete. No final claim that difficulty saturation has been reduced is warranted.**']
 else:lines+=['','The fixed schedule is complete. The tables distinguish native instrument scores, mathematical-answer adjudication, and unresolved outcomes. Read [FINDINGS.md](FINDINGS.md) for the scientific conclusion and its limits.']
 lines+=['','## Matched models and design','','GPT-6.1 Sol and GPT-6 Luna were requested at high reasoning in separate fresh Codex sessions. Every bank prompt was scheduled once per model; canonical prompts have four repetitions. The primary denominator is 96 per bank and model. The balanced shared-arm pass also has 96 per bank and model. The extra composition arm is supplementary.','', 'The exact protocol, hashes, matching limits, and statistical derivation are in [PROTOCOL.json](PROTOCOL.json) and [METHODS.md](METHODS.md). Model aliases are observable; immutable provider revisions and exact output-token caps are not. All findings concern these administered banks and tested settings.','', '## Canonical results','','| Model | Original native | Hard native | Original adjudicated interval | Hard adjudicated interval | Conservative drop interval |','|---|---:|---:|---:|---:|---:|']
 for model in strict['results']:
  n=strict['results'][model]['canonical'];a=sensitivity['results'][model]['canonical']
  interval=lambda b:f"{pct(b['accuracy_lower'])}–{pct(b['accuracy_upper_if_uncertain_correct'])}"
  lines.append(f"| {model} | {n['original']['correct']}/{n['original']['planned']} | {n['hard']['correct']}/{n['hard']['planned']} | {interval(a['original'])} | {interval(a['hard'])} | {' to '.join(pct(x) for x in a['conservative_mathematical_drop_interval'])} |")
 lines+=['','Intervals in this table assign every unresolved format, notation or apparatus outcome first as incorrect and then as correct. They are deterministic bounds on these observed/missing records, not confidence intervals. Adjudication is a post-observation sensitivity analysis; native scores remain unchanged.','', '## Operational ceiling decisions','','| Model | Scope | Native decision | Adjudicated decision | Conditional simultaneous lower bound on expected drop |','|---|---|---|---|---:|']
 for model in strict['results']:
  for scope in ['canonical','canonical_without_AM','shared_arms','shared_arms_without_AM']:
   n=strict['results'][model][scope];a=sensitivity['results'][model][scope]
   lines.append(f"| {model} | {scope} | {n['status']} | {a['status']} | {pct(a.get('conditional_independent_generation_lower_bound'))} |")
 lines+=['','The conditional bounds assume independent model generations, correct adjudication, and stable administered settings; they do not treat parameter instances as independent sampled families. Eight comparisons use a union-bound familywise error level of 0.05. The observed ceiling thresholds are original ≥95%, hard ≤85%, and a drop ≥10 percentage points; hard <20% is flagged for floor risk. AM exclusion is required because hard AM changes the scientific topic.','', '## Canonical results by construction/module','','| Model | Module | Original native | Hard native | Original adjudicated | Hard adjudicated | Unresolved original / hard |','|---|---|---:|---:|---:|---:|---:|']
 for model in strict['results']:
  for cluster in ['QD','LG','AN','AM','BV','TN']:
   n=strict['results'][model]['by_cluster'][cluster];a=sensitivity['results'][model]['by_cluster'][cluster]
   unresolved=lambda v:sum(v['categories'].get(k,0) for k in ['format_error','label_ambiguity','apparatus','truncated','refusal'])
   lines.append(f"| {model} | {cluster} | {n['original']['correct']}/{n['original']['planned']} | {n['hard']['correct']}/{n['hard']['planned']} | {a['original']['correct']}/{a['original']['planned']} | {a['hard']['correct']}/{a['hard']['planned']} | {unresolved(a['original'])} / {unresolved(a['hard'])} |")
 lines+=['','## Individual presentation arms: one balanced pass','','| Model | Bank | Arm | Native correct / planned | Audited interval |','|---|---|---|---:|---:|']
 native_index={r['run_id']:r for r in records};audited_index={r['run_id']:r for r in recovered}
 for model in strict['results']:
  for bank in ['original','hard']:
   for arm in ['canonical','T1','T2','paraphrase']+(['T2_after_T1'] if bank=='hard' else []):
    pp=[p for p in plan if p['model']==model and p['bank']==bank and p['arm']==arm and p['replicate']==0]
    missing={'grade':{'category':'apparatus','correct':False}}
    n=summary([native_index.get(p['run_id'],missing) for p in pp]);a=summary([audited_index.get(p['run_id'],missing) for p in pp])
    lines.append(f"| {model} | {bank} | {arm} | {n['correct']}/{n['planned']} | {pct(a['accuracy_lower'])}–{pct(a['accuracy_upper_if_uncertain_correct'])} |")
 lines+=['','These arm-level rows use only repetition zero. Composition has no original-bank counterpart; it is supplementary, not included in the shared-arm contrast.']
 lines+=['','## Sensitivity without manual or semantic-origin adjudication','','| Model | Scope | Exact-recovery decision | Conservative drop interval | Conditional lower bound |','|---|---|---|---:|---:|']
 for model in strict['results']:
  for scope in ['canonical','canonical_without_AM','shared_arms','shared_arms_without_AM']:
   result=machine_analysis['results'][model][scope]
   lines.append(f"| {model} | {scope} | {result['status']} | {' to '.join(pct(x) for x in result['conservative_mathematical_drop_interval'])} | {pct(result['conditional_independent_generation_lower_bound'])} |")
 lines+=['','This analysis leaves descriptive anomaly-origin synonyms and all manual decisions unresolved. It includes bounded exact arithmetic, endpoint substitution, Boolean notation normalization, and explicit answer-array recovery. The eight conditional bounds form a separate sensitivity family; selecting between analysis variants is not asserted to preserve a single global error rate.']
 lines+=['','## Answer size and exact component errors','','The canonical original bank has 47 declared coordinates across 24 instances; the hard bank has 266 scalar or polynomial entries. An original symbolic label or finite set counts as one coordinate. This is a descriptive encoding comparison, not a common unit of conceptual complexity. Whole-answer success becomes more demanding as the number of required entries grows.','', '| Model | Hard module | Exact entries correct / parsed entries | Fully parsed responses |', '|---|---|---:|---:|']
 for model in strict['results']:
  for cluster in ['QD','LG','AN','AM','BV','TN']:
   rr=[r for r in records if r['model']==model and r['bank']=='hard' and r['cluster']==cluster and r['arm']=='canonical' and r['grade'].get('scalar_entry_counts')]
   entries=[v for r in rr for v in r['grade']['scalar_entry_counts'].values()]
   lines.append(f"| {model} | {cluster} | {sum(v['correct'] for v in entries)} / {sum(v['total'] for v in entries)} | {len(rr)} |")
 lines+=['','Entry accuracy is conditional on native parsing and is not an unbiased estimate over missing or malformed answers. It helps localize errors within submitted exact answers; it does not erase failures to provide required coordinates.']
 entries=json.loads((ROOT/'ENTRY_DIAGNOSTICS.json').read_text())
 lines+=['','### Entry bounds including exact format recovery','','| Model | Module | Verified correct | Verified wrong | Unresolved | Planned entries |','|---|---|---:|---:|---:|---:|']
 for r in entries['summaries']:
  lines.append(f"| {r['model']} | {r['cluster']} | {r['correct']} | {r['wrong']} | {r['unresolved']} | {r['total']} |")
 lines+=['','Every planned canonical entry is counted once. Parsed coordinates and explicitly parseable cells contribute verified outcomes; omitted or unparseable entries remain unresolved. A polynomial expression counts as one entry. Dividing correct by planned gives the lower bound; adding unresolved gives the upper bound. These descriptive entries are not independent trials and are not used to inflate the sampling-test denominator.']
 stages=json.loads((ROOT/'STAGE_DIAGNOSTICS.json').read_text())
 lines+=['','### Localization by required output quantity','','| Model | Module | Quantity | Correct | Wrong | Unresolved | Planned |','|---|---|---|---:|---:|---:|---:|']
 for r in stages['summaries']:
  lines.append(f"| {r['model']} | {r['cluster']} | {r['coordinate']} | {r['correct']} | {r['wrong']} | {r['unresolved']} | {r['planned']} |")
 lines+=['','These are canonical output-coordinate outcomes, not inferred internal error causes. For example, an incorrect holonomy can propagate into the driven response; the recorded outputs alone cannot distinguish a multiplication-order mistake from an arithmetic mistake. Partially supplied coordinates with an explicit wrong entry are wrong; other incomplete coordinates remain unresolved.']
 lines+=['','## Failure attribution','','| Model | Bank | Completed | Native correct | Native format failures | Native label ambiguity | Exact native wrong answers | Apparatus outcomes |','|---|---|---:|---:|---:|---:|---:|---:|']
 for model in strict['results']:
  for bank in ['original','hard']:
   rr=[r for r in records if r['model']==model and r['bank']==bank];c=collections.Counter(r['grade']['category'] for r in rr)
   lines.append(f"| {model} | {bank} | {sum(r['status']=='completed' for r in rr)} | {c['correct']} | {c['format_error']} | {c['label_ambiguity']} | {c['mathematical_or_native_label_error']} | {c['apparatus']} |")
 lines+=['','Raw failed responses and exact mismatch witnesses are preserved in the audit JSONL files. Some hard-bank responses copy the displayed schema wrapper instead of returning the requested arrays; the original parser has rejected equivalent mathematical notation and endpoint-evaluated boundary terms. Those failures are separated from explicit wrong numerical or polynomial answers. [Exact case studies](CASE_STUDIES.md) show a Sol response solving the wrong driven source, a Luna pairing inconsistent with its correct vectors, and a single incorrect Sol jet coefficient.','', '## Transport and paraphrase consistency','','| Model | Bank | Arms | Consistent / parseable pairs | Eligible pairs | Native-rejected but consistent pairs |','|---|---|---|---:|---:|---:|']
 for bank in ['original','hard']:
  rows=json.loads((ROOT/f'consistency_{bank}.json').read_text())
  for model in strict['results']:
   for label,arms in [('shared',{'T1','T2','paraphrase'})]+([('composition',{'T2_after_T1'})] if bank=='hard' else []):
    rr=[r for r in rows if r['model']==model and r['arm'] in arms];valid=[r for r in rr if r['consistent'] is not None]
    lines.append(f"| {model} | {bank} | {label} | {sum(r['consistent'] is True for r in valid)} / {len(valid)} | {len(rr)} | {sum(r['consistent'] is True and not (r['canonical_correct'] and r['arm_correct']) for r in valid)} |")
 lines+=['','These are native-parseable pairs from the first pass; the denominator is explicitly shown to expose selection by formatting. A high consistency rate alone does not establish correctness. Native rejection can reflect notation rather than a mathematical error.']
 recovered_pairs=json.loads((ROOT/'consistency_hard_recovered.json').read_text())
 lines+=['','### Hard-bank consistency after exact format recovery','','| Model | Arms | Consistent / complete pairs | Eligible pairs | Incorrect but consistent pairs |','|---|---|---:|---:|---:|']
 for model in strict['results']:
  for label,arms in [('shared',{'T1','T2','paraphrase'}),('composition',{'T2_after_T1'})]:
   rr=[r for r in recovered_pairs if r['model']==model and r['arm'] in arms];valid=[r for r in rr if r['consistent'] is not None]
   lines.append(f"| {model} | {label} | {sum(r['consistent'] is True for r in valid)} / {len(valid)} | {len(rr)} | {sum(r['consistent'] is True and not (r['canonical_correct'] and r['arm_correct']) for r in valid)} |")
 lines+=['','This post-observation analysis transports the actual canonical answer and compares it to the actual transformed answer. Complete incorrect answers remain eligible; missing values are never filled. Format recovery is the same bounded exact procedure used above. The unobserved pair outcomes remain unknown, so the conditional rate is not an unconditional consistency estimate.','', '## Compute and integrity','','| Model | Bank | Reported input tokens | Reported output tokens | Reported reasoning tokens | Median response seconds |','|---|---|---:|---:|---:|---:|']
 for model in strict['results']:
  for bank in ['original','hard']:
   rr=[r for r in records if r['model']==model and r['bank']==bank];totals=collections.Counter()
   for r in rr:totals.update(r.get('usage') or {})
   lines.append(f"| {model} | {bank} | {totals['input_tokens']} | {totals['output_tokens']} | {totals['reasoning_output_tokens']} | {statistics.median([r['elapsed_seconds'] for r in rr]):.1f} |" if rr else f'| {model} | {bank} | 0 | 0 | 0 | — |')
 lines+=['','| Model | Canonical bank | Responses with usage | Mean reported reasoning tokens | Median reported reasoning tokens |','|---|---|---:|---:|---:|']
 for model in strict['results']:
  for bank in ['original','hard']:
   counts=[r['usage']['reasoning_output_tokens'] for r in records if r['model']==model and r['bank']==bank and r['arm']=='canonical' and r.get('usage') and 'reasoning_output_tokens' in r['usage']]
   if counts:lines.append(f"| {model} | {bank} | {len(counts)} | {statistics.mean(counts):.1f} | {statistics.median(counts):.1f} |")
 lines+=['','More reported reasoning tokens at unchanged accuracy indicate higher observed generation cost, not necessarily a reduced performance ceiling or a direct measure of conceptual difficulty.','', 'Reasoning tokens are reported as a component of output usage, not added again to total output. Token counts measure actual usage, not a matched token allowance.','',f"Verified result records: {verification['verified_records']}. Both frozen source manifests still match all 185 original and 173 hard-bank entries. Per-attempt hashes and one-turn event checks are in [VERIFICATION.json](VERIFICATION.json).",'', '## Interpretation limits','','A reduction in native score can come from answer arity, format compliance, numerical computation, or mathematical reasoning. The current design does not isolate these causes. Template reuse, six construction clusters, the AM topic change, uncontrolled service-level sampling defaults, and unavailable immutable model revisions limit generalization. No candidate family is automatically admitted to a confirmatory bank by this study.','', 'The exact statistical reference and official interface documentation are linked in [METHODS.md](METHODS.md).']
 checks=json.loads((ROOT/'DEFINING_EQUATION_CHECKS.json').read_text())
 lines+=['','## Direct defining-equation verification','',f"Submitted hard-bank answers: {checks['counts'].get('pass',0)} pass, {checks['counts'].get('rejected',0)} are rejected, and {checks['counts'].get('not_checked_incomplete_or_unparsed',0)} lack a complete typed answer and are not checked. All tested cases agree with the exact-answer classification.",'', 'The certificates check the submitted quantities in the defining equations, including independent exponential-moment differentiation for AN. They share SymPy and bank utilities, so this is an additional equation check rather than an independent proof-assistant implementation. Run `check_defining_equations.py --recompute` to bypass the incremental cache. Detailed checks and rejection reasons are in [DEFINING_EQUATION_CHECKS.json](DEFINING_EQUATION_CHECKS.json).']
 tests=json.loads((ROOT/'TEST_SUMMARY.json').read_text())
 lines+=['','## Executed validation suites','','| Suite | Tests | Failures | Errors |','|---|---:|---:|---:|']
 for name,r in tests.items():lines.append(f"| {name} | {r['tests']} | {r['failures']} | {r['errors']} |")
 lines+=['','The original suite ran in a byte-verified temporary copy. These tests verify source/evaluator properties and synthetic fixtures; they are excluded from the 720 empirical model responses. The source manifests are checked separately.']
 bounds=json.loads((ROOT/'ALL_SUCCESS_BOUNDS.json').read_text())
 applicable=[r for r in bounds['results'] if r['applies']]
 lines+=['','## Exploratory all-success bound','','This post-observation supplement has a separate four-cell simultaneous 95% guarantee, conditional on independent generations and valid grading. Its self-contained derivation is in [METHODS.md](METHODS.md). It does not assert a joint guarantee with the prospective Hoeffding family.']
 if applicable:
  lines+=['','| Model | Canonical bank | Verified correct | Conditional lower bound on average success probability |','|---|---|---:|---:|']
  for r in applicable:lines.append(f"| {r['model']} | {r['bank']} | {r['correct']}/{r['planned']} | {100*r['conditional_lower_bound']:.3f}% |")
 else:lines+=['','No canonical cell currently has all planned answers verified correct, so no nonzero all-success bound applies.']
 lines+=['','## Typed answers do not certify derivations','','A targeted spot-check found a Luna response with the correct final anomaly density but an ultraviolet-growing heat-kernel regulator and an inconsistent action-variation sign. An explicit Pauli-matrix computation verifies the regulator error. These errors can cancel in the final coefficient. See [PROOF_SPOT_CHECK.md](PROOF_SPOT_CHECK.md) and its machine-readable witness. This is evidence against interpreting answer-level saturation as proof-level saturation; it is not an exhaustive derivation assessment and does not alter the predeclared answer score.']
 (ROOT/'REPORT.md').write_text('\n'.join(lines)+'\n')
 print(json.dumps({'records':len(records),'complete':complete,'report':str(ROOT/'REPORT.md')}))
if __name__=='__main__':main()
