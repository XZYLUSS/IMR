# IMR harder-bank empirical calibration

Generated: 2026-10-17T12:31:11.752411+00:00

**Status: 720 of 720 scheduled responses recorded.**

The fixed schedule is complete. The tables distinguish native instrument scores, mathematical-answer adjudication, and unresolved outcomes. Read [FINDINGS.md](FINDINGS.md) for the scientific conclusion and its limits.

## Matched models and design

GPT-6.1 Sol and GPT-6 Luna were requested at high reasoning in separate fresh Codex sessions. Every bank prompt was scheduled once per model; canonical prompts have four repetitions. The primary denominator is 96 per bank and model. The balanced shared-arm pass also has 96 per bank and model. The extra composition arm is supplementary.

The exact protocol, hashes, matching limits, and statistical derivation are in [PROTOCOL.json](PROTOCOL.json) and [METHODS.md](METHODS.md). Model aliases are observable; immutable provider revisions and exact output-token caps are not. All findings concern these administered banks and tested settings.

## Canonical results

| Model | Original native | Hard native | Original adjudicated interval | Hard adjudicated interval | Conservative drop interval |
|---|---:|---:|---:|---:|---:|
| gpt-6-luna | 55/96 | 4/96 | 97.9%–97.9% | 29.2%–38.5% | 59.4% to 68.8% |
| gpt-6.1-sol | 57/96 | 90/96 | 100.0%–100.0% | 97.9%–97.9% | 2.1% to 2.1% |

Intervals in this table assign every unresolved format, notation or apparatus outcome first as incorrect and then as correct. They are deterministic bounds on these observed/missing records, not confidence intervals. Adjudication is a post-observation sensitivity analysis; native scores remain unchanged.

## Operational ceiling decisions

| Model | Scope | Native decision | Adjudicated decision | Conditional simultaneous lower bound on expected drop |
|---|---|---|---|---:|
| gpt-6-luna | canonical | original_ceiling_ambiguous | observed_finite_bank_reduction | 36.4% |
| gpt-6-luna | canonical_without_AM | original_ceiling_ambiguous | observed_finite_bank_reduction | 46.1% |
| gpt-6-luna | shared_arms | original_ceiling_ambiguous | observed_finite_bank_reduction | 37.4% |
| gpt-6-luna | shared_arms_without_AM | original_ceiling_ambiguous | observed_finite_bank_reduction | 41.1% |
| gpt-6.1-sol | canonical | original_ceiling_ambiguous | ceiling_persists_in_observed_scores | -20.9% |
| gpt-6.1-sol | canonical_without_AM | original_ceiling_ambiguous | ceiling_persists_in_observed_scores | -22.7% |
| gpt-6.1-sol | shared_arms | original_ceiling_ambiguous | ceiling_persists_in_observed_scores | -22.0% |
| gpt-6.1-sol | shared_arms_without_AM | original_ceiling_ambiguous | ceiling_persists_in_observed_scores | -23.9% |

The conditional bounds assume independent model generations, correct adjudication, and stable administered settings; they do not treat parameter instances as independent sampled families. Eight comparisons use a union-bound familywise error level of 0.05. The observed ceiling thresholds are original ≥95%, hard ≤85%, and a drop ≥10 percentage points; hard <20% is flagged for floor risk. AM exclusion is required because hard AM changes the scientific topic.

## Canonical results by construction/module

| Model | Module | Original native | Hard native | Original adjudicated | Hard adjudicated | Unresolved original / hard |
|---|---|---:|---:|---:|---:|---:|
| gpt-6-luna | QD | 16/16 | 0/16 | 16/16 | 0/16 | 0 / 3 |
| gpt-6-luna | LG | 12/16 | 0/16 | 16/16 | 4/16 | 0 / 3 |
| gpt-6-luna | AN | 11/16 | 0/16 | 16/16 | 5/16 | 0 / 1 |
| gpt-6-luna | AM | 0/16 | 0/16 | 14/16 | 12/16 | 0 / 2 |
| gpt-6-luna | BV | 1/16 | 0/16 | 16/16 | 1/16 | 0 / 0 |
| gpt-6-luna | TN | 15/16 | 4/16 | 16/16 | 6/16 | 0 / 0 |
| gpt-6.1-sol | QD | 16/16 | 14/16 | 16/16 | 14/16 | 0 / 0 |
| gpt-6.1-sol | LG | 12/16 | 16/16 | 16/16 | 16/16 | 0 / 0 |
| gpt-6.1-sol | AN | 10/16 | 16/16 | 16/16 | 16/16 | 0 / 0 |
| gpt-6.1-sol | AM | 0/16 | 16/16 | 16/16 | 16/16 | 0 / 0 |
| gpt-6.1-sol | BV | 7/16 | 12/16 | 16/16 | 16/16 | 0 / 0 |
| gpt-6.1-sol | TN | 12/16 | 16/16 | 16/16 | 16/16 | 0 / 0 |

## Individual presentation arms: one balanced pass

| Model | Bank | Arm | Native correct / planned | Audited interval |
|---|---|---|---:|---:|
| gpt-6-luna | original | canonical | 14/24 | 100.0%–100.0% |
| gpt-6-luna | original | T1 | 13/24 | 100.0%–100.0% |
| gpt-6-luna | original | T2 | 12/24 | 100.0%–100.0% |
| gpt-6-luna | original | paraphrase | 13/24 | 100.0%–100.0% |
| gpt-6-luna | hard | canonical | 1/24 | 37.5%–41.7% |
| gpt-6-luna | hard | T1 | 1/24 | 25.0%–41.7% |
| gpt-6-luna | hard | T2 | 0/24 | 25.0%–29.2% |
| gpt-6-luna | hard | paraphrase | 2/24 | 37.5%–45.8% |
| gpt-6-luna | hard | T2_after_T1 | 1/24 | 20.8%–33.3% |
| gpt-6.1-sol | original | canonical | 15/24 | 100.0%–100.0% |
| gpt-6.1-sol | original | T1 | 15/24 | 100.0%–100.0% |
| gpt-6.1-sol | original | T2 | 14/24 | 100.0%–100.0% |
| gpt-6.1-sol | original | paraphrase | 15/24 | 100.0%–100.0% |
| gpt-6.1-sol | hard | canonical | 24/24 | 100.0%–100.0% |
| gpt-6.1-sol | hard | T1 | 22/24 | 95.8%–95.8% |
| gpt-6.1-sol | hard | T2 | 22/24 | 100.0%–100.0% |
| gpt-6.1-sol | hard | paraphrase | 24/24 | 100.0%–100.0% |
| gpt-6.1-sol | hard | T2_after_T1 | 23/24 | 100.0%–100.0% |

These arm-level rows use only repetition zero. Composition has no original-bank counterpart; it is supplementary, not included in the shared-arm contrast.

## Sensitivity without manual or semantic-origin adjudication

| Model | Scope | Exact-recovery decision | Conservative drop interval | Conditional lower bound |
|---|---|---|---:|---:|
| gpt-6-luna | canonical | original_ceiling_ambiguous | 41.7% to 69.8% | 18.7% |
| gpt-6-luna | canonical_without_AM | observed_finite_bank_reduction | 67.5% to 80.0% | 42.3% |
| gpt-6-luna | shared_arms | original_ceiling_ambiguous | 42.7% to 68.8% | 19.7% |
| gpt-6-luna | shared_arms_without_AM | observed_finite_bank_reduction | 65.0% to 75.0% | 39.8% |
| gpt-6.1-sol | canonical | original_ceiling_ambiguous | -14.6% to 2.1% | -37.6% |
| gpt-6.1-sol | canonical_without_AM | ceiling_persists_in_observed_scores | 2.5% to 2.5% | -22.7% |
| gpt-6.1-sol | shared_arms | original_ceiling_ambiguous | -15.6% to 1.0% | -38.6% |
| gpt-6.1-sol | shared_arms_without_AM | ceiling_persists_in_observed_scores | 1.2% to 1.2% | -23.9% |

This analysis leaves descriptive anomaly-origin synonyms and all manual decisions unresolved. It includes bounded exact arithmetic, endpoint substitution, Boolean notation normalization, and explicit answer-array recovery. The eight conditional bounds form a separate sensitivity family; selecting between analysis variants is not asserted to preserve a single global error rate.

## Answer size and exact component errors

The canonical original bank has 47 declared coordinates across 24 instances; the hard bank has 266 scalar or polynomial entries. An original symbolic label or finite set counts as one coordinate. This is a descriptive encoding comparison, not a common unit of conceptual complexity. Whole-answer success becomes more demanding as the number of required entries grows.

| Model | Hard module | Exact entries correct / parsed entries | Fully parsed responses |
|---|---|---:|---:|
| gpt-6-luna | QD | 0 / 0 | 0 |
| gpt-6-luna | LG | 0 / 0 | 0 |
| gpt-6-luna | AN | 1 / 4 | 1 |
| gpt-6-luna | AM | 0 / 0 | 0 |
| gpt-6-luna | BV | 0 / 0 | 0 |
| gpt-6-luna | TN | 122 / 150 | 6 |
| gpt-6.1-sol | QD | 236 / 240 | 16 |
| gpt-6.1-sol | LG | 112 / 112 | 16 |
| gpt-6.1-sol | AN | 80 / 80 | 16 |
| gpt-6.1-sol | AM | 136 / 136 | 16 |
| gpt-6.1-sol | BV | 72 / 72 | 12 |
| gpt-6.1-sol | TN | 400 / 400 | 16 |

Entry accuracy is conditional on native parsing and is not an unbiased estimate over missing or malformed answers. It helps localize errors within submitted exact answers; it does not erase failures to provide required coordinates.

### Entry bounds including exact format recovery

| Model | Module | Verified correct | Verified wrong | Unresolved | Planned entries |
|---|---|---:|---:|---:|---:|
| gpt-6-luna | ALL | 715 | 306 | 43 | 1064 |
| gpt-6-luna | QD | 155 | 58 | 27 | 240 |
| gpt-6-luna | LG | 100 | 9 | 3 | 112 |
| gpt-6-luna | AN | 38 | 39 | 3 | 80 |
| gpt-6-luna | AM | 121 | 6 | 9 | 136 |
| gpt-6-luna | BV | 55 | 41 | 0 | 96 |
| gpt-6-luna | TN | 246 | 153 | 1 | 400 |
| gpt-6.1-sol | ALL | 1060 | 4 | 0 | 1064 |
| gpt-6.1-sol | QD | 236 | 4 | 0 | 240 |
| gpt-6.1-sol | LG | 112 | 0 | 0 | 112 |
| gpt-6.1-sol | AN | 80 | 0 | 0 | 80 |
| gpt-6.1-sol | AM | 136 | 0 | 0 | 136 |
| gpt-6.1-sol | BV | 96 | 0 | 0 | 96 |
| gpt-6.1-sol | TN | 400 | 0 | 0 | 400 |

Every planned canonical entry is counted once. Parsed coordinates and explicitly parseable cells contribute verified outcomes; omitted or unparseable entries remain unresolved. A polynomial expression counts as one entry. Dividing correct by planned gives the lower bound; adding unresolved gives the upper bound. These descriptive entries are not independent trials and are not used to inflate the sampling-test denominator.

### Localization by required output quantity

| Model | Module | Quantity | Correct | Wrong | Unresolved | Planned |
|---|---|---|---:|---:|---:|---:|
| gpt-6-luna | AM | amplitude_squared | 13 | 0 | 3 | 16 |
| gpt-6-luna | AM | mean | 13 | 2 | 1 | 16 |
| gpt-6-luna | AM | precision | 14 | 1 | 1 | 16 |
| gpt-6-luna | AN | jet | 5 | 10 | 1 | 16 |
| gpt-6-luna | BV | acceleration_momentum | 14 | 2 | 0 | 16 |
| gpt-6-luna | BV | euler | 1 | 15 | 0 | 16 |
| gpt-6-luna | BV | momentum | 5 | 11 | 0 | 16 |
| gpt-6-luna | LG | fluxes | 16 | 0 | 0 | 16 |
| gpt-6-luna | LG | pairing | 4 | 9 | 3 | 16 |
| gpt-6-luna | LG | periods | 16 | 0 | 0 | 16 |
| gpt-6-luna | QD | holonomy | 11 | 5 | 0 | 16 |
| gpt-6-luna | QD | resolvent_det | 2 | 7 | 7 | 16 |
| gpt-6-luna | QD | response | 0 | 9 | 7 | 16 |
| gpt-6-luna | TN | charge_u | 6 | 10 | 0 | 16 |
| gpt-6-luna | TN | charge_v | 7 | 9 | 0 | 16 |
| gpt-6-luna | TN | dsz | 7 | 8 | 1 | 16 |
| gpt-6-luna | TN | quadratic_form | 10 | 6 | 0 | 16 |
| gpt-6.1-sol | AM | amplitude_squared | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | AM | mean | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | AM | precision | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | AN | jet | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | BV | acceleration_momentum | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | BV | euler | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | BV | momentum | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | LG | fluxes | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | LG | pairing | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | LG | periods | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | QD | holonomy | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | QD | resolvent_det | 15 | 1 | 0 | 16 |
| gpt-6.1-sol | QD | response | 15 | 1 | 0 | 16 |
| gpt-6.1-sol | TN | charge_u | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | TN | charge_v | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | TN | dsz | 16 | 0 | 0 | 16 |
| gpt-6.1-sol | TN | quadratic_form | 16 | 0 | 0 | 16 |

These are canonical output-coordinate outcomes, not inferred internal error causes. For example, an incorrect holonomy can propagate into the driven response; the recorded outputs alone cannot distinguish a multiplication-order mistake from an arithmetic mistake. Partially supplied coordinates with an explicit wrong entry are wrong; other incomplete coordinates remain unresolved.

## Failure attribution

| Model | Bank | Completed | Native correct | Native format failures | Native label ambiguity | Exact native wrong answers | Apparatus outcomes |
|---|---|---:|---:|---:|---:|---:|---:|
| gpt-6-luna | original | 168 | 93 | 26 | 49 | 0 | 0 |
| gpt-6-luna | hard | 192 | 8 | 178 | 0 | 6 | 0 |
| gpt-6.1-sol | original | 168 | 101 | 15 | 52 | 0 | 0 |
| gpt-6.1-sol | hard | 192 | 181 | 8 | 0 | 3 | 0 |

Raw failed responses and exact mismatch witnesses are preserved in the audit JSONL files. Some hard-bank responses copy the displayed schema wrapper instead of returning the requested arrays; the original parser has rejected equivalent mathematical notation and endpoint-evaluated boundary terms. Those failures are separated from explicit wrong numerical or polynomial answers. [Exact case studies](CASE_STUDIES.md) show a Sol response solving the wrong driven source, a Luna pairing inconsistent with its correct vectors, and a single incorrect Sol jet coefficient.

## Transport and paraphrase consistency

| Model | Bank | Arms | Consistent / parseable pairs | Eligible pairs | Native-rejected but consistent pairs |
|---|---|---|---:|---:|---:|
| gpt-6-luna | original | shared | 39 / 60 | 72 | 2 |
| gpt-6.1-sol | original | shared | 54 / 66 | 72 | 10 |
| gpt-6-luna | hard | shared | 0 / 2 | 72 | 0 |
| gpt-6-luna | hard | composition | 1 / 1 | 24 | 0 |
| gpt-6.1-sol | hard | shared | 68 / 69 | 72 | 0 |
| gpt-6.1-sol | hard | composition | 23 / 23 | 24 | 0 |

These are native-parseable pairs from the first pass; the denominator is explicitly shown to expose selection by formatting. A high consistency rate alone does not establish correctness. Native rejection can reflect notation rather than a mathematical error.

### Hard-bank consistency after exact format recovery

| Model | Arms | Consistent / complete pairs | Eligible pairs | Incorrect but consistent pairs |
|---|---|---:|---:|---:|
| gpt-6-luna | shared | 13 / 54 | 72 | 0 |
| gpt-6-luna | composition | 3 / 15 | 24 | 0 |
| gpt-6.1-sol | shared | 71 / 72 | 72 | 0 |
| gpt-6.1-sol | composition | 24 / 24 | 24 | 0 |

This post-observation analysis transports the actual canonical answer and compares it to the actual transformed answer. Complete incorrect answers remain eligible; missing values are never filled. Format recovery is the same bounded exact procedure used above. The unobserved pair outcomes remain unknown, so the conditional rate is not an unconditional consistency estimate.

## Compute and integrity

| Model | Bank | Reported input tokens | Reported output tokens | Reported reasoning tokens | Median response seconds |
|---|---|---:|---:|---:|---:|
| gpt-6-luna | original | 932126 | 133198 | 89011 | 7.3 |
| gpt-6-luna | hard | 1151887 | 587085 | 532966 | 24.2 |
| gpt-6.1-sol | original | 932130 | 145446 | 82018 | 13.9 |
| gpt-6.1-sol | hard | 1151885 | 498175 | 469856 | 32.4 |

| Model | Canonical bank | Responses with usage | Mean reported reasoning tokens | Median reported reasoning tokens |
|---|---|---:|---:|---:|
| gpt-6-luna | original | 96 | 522.3 | 170.0 |
| gpt-6-luna | hard | 96 | 2668.8 | 2361.0 |
| gpt-6.1-sol | original | 96 | 491.4 | 176.0 |
| gpt-6.1-sol | hard | 96 | 2068.2 | 1491.0 |

More reported reasoning tokens at unchanged accuracy indicate higher observed generation cost, not necessarily a reduced performance ceiling or a direct measure of conceptual difficulty.

Reasoning tokens are reported as a component of output usage, not added again to total output. Token counts measure actual usage, not a matched token allowance.

Verified result records: 720. Both frozen source manifests still match all 185 original and 173 hard-bank entries. Per-attempt hashes and one-turn event checks are in [VERIFICATION.json](VERIFICATION.json).

## Interpretation limits

A reduction in native score can come from answer arity, format compliance, numerical computation, or mathematical reasoning. The current design does not isolate these causes. Template reuse, six construction clusters, the AM topic change, uncontrolled service-level sampling defaults, and unavailable immutable model revisions limit generalization. No candidate family is automatically admitted to a confirmatory bank by this study.

The exact statistical reference and official interface documentation are linked in [METHODS.md](METHODS.md).

## Direct defining-equation verification

Submitted hard-bank answers: 243 pass, 104 are rejected, and 37 lack a complete typed answer and are not checked. All tested cases agree with the exact-answer classification.

The certificates check the submitted quantities in the defining equations, including independent exponential-moment differentiation for AN. They share SymPy and bank utilities, so this is an additional equation check rather than an independent proof-assistant implementation. Run `check_defining_equations.py --recompute` to bypass the incremental cache. Detailed checks and rejection reasons are in [DEFINING_EQUATION_CHECKS.json](DEFINING_EQUATION_CHECKS.json).

## Executed validation suites

| Suite | Tests | Failures | Errors |
|---|---:|---:|---:|
| analysis | 20 | 0 | 0 |
| hard_bank | 106 | 0 | 0 |
| original_bank | 354 | 0 | 0 |

The original suite ran in a byte-verified temporary copy. These tests verify source/evaluator properties and synthetic fixtures; they are excluded from the 720 empirical model responses. The source manifests are checked separately.

## Exploratory all-success bound

This post-observation supplement has a separate four-cell simultaneous 95% guarantee, conditional on independent generations and valid grading. Its self-contained derivation is in [METHODS.md](METHODS.md). It does not assert a joint guarantee with the prospective Hoeffding family.

| Model | Canonical bank | Verified correct | Conditional lower bound on average success probability |
|---|---|---:|---:|
| gpt-6.1-sol | original | 96/96 | 95.538% |

## Typed answers do not certify derivations

A targeted spot-check found a Luna response with the correct final anomaly density but an ultraviolet-growing heat-kernel regulator and an inconsistent action-variation sign. An explicit Pauli-matrix computation verifies the regulator error. These errors can cancel in the final coefficient. See [PROOF_SPOT_CHECK.md](PROOF_SPOT_CHECK.md) and its machine-readable witness. This is evidence against interpreting answer-level saturation as proof-level saturation; it is not an exhaustive derivation assessment and does not alter the predeclared answer score.
