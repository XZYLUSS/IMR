# Evaluation audit development log

The inference protocol, input plan, source banks, and backend adapter are frozen. The reporting and adjudication implementation was developed while the fixed inference schedule ran. No grading result changes which model requests are dispatched.

- The secondary analysis was corrected before final reporting to use only repetition zero for all four shared arms. Mixing the extra canonical repetitions into this score would overweight the canonical arm.
- Missing/apparatus outcomes force an incomplete-coverage decision and are included in uncertainty bounds; they cannot imply failure to reproduce a mathematical ceiling.
- Original symbolic-label mismatches are unresolved until audited, rather than automatically mathematical errors.
- AM-002 component diagnostics group coefficient and tensor structure into their physical-density normalization, because the frozen native equality kernel couples those fields.
- The initial Boolean audit helper treated the label `false` as different from `no`. Review of the raw responses identified this evaluator error; it was corrected to explicit true/yes and false/no equivalence before final reporting, with regression checks. Unknown Boolean labels remain unresolved.
- Format-recovery diagnostics were extended to remove a redundant singleton outer array, recognize exact integer JSON values, and distinguish metadata dimensions from actual nested answer arrays. No missing numerical answers are filled in.
- Boundary notation audits compare endpoint-evaluated expressions by exact symbolic substitution and accept limited unambiguous implicit multiplication. Full boundary integrals and descriptive anomaly-origin labels are separately documented manual adjudications when the native coordinate representation differs.

All these changes concern evaluator diagnostics and post-observation sensitivity analyses. Native frozen-bank scores are retained, and manual decisions identify response hashes and their scope. None of these changes supplies information to a model session or reruns a wrong answer.
- Boolean format recovery explicitly maps yes/true/1 and no/false/0 symmetrically, including single surrounding braces. The native non-coercing score remains untouched. Tests verify that a submitted 1 is rejected when the correct Boolean is false; unknown labels remain unresolved. Raw cases using 0 were also inspected and stated the corresponding negative conclusion in their explanations.
- Inspection of hard-bank rejections revealed explicit unevaluated rational arithmetic and flat column lists. The sensitivity audit now evaluates bounded constant arithmetic with the frozen bank's safe AST walker and reshapes only a list of the declared column length. Undefined symbols, function calls, and omitted coordinates remain unresolved. Tests cover correct and incorrect rational expressions and rejection of executable syntax.
- Operational decisions now compare exact `Fraction` values rather than binary floats. A regression case with 95/100 original and 85/100 hard successes verifies that the exact 1/10 drop meets the declared threshold; the adjacent 9/100 drop does not. Exact interval endpoints and symbolic confidence-bound expressions are retained in JSON.
- Boundary-integral recovery now extracts an explicitly displayed integrand only for recognized full-boundary notation and the declared measure (`dSigma_mu` or `dA_g`). It checks that integrand with the bounded polynomial grammar. Opposite signs are rejected and a mismatched measure remains unresolved. Earlier manual decisions for these same expressions remain preserved as an audit trail.

## Recovered transport diagnostics

Added `recovered_consistency.py` as an explicitly post-observation analysis of first-pass hard-bank pairs. It transports complete actual submitted answers after the same exact wrapper recovery used for accuracy; it retains complete wrong answers and never fills missing coordinates. Native consistency remains separate. Renamed its native-rejected category to avoid equating original string-label rejection with a mathematical error.

Added exact per-entry residual witnesses for native hard-bank errors and `entry_diagnostics.py` for all planned canonical entries. The latter includes bounded format recovery and partial explicit cells, leaves missing entries unresolved, and makes no independence claim or additional significance test.

## Exploratory all-success supplement

After the first-pass results, added an explicitly exploratory four-cell all-success lower bound. Its derivation uses independence and the product-at-fixed-sum inequality, permits non-identical prompt success probabilities, and provides its own four-cell family guarantee. It does not replace the prospective Hoeffding analysis or assert a joint guarantee across analysis families. Exact rational powers determine threshold comparisons.

Added the explicit Unicode pi glyph alias to the bounded original-bank arithmetic parser after a response used `π^2/6`. Positive and incorrect-value regression cases preserve exact comparison; the native score remains unchanged.

## Joint anomaly-density audit correction

The native grader already grades the AM-002 coefficient and structure jointly. The additional notation audit had compared them separately, which could misclassify an equivalent 1/8 FFtilde answer relative to 1/16 epsFF when a separate origin label also needed recovery. The audit now normalizes only recognized, explicitly defined contractions and compares the combined density; unknown contractions remain unresolved. The observed negative-coefficient examples explicitly use positive epsFF and remain mathematical errors. Regression tests cover equivalent and incorrect pairs and an unknown signed contraction.
