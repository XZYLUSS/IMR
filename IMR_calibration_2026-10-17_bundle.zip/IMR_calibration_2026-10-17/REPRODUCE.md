# Reproduce or inspect this calibration

The original and hard banks are intentionally outside this evaluation directory and remain frozen. `PROTOCOL.json` records their absolute locations, manifest hashes, and public prompt hashes. All inference inputs come from their gold-free exports. Do not substitute family `*-problem.json` or `*-transform.json` files as model input.

## Offline verification and reporting

Use a Python environment with SymPy 1.14.0 and pytest. The study used:

```
../tmp/imr_sep_review/venv/bin/python -m pytest -q test_calibration.py test_audits.py
../tmp/imr_sep_review/venv/bin/python verify_results.py
../tmp/imr_sep_review/venv/bin/python build_report.py
../tmp/imr_sep_review/venv/bin/python catalog_failures.py
```

The report builder uses separate processes for the original and hard grading modules, since both banks define modules named `core`. It writes native results and adjudicated sensitivity results separately. `manual_adjudications.jsonl`, when present, records response hashes and explicit reasons for manual decisions. Raw model responses are never overwritten by the adjudication process. The synthetic fixtures in test files are not empirical data.

The integrity report is `VERIFICATION.json`. The report is complete only if its `complete_schedule` field is true and every planned record has an acceptable observed status. An experiment with missing or apparatus outcomes can remain scientifically inconclusive even when the dispatch schedule has ended.

## Resume the fixed inference schedule

The user explicitly authorized this particular run with `gpt-6.1-sol` and `gpt-6-luna`, high reasoning, using their Codex allowance. Resuming it uses the installed Codex CLI and the existing account login:

```
python3 run_evaluation.py
```

Do not run two copies concurrently. The runner validates frozen input hashes, skips recorded runs, and preserves per-attempt evidence. A fresh unrecorded run gets a new empty working directory and an ephemeral Codex session. Ordinary local sandbox execution may not permit the CLI's runtime initialization or network connection; this execution used the app's approved escalation for the authorized model calls. No credentials are stored in this study folder.

The schedule contains 720 unique run IDs. The expected per-model count is 168 original responses and 192 hard responses. Canonical prompts have 4 repetitions; each other arm has 1. There are no accuracy-based reruns or early stopping rules. Infrastructure-only retries are bounded and retained. A process interruption between writing an attempt result and appending the aggregate log can be resumed from the existing attempt result. An interruption while an attempt is in flight should be audited before resuming; do not overwrite its directory.

## Principal artifacts

- `PROTOCOL.json`, `SETTINGS.json`, `plan.jsonl`: prospective protocol, inference controls, and fixed randomized schedule.
- `responses.jsonl`, `runs/<run_id>/attempt_<n>/`: empirical final records and complete raw attempt evidence.
- `graded_original.jsonl`, `graded_hard.jsonl`: frozen native-parser outcomes.
- `original_notation_audit.jsonl`, `hard_format_audit.jsonl`: post-observation notation/format audits and exact mismatch witnesses.
- `graded_adjudicated.jsonl`, `analysis_adjudicated.json`: explicit sensitivity analysis, not silently substituted native scores.
- `consistency_original.json`, `consistency_hard.json`: native answer-transport consistency and its parseable denominators.
- `REPORT.md`, `METHODS.md`, `FAILURE_CATALOG.md`: readable findings, mathematical methods, and complete failure navigation.
- `preflight/`: apparatus checks excluded from empirical counts. These diagnostics can contain local workspace/policy paths and are intended for local audit.

The candidate bank's original `calibration_status=not_run` fields describe its frozen state at creation. This external evaluation adds evidence without mutating that release or automatically changing confirmatory eligibility.

For a fresh defining-equation audit of every complete hard-bank answer, bypass the incremental cache:

```
../tmp/imr_sep_review/venv/bin/python check_defining_equations.py --recompute
```

This audit checks submitted values in the frozen mathematical identities and requires agreement with exact-answer grading. It records incomplete/unparsed answers as untested, not as certified failures. `plot_results.py` exports the canonical results as PNG, PDF and SVG using Matplotlib 3.10.7; `repeat_diagnostics.py` records all four canonical outcomes per instance.


## Portable offline bundle

`IMR_calibration_2026-10-17_bundle.zip` contains this study directory, the manifest-listed original and hard-bank sources at their original relative locations, and the original review archive. Extract the whole archive into one directory so those relative locations remain intact. The original absolute invocation paths remain in the historical records as provenance; offline verification checks them against the frozen historical settings. Offline grading does not require the Codex executable, account login, API credentials, or a network connection once dependencies are installed.

For a fresh analysis environment, use Python 3.13.7 and install `requirements-analysis.txt` into a new virtual environment. Then run, from the extracted study directory:

```sh
python -m pytest -q test_calibration.py test_audits.py
python verify_results.py
python build_report.py
python check_defining_equations.py --recompute
python verify_proof_spot_check.py
python repeat_diagnostics.py
python catalog_failures.py
python plot_results.py
```

`build_report.py` also writes `ENTRY_DIAGNOSTICS.json`, `STAGE_DIAGNOSTICS.json`, `consistency_hard_recovered.json`, and the explicitly exploratory `ALL_SUCCESS_BOUNDS.json`. `analysis_symbolic_only.json` excludes manual and semantic-origin judgments. `PROOF_SPOT_CHECK.md` documents a correct final answer with an invalid derivation; the accompanying Python script reproduces its Pauli-matrix and integration-by-parts checks.

The study `MANIFEST.sha256` records the sealed evidence bytes. `BUNDLE_VERIFICATION.json` records the ZIP SHA-256, member count, CRC check, and byte comparisons, and is deliberately outside the archive/manifest to avoid a recursive hash dependency. Re-running reporting changes generated timestamps and can alter recorded timing fields; perform replay in an extracted working copy and preserve the sealed archive. Do not call `study.py` as a script: its main function is the original preparation step and would overwrite draft/status files. Importing it for the supplied verification tools is safe.

The original-bank test suite was replayed in a byte-verified temporary copy: see `original_bank_test_output.txt`, `original_bank_tests.xml`, and `ORIGINAL_BANK_TEST_VERIFICATION.json`. The source release was checked before and after that replay. The hard-bank test output is `hard_bank_test_output.txt`.

`SEMANTIC_LABEL_REVIEW.json` records the primary evaluator's review of the closed-list anomaly-origin synonym rules. These semantic decisions and individually justified manual decisions remain excluded from the exact-recovery-only sensitivity analysis.

Historical preparation files such as `PROTOCOL_DRAFT.json` and `analysis_partial.json` are retained for provenance. The operative protocol is `PROTOCOL.json`; the final state is in `RUN_STATUS.json`, `VERIFICATION.json`, and `REPORT.md`.

`python case_studies.py` reproduces the three selected exact error witnesses in `CASE_STUDIES.md` and `CASE_STUDIES.json`. These examples are illustrative; error frequencies come from the complete response and stage tables.

`python verify_original_anomalies.py` reproduces the Hermitian gamma-matrix traces and action-variation sign checks for the two original-bank anomaly errors recorded in `ORIGINAL_ANOMALY_ERROR_CHECKS.json`. The pre-correction notation-audit snapshot and zero-change comparison for the joint density normalization are retained in `audit_snapshots/` and `JOINT_DENSITY_AUDIT_CHANGE.json`.
