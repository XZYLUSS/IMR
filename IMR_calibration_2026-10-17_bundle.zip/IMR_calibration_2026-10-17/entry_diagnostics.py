"""Exact hard-bank entry diagnostics; no imputation of omitted entries."""
import json, sys, collections
from fractions import Fraction
from study import ROOT, BANKS, jsonl, write_json
sys.path.insert(0, str(BANKS['hard']))
from core import solve, same
from grading import parse_response


def main():
    presentations = {r['prompt_id']: r for r in json.loads(
        (BANKS['hard'] / 'presentations.json').read_text())['presentations']}
    records = {r['run_id']: r for r in jsonl(ROOT / 'graded_hard.jsonl')}
    audits = {r['run_id']: r for r in jsonl(ROOT / 'hard_format_audit.jsonl')}
    results = []
    for plan in jsonl(ROOT / 'plan.jsonl'):
        if plan['bank'] != 'hard' or plan['arm'] != 'canonical':
            continue
        p = presentations[plan['prompt_id']]
        gold = solve(p['construction_cluster'], p['input'])
        row = records.get(plan['run_id'])
        answer, partial = {}, []
        if row and row['grade']['valid']:
            answer = parse_response(row['response'], gold)
        elif row and plan['run_id'] in audits:
            audit = audits[plan['run_id']]
            for key, value in audit.get('normalized_answer', {}).items():
                answer.update(parse_response(json.dumps({key: value}), {key: gold[key]}))
            partial = audit.get('partial_cells', [])
        flags = {}
        for key, target in gold.items():
            if hasattr(target, 'rows'):
                for i in range(target.rows):
                    for j in range(target.cols):
                        flags[(key, i, j)] = same(answer[key][i, j], target[i, j]) if key in answer else None
            else:
                flags[(key, None, None)] = same(answer[key], target) if key in answer else None
        for cell in partial:
            slot = (cell['coordinate'], cell['row'], cell['column'])
            assert slot in flags and flags[slot] is None
            flags[slot] = cell['correct']
        counts = {'correct': sum(v is True for v in flags.values()),
                  'wrong': sum(v is False for v in flags.values()),
                  'unresolved': sum(v is None for v in flags.values()),
                  'total': len(flags)}
        per_coordinate = {}
        for key in gold:
            values = [value for slot, value in flags.items() if slot[0] == key]
            per_coordinate[key] = ('wrong' if any(v is False for v in values) else
                                   'correct' if all(v is True for v in values) else 'unresolved')
        results.append({k: plan[k] for k in ('run_id', 'model', 'cluster', 'prompt_id', 'replicate')} | counts | {'coordinate_status': per_coordinate})
    summaries = []
    arity = json.loads((ROOT / 'answer_arity_hard.json').read_text())
    for model in sorted({r['model'] for r in results}):
        for cluster in ['ALL', 'QD', 'LG', 'AN', 'AM', 'BV', 'TN']:
            rows = [r for r in results if r['model'] == model and (cluster == 'ALL' or r['cluster'] == cluster)]
            counts = {key: sum(r[key] for r in rows) for key in ('correct', 'wrong', 'unresolved', 'total')}
            assert counts['correct'] + counts['wrong'] + counts['unresolved'] == counts['total']
            assert counts['total'] == 4 * sum(r['scalar_slots_or_labels'] for r in arity
                                               if cluster == 'ALL' or r['cluster'] == cluster)
            summaries.append({'model': model, 'cluster': cluster, **counts,
                              'lower_exact': str(Fraction(counts['correct'], counts['total'])),
                              'upper_exact': str(Fraction(counts['correct'] + counts['unresolved'], counts['total']))})
    write_json(ROOT / 'ENTRY_DIAGNOSTICS.json', {
        'scope': 'four canonical repetitions; post-observation exact recovery; polynomial expressions count as one entry; no missing-entry imputation',
        'summaries': summaries, 'records': results})
    stages = collections.defaultdict(collections.Counter)
    for row in results:
        for coordinate, status in row['coordinate_status'].items():
            stages[(row['model'], row['cluster'], coordinate)][status] += 1
    write_json(ROOT / 'STAGE_DIAGNOSTICS.json', {
        'scope': 'canonical repetitions; native values plus explicit exact recovery',
        'interpretation': 'Output-coordinate errors localize failed quantities; they do not identify the internal cause of a model error. A partial coordinate with one explicit wrong entry is wrong; otherwise an incomplete coordinate is unresolved.',
        'summaries': [{'model': key[0], 'cluster': key[1], 'coordinate': key[2],
                       'correct': value['correct'], 'wrong': value['wrong'],
                       'unresolved': value['unresolved'], 'planned': sum(value.values())}
                      for key, value in sorted(stages.items())]})
    print('entry diagnostics', len(results), 'planned canonical responses')


if __name__ == '__main__':
    main()
