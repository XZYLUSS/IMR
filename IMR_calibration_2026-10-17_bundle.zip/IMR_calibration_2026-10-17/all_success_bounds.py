"""Exploratory all-success lower bounds; independent, non-identical generations."""
import json
from fractions import Fraction
from study import ROOT, write_json


def cell_bound(correct, planned, unresolved, alpha=Fraction(1, 20), comparisons=4):
    tail = alpha / comparisons
    all_success = correct == planned and unresolved == 0
    lower = float(tail) ** (1 / planned) if all_success else 0.0
    return {'applies': all_success, 'correct': correct, 'planned': planned,
            'unresolved': unresolved, 'family_alpha_exact': str(alpha),
            'comparisons': comparisons, 'per_cell_tail_exact': str(tail),
            'lower_exact_expression': f'({tail})**(1/{planned})' if all_success else '0',
            'conditional_lower_bound': lower,
            'lower_strictly_above_95_percent': bool(all_success and Fraction(19, 20) ** planned < tail),
            'lower_strictly_above_90_percent': bool(all_success and Fraction(9, 10) ** planned < tail),
            'max_expected_original_minus_this_bank_drop': 1 - lower}


def main():
    data = json.loads((ROOT / 'analysis_adjudicated.json').read_text())
    rows = []
    for model, scopes in data['results'].items():
        for bank in ['original', 'hard']:
            cell = scopes['canonical'][bank]
            rows.append({'model': model, 'bank': bank, **cell_bound(
                cell['correct'], cell['planned'],
                sum(cell['categories'].get(key, 0) for key in
                    ['format_error', 'label_ambiguity', 'apparatus', 'truncated', 'refusal']))})
    write_json(ROOT / 'ALL_SUCCESS_BOUNDS.json', {
        'status': 'exploratory post-observation supplementary family; not the predeclared Hoeffding analysis',
        'assumptions': 'independent generations and valid answer classifications on the fixed prompts; no identical-distribution assumption',
        'simultaneity': 'four canonical model-bank cells at alpha=0.05; not a joint guarantee with other analysis families',
        'results': rows})


if __name__ == '__main__':
    main()
