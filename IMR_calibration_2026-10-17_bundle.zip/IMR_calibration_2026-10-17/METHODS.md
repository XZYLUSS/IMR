# Matched empirical calibration: methods and limits

## Question and estimands

The experiment measures the performance of two specified model aliases on the frozen, repaired original bank and the frozen hard-v2 candidate. It does not estimate a population of independently sampled mathematical families. Both banks contain 24 instances in six modules; the hard bank has six construction templates. Presentations and parameter instances from one template are not treated as independently sampled families.

For a model, bank, and administered prompt, a fresh session produces one response. The primary observed score is the fraction of correct **complete typed answers** over 24 canonical instances, each administered four times (96 responses per bank and model). The secondary score uses exactly one pass over the four shared arms (canonical, T1, T2, paraphrase), also 96 responses per bank and model. The extra hard-bank composition arm has 24 responses per model and is reported separately. It has no original-bank comparator. Canonical repeats are not mixed into the secondary score. The total prospective schedule is 720 responses. Repeated outcomes are retained, including repeated errors.

The user authorized `gpt-6.1-sol` and `gpt-6-luna`, high reasoning, using the existing Codex allowance. Randomization uses seed 20261017 to interleave banks and models within complete blocks. This seed orders requests; it is not a model sampling seed. Protocol and inference configuration were frozen before the first benchmark response. Arithmetic and apparatus preflights are excluded from benchmark counts.

A useful reduction in the **observed operational ceiling** was prospectively defined as original accuracy at least 0.95, hard accuracy at most 0.85, and a drop of at least 0.10 after accounting for uncertain outcomes. Hard accuracy below 0.20 is flagged as possible floor saturation. These are study design choices, not theorems or universal definitions. Showing an accuracy drop alone is weaker than demonstrating a useful range of difficulty. Exact symbolic certificates certify reference mathematics; they cannot certify model difficulty.

## What is matched

The same requested model alias, high reasoning setting, neutral instructions, ephemeral-session policy, tool restrictions, service defaults, 600-second per-attempt wall timeout, and scheduling procedure are applied to both banks. Only the public `presentation` or `prompt` string is supplied, verbatim. Gold-containing family artifacts, certificates, evaluator code, and answers to other presentations are never included in the benchmark input. Evaluation and gold comparison run in separate processes after model responses are recorded.

Each session uses an empty temporary working directory, ignores user configuration, and disables memories, model-generated shell use, browser access, apps, plugins and delegation where supported. Parent `CODEX_*` environment entries are removed except an existing `CODEX_HOME`; authentication remains in its normal location and is not copied into the result bundle. The common instruction file requests no tools. The CLI still registers some tool interfaces despite these switches. Thus the enforceable criterion is **no observed tool calls**, not a claim that every possible tool schema disappeared. The runner rejects every non-message/non-reasoning event item, stops the process, and records an apparatus violation. The code-mode host is disabled and reports failure closed. Preflight self-reports are supporting diagnostics, not proof of inaccessible hidden server context.

The local CLI headers confirmed each requested model alias and `high` reasoning. An immutable serving model revision is not exposed in response events. Temperature, sampling seed, and maximum output-token cap are also not independently exposed. Identical service defaults are requested; exact API-style token-budget matching or immutable snapshot pinning is **not established**. Raw event logs retain reported input, cache, output, and reasoning token counts. Wall time includes startup and service latency, so it is an apparatus limit rather than a pure compute budget.

The original public prompts request explanations and final-answer lines; the hard public prompts request JSON. Answer dimensionality and problem content differ. Consequently, the comparison concerns the two administered instruments, not an identified causal effect of mathematical complexity alone. In particular, original AM concerns anomalies while hard AM concerns finite-dimensional Gaussian measures; every main comparison has a preplanned AM-excluded sensitivity analysis. Original and hard instance numbers do not define paired identical questions; no paired-item or McNemar test is used.

## Response preservation and missingness

Each attempt saves its exact question, invocation, raw event stream, stderr, final response, timestamps, process exit status, usage, and SHA-256 hashes. Completed wrong answers and format failures are never retried. At most one retry is allowed for an apparatus error with no completed response. Both attempts remain available. A wall timeout, tool violation, provider failure, incomplete dispatch, or allowance exhaustion is not a mathematical failure. The runner checkpoints and stops dispatch after repeated infrastructure failures; it does not stop on accuracy.

The transcript hashes protect integrity within this local record. They do not independently attest the provider's hidden computation or constitute a cryptographic proof of remote model identity.

## Grading and adjudication

The frozen native original parser/equality kernel and the hard bank's bounded, non-evaluating JSON/AST parser and exact SymPy comparison produce the strict scores. Answer coordinates are also scored separately. Mechanism/witness keyword flags in the old grader are not proof verification and do not enter correctness here. A correct typed answer does not imply that every sentence of an accompanying derivation is correct.

The old grader sometimes compares symbolic labels as strings. A native rejection of equivalent notation or a prose description of an anomaly therefore requires adjudication; it is not automatically a mathematical error. Such unresolved cases enter the uncertainty set. The hard parser can also reject a mathematically correct answer because it is wrapped in a code fence or copies the displayed schema metadata. Any additional format recovery or semantic adjudication is explicitly reported as a sensitivity analysis, with the native score preserved. Post-observation rules and manual judgments must be distinguished from the prospective strict analysis. No response may be rewritten to match a gold value.

Synthetic reference-answer and malformed-answer fixtures test the evaluator only; they never enter empirical model results. Frozen bank manifests are verified before and after the study.

## Conservative finite-record bounds

For bank b, let n_b be the fixed planned count, c_b the number of verified correct responses, and u_b the number whose mathematical correctness is unresolved because of formatting, label ambiguity, truncation, refusal, or apparatus missingness. Provided other responses are correctly classified as wrong, the observed mathematical-answer success fraction lies in

    L_b = c_b / n_b <= p_observed,b <= U_b = (c_b + u_b) / n_b.

Thus the observed original-minus-hard difference is contained in

    [ L_original - U_hard, U_original - L_hard ].

This deterministic interval does not assume independent instances, random sampling, or binomial trials. Its width transparently shows whether formatting or missingness could explain the apparent drop. It is a bound on unresolved observed outcomes, not a confidence interval for a latent reasoning ability. If an apparent mathematical error or native correctness is misgraded, the bound must be revised.

## Conditional sampling uncertainty

A supplementary one-sided Hoeffding bound is supplied only under an explicit assumption: independent model generations with valid grading on the fixed prompts. Identical distribution across prompts is not needed. Let X_i,Y_j be Bernoulli answer-success indicators for the two banks, and let Delta be the difference of their average success probabilities over the administered fixed prompts. For D = mean(X)-mean(Y), the sum of squared ranges of its summands is 1/n_original + 1/n_hard. Hoeffding's inequality gives

    Pr[D - Delta >= epsilon]
      <= exp(-2 epsilon^2 / (1/n_original + 1/n_hard)).

Replacing D by the smaller conservative observed drop L_original-U_hard preserves a lower-bound guarantee. For K=8 planned model/scope comparisons and familywise alpha=0.05, a union bound gives the simultaneous conditional lower bounds

    Delta >= L_original - U_hard
             - sqrt( (1/2)(1/n_original + 1/n_hard) log(K/alpha) ).

The eight comparisons are two models times canonical/shared-arm scopes, with and without AM. Their overlap does not invalidate the union bound; independence is required within each model-generation comparison, not between the eight bounds. The maximum with -1 is taken since an accuracy difference cannot be smaller than -1. This is deliberately conservative and not a test treating 24 related instances as independent sampled families. Provider dependence or unobserved configuration changes can invalidate the sampling interpretation. The unconditional finite-record interval remains descriptive. Neither this bound nor the observed ceiling rule establishes a population-wide absence of saturation.

Reference: W. Hoeffding, “Probability Inequalities for Sums of Bounded Random Variables,” *Journal of the American Statistical Association* **58** (301), 13–30 (1963), [doi:10.1080/01621459.1963.10500830](https://doi.org/10.1080/01621459.1963.10500830). The displayed specialization and multiple-comparison union-bound argument are derived above.

## Implementation references

The CLI interface and configuration behavior were checked against the installed CLI's help output and OpenAI's official documentation: [non-interactive mode](https://learn.chatgpt.com/docs/non-interactive-mode) and [configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference). The bank-local certificates and grading implementations are the primary executable references for answer mathematics. Their exact source manifests are recorded in `PROTOCOL.json`; original and hard releases are preserved unchanged.

## Post-observation audit rules

`audit_hard.py` preserves the native score and separately decodes a single JSON object, strips one code fence, and unwraps a unique `value`, `values`, `data`, `entries`, `matrix`, or `result` field. Nested arrays mistakenly written under a `shape` metadata key can be interpreted as explicit matrix entries. A metadata dimension pair such as `[3,1]` is never interpreted as an answer vector. Exact integer JSON numbers may be converted to strings; floating-point numbers are not rationalized. Missing scalar values are not inferred, even when a relation to other coordinates would make them easy to compute. An explicit, parseable wrong entry is retained as an exact mismatch witness even if other entries are missing. This audit can distinguish a formatting-only rejection from an actual arithmetic error, but cannot fill an omitted answer.

`audit_original.py` uses bounded arithmetic ASTs to compare elementary expressions such as `pi**2/6` with `pi^2/6`, and verifies endpoint differences symbolically against the published boundary primitive. For example, it compares an explicitly returned `B(b)-B(a)` to the same expression obtained by independent endpoint substitution in the gold primitive; it does not merely remove endpoint labels. Boolean label casing, unordered finite sets, and a limited list of anomaly-origin synonyms are checked separately. Semantic synonym decisions remain available for manual inspection and are not claims to have mechanically certified an entire derivation.

For the terminology used in the AM audit, see M. J. Duff, [“Twenty Years of the Weyl Anomaly”](https://arxiv.org/abs/hep-th/9308075), *Classical and Quantum Gravity* **11**, 1387–1404 (1994), and K. Fujikawa, [“Path integral for gauge theories with fermions”](https://doi.org/10.1103/PhysRevD.21.2848), *Physical Review D* **21**, 2848 (1980), erratum **22**, 1499 (1980). The references support the Weyl/conformal-anomaly terminology and the role of the fermion measure Jacobian; bank-specific numerical conventions are taken from the frozen prompts and certificates.

An omitted required coordinate is a failure to complete the administered task. Granting it possible credit in the optimistic upper bound does **not** mean the missing answer has been reconstructed or that the response is complete. This deliberate benefit-of-the-doubt bound asks whether a bank difference survives even if every unresolved format/incompleteness case were credited. It is not an estimate of unobserved mathematical knowledge. The strict and recovered-complete answer counts remain the directly verified successes.

Additional exact-recovery rules handle explicitly supplied constant rational arithmetic (bounded AST evaluation, no names or calls), scalar expressions placed under a `shape` key, and flat lists whose declared target is a column of the same length. These operations preserve the submitted values and order. They never calculate an omitted determinant, scalar pairing, or missing jet coefficient from other fields. Symbolic placeholders such as `det(M)` or undefined `m22` remain unresolved. The native rational-string/array contract is unchanged.

Operational threshold decisions and finite-record interval endpoints are computed as exact rational numbers. JSON outputs preserve the exact fractions and an exact symbolic expression for each conditional Hoeffding lower bound. Percentages and numerical confidence-bound evaluations in the readable report are rounded for display; display rounding does not determine decisions.


## Exploratory all-success bound

A supplementary analysis added after observing the first pass addresses the ceiling when every response in a canonical cell is verified correct. It is not part of the predeclared Hoeffding analysis. There are four canonical model-bank cells, each with fixed n=96. For independent Bernoulli generations with possibly different success probabilities p_i, let p_bar=(sum p_i)/n. Then

    Pr(all n succeed) = product p_i <= p_bar**n.

The product inequality follows by maximizing the product at fixed sum: replacing any unequal positive pair a,b by their common average increases its product because ((a+b)/2)^2-ab=(a-b)^2/4. Compactness gives a maximum; an interior maximum therefore has all entries equal, while a zero-product boundary cannot exceed the equal-point product. This proves the displayed bound without an identical-distribution assumption.

Define L=(alpha/K)^(1/n) when all n answers are verified correct, and L=0 otherwise. If p_bar<L, the probability that this rule returns L rather than zero is at most p_bar^n<alpha/K. A union bound over the K=4 canonical cells therefore supplies simultaneous one-sided 95% lower bounds for that four-cell family. At n=96, L=(1/80)^(1/96), approximately 0.9554. Decisions that L exceeds 0.95 or 0.90 use exact comparisons of rational powers, not rounded decimals. If the hard-bank mean is at least L, its expected drop from any original-bank mean bounded by one is at most 1-L.

This inference is conditional on independent generations and valid mathematical-answer classification. It is valid for unequal fixed-prompt success probabilities, but not established under arbitrary provider dependence. Its four-cell simultaneity is separate from the predeclared eight-comparison Hoeffding family and other sensitivities; no joint 95% guarantee across all reported families is asserted. The method and its post-observation timing are recorded in `ALL_SUCCESS_BOUNDS.json` and `AUDIT_CHANGELOG.md`. A perfect observed cell alone remains a finite-bank observation without the independence assumption.


The primary evaluator had access to the frozen reference answers and developed the notation/format audit after observing responses. This is an unblinded development calibration. Fresh test sessions received only public problem text, but pretraining contamination and hidden provider context were not measured. No untouched construction holdout or independent mathematical reviewer was introduced by this run. The frozen candidate's confirmatory-admission flags therefore remain unchanged.

The CLI emits nonfatal event notices for the experimental `skip_host_skill_discovery` switch and the deliberately disabled code-mode host. These messages are retained and counted in `VERIFICATION.json`. A completed inference with these notices is distinguished from a model-call failure, timeout, or observed tool invocation. Verification also requires a distinct session ID for every completed benchmark run and exact agreement between the final message event, saved response, aggregate record, and reported usage.
