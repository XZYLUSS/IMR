"""Three selected exact error witnesses; illustrative, not an error-frequency sample."""
import sys, json
import sympy as sp
from study import ROOT, BANKS, jsonl, write_json
sys.path.insert(0, str(BANKS['hard']))
from core import solve, pack
from grading import parse_response


def main():
    rows = {r['run_id']: r for r in jsonl(ROOT / 'graded_hard.jsonl')}
    audits = {r['run_id']: r for r in jsonl(ROOT / 'hard_format_audit.jsonl')}
    presentations = {r['prompt_id']: r for r in json.loads(
        (BANKS['hard'] / 'presentations.json').read_text())['presentations']}
    ids = ['01c80dcd8b9ef741eabe38d7', '1b5a46c506d53b62c11e3c01', '84d4f36cbd98c8adca332693']
    cases = []
    for rid in ids:
        r = rows[rid]
        p = presentations[r['prompt_id']]
        gold = solve(p['construction_cluster'], p['input'])
        answer = parse_response(r['response'], gold) if r['grade']['valid'] else parse_response(
            json.dumps(audits[rid]['normalized_answer']), gold)
        case = {key: r[key] for key in ['run_id', 'prompt_id', 'model', 'replicate', 'response_sha256', 'artifact_directory']}
        if rid == ids[0]:
            assert answer['holonomy'] == gold['holonomy']
            assert answer['resolvent_det'] == gold['resolvent_det']
            source = sp.Matrix(p['input']['source'])
            implied = (sp.eye(3) - answer['holonomy']) * answer['response']
            assert source == sp.Matrix([2,-3,4]) and implied == sp.Matrix([2,-3,8])
            case.update(kind='driven_equation_residual', supplied_source=pack(source),
                        implied_source=pack(implied), exact_residual=pack(implied-source),
                        interpretation='Correct holonomy and resolvent determinant; the reported vector solves a different right-hand side. This does not establish the internal cause of the error.')
        elif rid == ids[1]:
            assert answer['periods'] == gold['periods'] and answer['fluxes'] == gold['fluxes']
            pairing = (answer['periods'].T * answer['fluxes'])[0]
            assert pairing == 492 and answer['pairing'] == 496
            case.update(kind='inconsistent_pairing', periods=pack(answer['periods']), fluxes=pack(answer['fluxes']),
                        pairing_of_submitted_vectors=str(pairing), submitted_pairing=str(answer['pairing']),
                        exact_residual=str(answer['pairing']-pairing),
                        interpretation='The period and flux vectors are correct, but the reported pairing contradicts their exact contraction. This is an arithmetic inconsistency in the submitted answer.')
        else:
            residual = sp.simplify(answer['jet'][4] - gold['jet'][4])
            assert residual == sp.Rational(79735,51230962944)
            assert all(answer['jet'][i] == gold['jet'][i] for i in range(4))
            case.update(kind='single_jet_coefficient', row_zero_based=4,
                        observed=str(answer['jet'][4]), expected=str(gold['jet'][4]), exact_residual=str(residual),
                        interpretation='The first four entries are correct. The fifth differs by a nonzero exact rational; an independent moment-generating-function certificate rejects it.')
        cases.append(case)
    write_json(ROOT / 'CASE_STUDIES.json', {'selection': 'post-observation illustrative cases; not a representative error-frequency sample', 'cases': cases})
    lines = ['# Exact error case studies', '',
             'These three cases were selected after observing responses. They illustrate verified output errors and do not estimate their frequency. The full catalogue and per-quantity counts remain the population descriptions for this administered study.', '',
             '## Sol: correct holonomy, wrong driven response', '',
             'For `IMR-H2-QD-002/canonical`, repetition 2, the submitted holonomy H and det(I-H) are correct. Exact multiplication of the submitted response x gives', '',
             '    (I-H)x = (2, -3, 8)^T,', '',
             'where the supplied source is (2, -3, 4)^T. The residual is therefore (0, 0, 4)^T. The output solves a different right-hand side; the recorded answer does not establish why the model made this error.', '',
             '## Luna: correct cohomology vectors, inconsistent pairing', '',
             'For `IMR-H2-LG-001/canonical`, repetition 1, exact wrapper recovery gives the correct periods p=(16,-2,18)^T and fluxes f=(10,23,21)^T. Their contraction is', '',
             '    p^T f = 16*10 - 2*23 + 18*21 = 492.', '',
             'The submitted pairing is 496. Thus the answer is internally inconsistent even after its formatting is recovered. This demonstrates an arithmetic error without requiring an inference about its hidden reasoning.', '',
             '## Sol: one incorrect transformed asymptotic coefficient', '',
             'For `IMR-H2-AN-004/T1`, repetition 1, the first four jet entries are correct. The fifth is 413711685452059/104921012109312; its certified value is 413711522154779/104921012109312. Their difference is exactly 79735/51230962944, which is nonzero. The independent exponential-moment calculation in the bank certificate also rejects this answer.', '',
             '## Provenance and replay', '',
             'Run `python case_studies.py` to reproduce the matrix, contraction, and rational-residual checks with SymPy. Mathematical definitions and transport proofs are in [the frozen hard-bank proof document](../IMR_hard_bank_v2/DESIGN_AND_PROOFS.md).']
    for case in cases:
        lines.append(f"\n- `{case['run_id']}`: [raw response]({case['artifact_directory']}/response.txt); response SHA-256 `{case['response_sha256']}`.")
    (ROOT / 'CASE_STUDIES.md').write_text('\n'.join(lines)+'\n')
    print('three exact case studies verified')


if __name__ == '__main__':
    main()
