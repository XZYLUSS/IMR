# Exact error case studies

These three cases were selected after observing responses. They illustrate verified output errors and do not estimate their frequency. The full catalogue and per-quantity counts remain the population descriptions for this administered study.

## Sol: correct holonomy, wrong driven response

For `IMR-H2-QD-002/canonical`, repetition 2, the submitted holonomy H and det(I-H) are correct. Exact multiplication of the submitted response x gives

    (I-H)x = (2, -3, 8)^T,

where the supplied source is (2, -3, 4)^T. The residual is therefore (0, 0, 4)^T. The output solves a different right-hand side; the recorded answer does not establish why the model made this error.

## Luna: correct cohomology vectors, inconsistent pairing

For `IMR-H2-LG-001/canonical`, repetition 1, exact wrapper recovery gives the correct periods p=(16,-2,18)^T and fluxes f=(10,23,21)^T. Their contraction is

    p^T f = 16*10 - 2*23 + 18*21 = 492.

The submitted pairing is 496. Thus the answer is internally inconsistent even after its formatting is recovered. This demonstrates an arithmetic error without requiring an inference about its hidden reasoning.

## Sol: one incorrect transformed asymptotic coefficient

For `IMR-H2-AN-004/T1`, repetition 1, the first four jet entries are correct. The fifth is 413711685452059/104921012109312; its certified value is 413711522154779/104921012109312. Their difference is exactly 79735/51230962944, which is nonzero. The independent exponential-moment calculation in the bank certificate also rejects this answer.

## Provenance and replay

Run `python case_studies.py` to reproduce the matrix, contraction, and rational-residual checks with SymPy. Mathematical definitions and transport proofs are in [the frozen hard-bank proof document](../IMR_hard_bank_v2/DESIGN_AND_PROOFS.md).

- `01c80dcd8b9ef741eabe38d7`: [raw response](runs/01c80dcd8b9ef741eabe38d7/attempt_1/response.txt); response SHA-256 `261a60beaee4e083d878681a71aa8ef82d1adc05f89c5153c1be784f03dc149f`.

- `1b5a46c506d53b62c11e3c01`: [raw response](runs/1b5a46c506d53b62c11e3c01/attempt_1/response.txt); response SHA-256 `9c2f1f2836bed98e399aa33508fbf5fa4788c1caabd71ee534a40bb01e12f039`.

- `84d4f36cbd98c8adca332693`: [raw response](runs/84d4f36cbd98c8adca332693/attempt_1/response.txt); response SHA-256 `821b6d4d69dffd9cabd747991198e13c18e5ba295c1e6d0fae68f716b3d3aebd`.
