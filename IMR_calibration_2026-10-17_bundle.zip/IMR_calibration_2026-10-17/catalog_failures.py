import json,collections
from study import ROOT,jsonl

def main():
 rows=jsonl(ROOT/'graded_original.jsonl')+jsonl(ROOT/'graded_hard.jsonl')
 audits={r['run_id']:r for f in ['original_notation_audit.jsonl','hard_format_audit.jsonl'] for r in jsonl(ROOT/f)}
 manual={r['run_id']:r for r in jsonl(ROOT/'manual_adjudications.jsonl')} if (ROOT/'manual_adjudications.jsonl').exists() else {}
 failures=[r for r in rows if not r['grade']['correct']]
 lines=['# Complete native-failure catalogue','',f'{len(failures)} native failures among {len(rows)} recorded responses. Some are mathematically correct after explicit notation/format adjudication. This catalogue retains all native failures.','', 'The structured audit JSONL files contain complete exact mismatch witnesses; the short excerpts below are for navigation.','']
 for model in ['gpt-6.1-sol','gpt-6-luna']:
  lines+=['## '+model,'']
  for bank in ['original','hard']:
   for cluster in ['QD','LG','AN','AM','BV','TN']:
    rr=[r for r in failures if r['model']==model and r['bank']==bank and r['cluster']==cluster]
    if not rr:continue
    lines+=['### '+bank+' / '+cluster,'']
    for r in sorted(rr,key=lambda x:(x['prompt_id'],x['replicate'])):
     a=audits.get(r['run_id'],{});m=manual.get(r['run_id'],{});outcome=m.get('classification',a.get('classification','not adjudicated'))
     lines.append(f"- **{r['prompt_id']}, repetition {r['replicate']+1}** — native `{r['grade']['category']}`; audit `{outcome}`. [Raw response]({r['artifact_directory']}/response.txt), [attempt record]({r['artifact_directory']}/result.json).")
     witnesses=a.get('wrong_witnesses',r['grade'].get('wrong_witnesses',[]))
     if witnesses:
      w=witnesses[0];lines.append('  Exact mismatch example: '+json.dumps(w,sort_keys=True)[:600]+'.')
     if m:lines.append('  Manual rationale: '+m['reason'])
    lines.append('')
 (ROOT/'FAILURE_CATALOG.md').write_text('\n'.join(lines)+'\n')
 print('catalogued',len(failures),'native failures')
if __name__=='__main__':main()
