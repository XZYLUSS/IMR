"""Count declared answer scalar entries; labels/polynomials remain one entry each."""
import argparse,json,sys
from study import BANKS,ROOT,write_json
p=argparse.ArgumentParser();p.add_argument('--bank',choices=['original','hard'],required=True);a=p.parse_args();sys.path.insert(0,str(BANKS[a.bank]));rows=[]
if a.bank=='original':
 from families import build_corpus
 for fid,f in build_corpus().items():rows.append({'family_id':fid,'cluster':fid.split('-')[-2],'coordinates':len(f.coords),'scalar_slots_or_labels':len(f.coords),'note':'A set or symbolic label is counted as one declared coordinate.'})
else:
 from core import all_instances,solve
 for r in all_instances():
  gold=solve(r['construction_cluster'],r['input'])
  rows.append({'family_id':r['id'],'cluster':r['construction_cluster'],'coordinates':len(gold),'scalar_slots_or_labels':sum(v.rows*v.cols if hasattr(v,'rows') else 1 for v in gold.values()),'note':'Each polynomial or rational matrix entry counts once; algebraic complexity is not measured.'})
write_json(ROOT/f'answer_arity_{a.bank}.json',rows)
print(a.bank,len(rows),sum(r['scalar_slots_or_labels'] for r in rows))
