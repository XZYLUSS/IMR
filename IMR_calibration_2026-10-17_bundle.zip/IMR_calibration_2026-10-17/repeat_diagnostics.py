import collections,json
from study import ROOT,jsonl,write_json

def main():
 plan=jsonl(ROOT/'plan.jsonl');rows={r['run_id']:r for r in jsonl(ROOT/'graded_adjudicated.jsonl')};native={r['run_id']:r for b in ['original','hard'] for r in jsonl(ROOT/f'graded_{b}.jsonl')}
 groups=collections.defaultdict(list)
 for p in plan:
  if p['arm']=='canonical':groups[(p['model'],p['bank'],p['family_id'])].append(p)
 out=[]
 for (model,bank,fid),planned in sorted(groups.items()):
  observed=[rows[p['run_id']] for p in planned if p['run_id'] in rows];uncertain=sum(r['grade']['category'] in ['format_error','label_ambiguity','apparatus','refusal','truncated'] for r in observed)+len(planned)-len(observed)
  out.append({'model':model,'bank':bank,'family_id':fid,'planned_repetitions':4,'observed_repetitions':len(observed),'native_correct':sum(native[r['run_id']]['grade']['correct'] for r in observed),'audited_correct':sum(r['grade']['correct'] for r in observed),'unresolved':uncertain,'distinct_final_response_hashes':len({r['response_sha256'] for r in observed if r['status']=='completed'}),'repetition_outcomes':[{'replicate':r['replicate'],'category':r['grade']['category'],'run_id':r['run_id']} for r in sorted(observed,key=lambda x:x['replicate'])]})
 write_json(ROOT/'repeat_diagnostics.json',out)
 print('Canonical model/bank/instance groups',len(out))
if __name__=='__main__':main()
