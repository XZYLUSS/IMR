"""One process per bank prevents old/new modules named core from colliding."""
import argparse,json,sys
from pathlib import Path
from study import BANKS,jsonl

def grader(bank):
 sys.path.insert(0,str(BANKS[bank]))
 if bank=='original':
  from families import build_corpus
  corpus=build_corpus()
  def evaluate(pid,raw):
   fid,arm=pid.split('/');family=corpus[fid]
   gold=family.canonical_gold if arm in ('canonical','paraphrase') else next(t.transported_gold for t in family.transforms if t.tid==arm)
   if not isinstance(raw,str) or len(raw.encode())>262144:return {'valid':False,'correct':False,'reason':'empty or excessive response'}
   parsed=family.normalizer(raw)
   if parsed is None:return {'valid':False,'correct':False,'reason':'native parser rejected response'}
   answer,flags=parsed
   components={key:family.eqf({**gold,key:answer[key]},gold) for key in family.coords}
   if fid=='IMR-AM-002':
    from families import _am_normal
    components={'physical_density':_am_normal(answer['coeff_num'],answer['structure'])==_am_normal(gold['coeff_num'],gold['structure']),'origin':answer['origin']==gold['origin']}
   return {'valid':True,'correct':family.eqf(answer,gold),'component_correct':components,'normalized_answer':{key:str(value) for key,value in answer.items()},'type_spec':family.type_spec,'weak_text_cues':flags,'reason':'frozen native equality kernel; text cues do not certify proofs'}
  return evaluate
 from core import solve,same,pack
 from grading import grade,parse_response
 index={row['prompt_id']:row for row in json.loads((BANKS['hard']/'presentations.json').read_text())['presentations']}
 def evaluate(pid,raw):
  row=index[pid];gold=solve(row['construction_cluster'],row['input']);result=grade(raw,gold)
  if result['valid']:
   answer=parse_response(raw,gold);result['component_correct']={key:same(answer[key],value) for key,value in gold.items()};result['normalized_answer']=pack(answer)
   result['scalar_entry_counts']={key:{'correct':sum(same(answer[key][i,j],value[i,j]) for i in range(value.rows) for j in range(value.cols)),'total':value.rows*value.cols} if hasattr(value,'rows') else {'correct':int(same(answer[key],value)),'total':1} for key,value in gold.items()}
   if not result['correct']:
    import sympy as sp
    witnesses=[]
    for key,target in gold.items():
     entries=[(i,j,answer[key][i,j],target[i,j]) for i in range(target.rows) for j in range(target.cols)] if hasattr(target,'rows') else [(None,None,answer[key],target)]
     for i,j,observed,expected in entries:
      if not same(observed,expected):witnesses.append({'coordinate':key,'row':i,'column':j,'observed':str(observed),'expected':str(expected),'exact_residual_observed_minus_expected':str(sp.simplify(observed-expected))})
    result['wrong_witnesses']=witnesses
  return result
 return evaluate

def main():
 p=argparse.ArgumentParser();p.add_argument('--bank',choices=list(BANKS),required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args();evaluate=grader(args.bank)
 out=[]
 for record in jsonl(args.input):
  if record['bank']!=args.bank:continue
  status=record.get('status','missing')
  if status not in ('completed','truncated','refusal'):
   result={'valid':False,'correct':False,'reason':'unobserved apparatus outcome','category':'apparatus'}
  elif status=='truncated':result={'valid':False,'correct':False,'reason':'generation budget exhausted','category':'truncated'}
  elif status=='refusal':result={'valid':False,'correct':False,'reason':'provider refusal','category':'refusal'}
  else:
   result=evaluate(record['prompt_id'],record.get('response',''));result['category']='correct' if result['correct'] else 'mathematical_or_native_label_error' if result['valid'] else 'format_error'
  if args.bank=='original' and result.get('valid') and not result.get('correct') and any(result.get('type_spec',{}).get(k)=='label' and not ok for k,ok in result.get('component_correct',{}).items()):
   result['category']='label_ambiguity'
  out.append({**record,'grade':result})
 args.output.write_text(''.join(json.dumps(row,sort_keys=True)+'\n' for row in out))
if __name__=='__main__':main()
