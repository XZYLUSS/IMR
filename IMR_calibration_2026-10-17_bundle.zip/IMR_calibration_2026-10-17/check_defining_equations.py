"""Check complete submitted answers against bank-local defining-equation certificates.
This shares SymPy and bank utilities, but checks equations rather than only solve()==answer.
"""
import argparse,json,sys,time,hashlib
from study import ROOT,BANKS,jsonl,write_json
sys.path.insert(0,str(BANKS['hard']))
from core import solve,pack
from grading import parse_response
from certificates import mathematical_checks,CertificateFailure

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--recompute',action='store_true');args=ap.parse_args()
 from study import verify_banks
 verify_banks()
 index={r['prompt_id']:r for r in json.loads((BANKS['hard']/'presentations.json').read_text())['presentations']}
 audits={r['run_id']:r for r in jsonl(ROOT/'hard_format_audit.jsonl')};cache={}
 cachefile=ROOT/'defining_equation_cache.json'
 if cachefile.exists() and not args.recompute:cache=json.loads(cachefile.read_text())
 results=[]
 for r in jsonl(ROOT/'graded_hard.jsonl'):
  pid=r['prompt_id'];p=index[pid];gold=solve(p['construction_cluster'],p['input']);a=audits.get(r['run_id'])
  if r['grade']['valid']:
   answer=parse_response(r['response'],gold);expected=r['grade']['correct'];source='native_parsed'
  elif a and a.get('normalized_answer',{}).keys()==gold.keys():
   answer=parse_response(json.dumps(a['normalized_answer']),gold);expected=a['classification']=='correct_after_format_recovery';source='complete_format_recovered'
  else:
   results.append({'run_id':r['run_id'],'prompt_id':pid,'status':'not_checked_incomplete_or_unparsed','reason':'No complete typed answer; missing entries are never supplied from gold.'});continue
  signature=hashlib.sha256(json.dumps([pid,pack(answer)],sort_keys=True).encode()).hexdigest()
  if signature not in cache:
   started=time.monotonic()
   try:
    checks=mathematical_checks(p['construction_cluster'],p['input'],answer);passed=True;reason='all defining-equation checks passed'
   except CertificateFailure as exc:checks=[];passed=False;reason=str(exc)
   cache[signature]={'passed':passed,'reason':reason,'checks':checks,'seconds':time.monotonic()-started}
   write_json(cachefile,cache)
  result=cache[signature]
  if result['passed']!=expected:raise AssertionError(('Disagreement between exact equality and defining equations',r['run_id'],result))
  results.append({'run_id':r['run_id'],'prompt_id':pid,'source':source,'status':'pass' if result['passed'] else 'rejected','cache_signature':signature,'reason':result['reason'],'checks':result['checks']})
 from collections import Counter
 report={'method':'bank-local defining-equation verification; shared SymPy/utilities, not an independent proof assistant','counts':dict(Counter(r['status'] for r in results)),'unique_answer_checks':len(cache),'results':results}
 write_json(ROOT/'DEFINING_EQUATION_CHECKS.json',report);print(json.dumps({k:v for k,v in report.items() if k!='results'}))
if __name__=='__main__':main()
