"""Resumable fixed-schedule runner; no outcome-dependent selection or gold access."""
import concurrent.futures,json,time
from collections import Counter
from study import ROOT,jsonl,sha,write_json
from backend import attempt,SETTINGS

def main():
 protocol=json.loads((ROOT/'PROTOCOL.json').read_text())
 for name,digest in protocol['hashes'].items():
  if sha((ROOT/name).read_bytes())!=digest:raise ValueError('Frozen input changed: '+name)
 plan=jsonl(ROOT/'plan.jsonl');settings_sha=sha((ROOT/'SETTINGS.json').read_bytes());out=ROOT/'responses.jsonl'
 records=jsonl(out) if out.exists() else [];done={r['run_id'] for r in records}
 if len(done)!=len(records):raise ValueError('Duplicate completion records')
 pending=[r for r in plan if r['run_id'] not in done];calls=sum(r.get('attempt',1) for r in records)
 def run(row):
  previous=sorted((ROOT/'runs'/row['run_id']).glob('attempt_*/result.json')) if (ROOT/'runs'/row['run_id']).exists() else []
  if previous:
   result=json.loads(previous[-1].read_text())
  else:result=attempt(row,1,settings_sha)
  if result['status']=='apparatus_error' and result['attempt']==1 and not result['response']:
   time.sleep(3);result=attempt(row,2,settings_sha)
  return result
 def checkpoint():
  write_json(ROOT/'RUN_STATUS.json',{'status':'running' if len(records)<len(plan) else 'schedule_complete','planned':len(plan),'recorded':len(records),'empirical_model_calls':sum(r.get('attempt',1) for r in records),'categories':dict(Counter(r['status'] for r in records)),'updated_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'protocol_sha256':sha((ROOT/'PROTOCOL.json').read_bytes())})
 checkpoint();consecutive_failures=0;iterator=iter(pending)
 with concurrent.futures.ThreadPoolExecutor(max_workers=SETTINGS['concurrency']) as pool:
  active={}
  for row in list(pending)[:SETTINGS['concurrency']]:active[pool.submit(run,row)]=row
  for _ in range(min(len(pending),SETTINGS['concurrency'])):next(iterator)
  while active:
   finished,_=concurrent.futures.wait(active,return_when=concurrent.futures.FIRST_COMPLETED)
   for future in finished:
    row=active.pop(future);result=future.result()
    with out.open('a') as stream:stream.write(json.dumps(result,sort_keys=True)+'\n');stream.flush()
    records.append(result);checkpoint();print(json.dumps({'recorded':len(records),'run_id':row['run_id'],'model':row['model'],'bank':row['bank'],'arm':row['arm'],'status':result['status'],'seconds':round(result['elapsed_seconds'],1)}),flush=True)
    consecutive_failures=consecutive_failures+1 if result['status']=='apparatus_error' else 0
    if consecutive_failures>=6:
     print('Stopping schedule dispatch after repeated apparatus failures; in-flight calls will finish.',flush=True);iterator=iter([])
    nextrow=next(iterator,None)
    if nextrow is not None:active[pool.submit(run,nextrow)]=nextrow
 checkpoint()
if __name__=='__main__':main()
