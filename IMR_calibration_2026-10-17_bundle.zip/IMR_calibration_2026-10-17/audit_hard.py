"""Post-observation format diagnostics. Never modifies native results or model inputs."""
import ast,json,sys,re,argparse
from pathlib import Path
from study import ROOT,BANKS,jsonl,write_json
sys.path.insert(0,str(BANKS['hard']))
from core import solve,same,pack
from grading import parse_response,parse_entry,InvalidResponse,unique_object

def unpack_wrapped(value):
 steps=[]
 if isinstance(value,dict):
  keys=[k for k in ('value','values','data','entries','matrix','result') if k in value]
  if len(keys)==1:value=value[keys[0]];steps.append('unwrap_'+keys[0])
  elif not keys and isinstance(value.get('shape'),list) and value['shape'] and all(isinstance(x,list) for x in value['shape']):
   value=value['shape'];steps.append('matrix_written_in_shape_metadata')
  elif not keys and isinstance(value.get('shape'),str):
   value=value['shape'];steps.append('scalar_expression_written_in_shape_metadata')
 while isinstance(value,list) and len(value)==1 and isinstance(value[0],list) and value[0] and all(isinstance(x,list) for x in value[0]):
  value=value[0];steps.append('remove_singleton_outer_array')
 # Integer JSON numbers have exact values; floats are never silently rationalized.
 def strings(x):
  if type(x) is int:return str(x)
  if isinstance(x,list):return [strings(v) for v in x]
  return x
 return strings(value),steps

def rational_expression(text):
 """Evaluate only bounded, explicit constant arithmetic with the bank's safe AST walker."""
 if not isinstance(text,str) or len(text)>24000:return text
 try:
  tree=ast.parse(text,mode='eval')
  if any(isinstance(n,(ast.Name,ast.Call,ast.Attribute,ast.Subscript)) for n in ast.walk(tree)):return text
  value=parse_entry(text,True)
  return str(value) if value.is_Rational else text
 except (InvalidResponse,SyntaxError,ValueError,TypeError,RecursionError):return text

def decode(raw):
 raw=raw.strip();steps=[]
 if raw.startswith('```') and raw.endswith('```'):
  raw=re.sub(r'^```(?:json)?\s*','',raw).removesuffix('```').strip();steps.append('remove_code_fence')
 try:return json.loads(raw,object_pairs_hook=unique_object),steps
 except (ValueError,RecursionError):return None,steps

def audit(raw,gold):
 data,steps=decode(raw)
 if not isinstance(data,dict):return {'classification':'unresolved_format','operations':steps}
 result={};wrong=[];partial=[];normalized={}
 for key,target in gold.items():
  value,ops=unpack_wrapped(data.get(key));steps.extend(key+':'+x for x in ops)
  if hasattr(target,'cols') and target.cols==1 and isinstance(value,list) and len(value)==target.rows and all(isinstance(x,str) for x in value):
   value=[[x] for x in value];steps.append(key+':flat_list_to_declared_column')
  if key not in ('euler','momentum','acceleration_momentum'):
   def normalize(x):return [normalize(v) for v in x] if isinstance(x,list) else rational_expression(x)
   before=value;value=normalize(value)
   if value!=before:steps.append(key+':bounded_exact_constant_arithmetic')
  try:
   parsed=parse_response(json.dumps({key:value}),{key:target})[key]
   result[key]=same(parsed,target);normalized[key]=pack(parsed)
   if not result[key]:wrong.append({'coordinate':key,'observed':pack(parsed),'expected':pack(target)})
  except (InvalidResponse,TypeError,ValueError):
   result[key]=None
   # An explicitly supplied, parseable wrong cell is evidence even if other cells are absent.
   if hasattr(target,'rows') and isinstance(value,list):
    for i,row in enumerate(value[:target.rows]):
     if not isinstance(row,list):continue
     for j,entry in enumerate(row[:target.cols]):
      try:cell=parse_entry(entry,key in ('euler','momentum','acceleration_momentum'))
      except (InvalidResponse,TypeError,ValueError):continue
      ok=same(cell,target[i,j]);partial.append({'coordinate':key,'row':i,'column':j,'correct':ok})
      if not ok:wrong.append({'coordinate':key,'row':i,'column':j,'observed':str(cell),'expected':str(target[i,j])})
 classification='explicit_mathematical_error' if wrong else 'correct_after_format_recovery' if all(v is True for v in result.values()) else 'unresolved_format'
 return {'classification':classification,'operations':steps,'coordinate_correct':result,'wrong_witnesses':wrong,'partial_cells':partial,'normalized_answer':normalized,'post_observation':True}

def main():
 index={r['prompt_id']:r for r in json.loads((BANKS['hard']/'presentations.json').read_text())['presentations']}
 output=[]
 for r in jsonl(ROOT/'graded_hard.jsonl'):
  if r['grade']['category']!='format_error':continue
  p=index[r['prompt_id']];gold=solve(p['construction_cluster'],p['input'])
  output.append({'run_id':r['run_id'],'model':r['model'],'prompt_id':r['prompt_id'],'replicate':r['replicate'],'response_sha256':r['response_sha256'],**audit(r['response'],gold)})
 (ROOT/'hard_format_audit.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in output))
 from collections import Counter
 print(dict(Counter(r['classification'] for r in output)))
if __name__=='__main__':main()
