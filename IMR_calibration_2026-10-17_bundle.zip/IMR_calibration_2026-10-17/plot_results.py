"""Publication-exportable plots of finite-record bounds, not IID-family confidence intervals."""
import os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'plot_cache'))
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

def main():
 native=json.loads((ROOT/'analysis_native.json').read_text());audit=json.loads((ROOT/'analysis_adjudicated.json').read_text())
 models=['gpt-6.1-sol','gpt-6-luna'];labels={'gpt-6.1-sol':'GPT-6.1 Sol','gpt-6-luna':'GPT-6 Luna'}
 colors=['#244b73','#5f9eaa','#f3d797','#e6e9ed']
 plt.rcParams.update({'font.size':11,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
 fig,ax=plt.subplots(figsize=(11,5.1));ys=[];names=[]
 for mi,model in enumerate(models):
  for bi,bank in enumerate(['original','hard']):
   y=mi*3+bi;ys.append(y);names.append(labels[model]+' · '+bank)
   n=native['results'][model]['canonical'][bank];a=audit['results'][model]['canonical'][bank];total=a['planned']
   counts=[n['correct'],a['correct']-n['correct'],round(a['accuracy_upper_if_uncertain_correct']*total)-a['correct'],total-round(a['accuracy_upper_if_uncertain_correct']*total)]
   left=0
   for k,count in enumerate(counts):
    width=count/total;ax.barh(y,width,left=left,height=.66,color=colors[k],edgecolor='white',hatch='///' if k==2 else None,label=['Native correct','Correct after audit','Unresolved','Verified wrong'][k] if y==0 else None)
    if width>=.07:ax.text(left+width/2,y,str(count),ha='center',va='center',color='white' if k==0 else '#182432',fontsize=10)
    left+=width
 ax.axvline(.95,color='#66524b',linestyle='--',lw=1,label='95% ceiling threshold')
 ax.set(yticks=ys,yticklabels=names,xlim=(0,1),xlabel='Fraction of the fixed canonical schedule (96 responses per bar)')
 ax.invert_yaxis();ax.xaxis.set_major_formatter(PercentFormatter(1));ax.grid(axis='x',alpha=.12);ax.set_axisbelow(True)
 status='COMPLETE' if audit['missing_records']==0 else f"INCOMPLETE: {audit['observed_records']}/720 recorded"
 ax.set_title('Canonical answer outcomes · '+status,loc='left',fontweight='bold',pad=16)
 ax.legend(loc='upper center',bbox_to_anchor=(.5,-.19),ncol=3,frameon=False,fontsize=10)
 fig.text(.015,.015,'Counts are printed inside sufficiently large segments. Audits are post-observation; unresolved cases are not scored as mathematical errors.',fontsize=9,color='#424952')
 fig.subplots_adjust(left=.22,right=.98,top=.87,bottom=.28)
 for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'canonical_outcomes.{ext}',dpi=220)
 plt.close(fig)
 fig,axes=plt.subplots(1,2,figsize=(11.5,5.5),sharey=True)
 for ax,model in zip(axes,models):
  for i,cluster in enumerate(['QD','LG','AN','AM','BV','TN']):
   for bank,offset,color in [('original',-.13,'#244b73'),('hard',.13,'#b36c30')]:
    a=audit['results'][model]['by_cluster'][cluster][bank];lo=a['accuracy_lower'];hi=a['accuracy_upper_if_uncertain_correct'];x=i+offset
    ax.plot([x,x],[lo,hi],color=color,lw=3,solid_capstyle='round');ax.scatter([x],[lo],marker='o',color=color,s=30,label=bank.title() if i==0 else None)
    if hi>lo:ax.scatter([x],[hi],marker='_',color=color,s=100)
  ax.axhline(.95,color='#777777',ls='--',lw=1);ax.axhline(.85,color='#aaaaaa',ls=':',lw=1)
  ax.set(xticks=range(6),xticklabels=['QD','LG','AN','AM*','BV','TN'],ylim=(-.04,1.05),title=labels[model],xlabel='Construction / module')
  ax.yaxis.set_major_formatter(PercentFormatter(1));ax.grid(axis='y',alpha=.15);ax.legend(loc='center right',frameon=False)
 axes[0].set_ylabel('Audited correct fraction and unresolved upper bound')
 fig.suptitle('Canonical performance by module · '+status,fontweight='bold',y=.98)
 fig.text(.06,.03,'Each module: 4 instances × 4 repetitions. Vertical segments span unresolved outcomes, not confidence intervals.\n*AM changes subject between banks; the report also excludes AM. Dashed lines: 95% ceiling; dotted lines: 85% target.',fontsize=9,color='#424952')
 fig.subplots_adjust(left=.08,right=.98,top=.87,bottom=.23,wspace=.14)
 for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'canonical_by_module.{ext}',dpi=220)
 plt.close(fig)
 print('Saved canonical outcome and module figures as PNG, PDF and SVG.')
if __name__=='__main__':main()
