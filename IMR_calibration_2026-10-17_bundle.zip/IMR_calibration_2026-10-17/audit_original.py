"""Post-observation original-bank notation audit, separate from native scoring."""
import ast,json,re,sys
import sympy as s
from study import ROOT,BANKS,jsonl
sys.path.insert(0,str(BANKS['original']))
from families import build_corpus
from core import make_parser
from boundary_contract import polynomial,case_set,_SYMBOLS

def exact_expression(text):
 if not isinstance(text,str) or len(text)>500:raise ValueError('bounded string required')
 text=text.replace('π','pi').strip().strip('$').replace('\\(','').replace('\\)','').replace('\\left','').replace('\\right','').replace('\\pi','pi').replace('\\lambda','lam').replace('lambda','lam').replace('\\cdot','*').replace('\\,','')
 for _ in range(6):
  text=re.sub(r'\\frac\{([^{}]+)\}\{([^{}]+)\}',r'((\1)/(\2))',text)
  text=re.sub(r'\\sqrt\{([^{}]+)\}',r'sqrt(\1)',text)
 text=re.sub(r'\^\{([^{}]+)\}',r'^(\1)',text).replace('^','**')
 text=re.sub(r'\s+','',text).replace('F_{01}','F01').replace('F_01','F01').replace('qF01','q*F01')
 text=re.sub(r'(?<=[0-9])(?=pi|lam|q|F01|\()', '*',text)
 text=re.sub(r'(?<=\))(?=pi|lam|q|F01|\()', '*',text)
 tree=ast.parse(text,mode='eval')
 if len(list(ast.walk(tree)))>100:raise ValueError('too large')
 names={'pi':s.pi,**{n:s.Symbol(n) for n in ['lam','q','F01']}}
 def walk(n):
  if isinstance(n,ast.Constant) and type(n.value) is int and abs(n.value)<10**30:return s.Integer(n.value)
  if isinstance(n,ast.Name) and n.id in names:return names[n.id]
  if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):return walk(n.operand)*(1 if isinstance(n.op,ast.UAdd) else -1)
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='sqrt' and len(n.args)==1 and not n.keywords:return s.sqrt(walk(n.args[0]))
  if isinstance(n,ast.BinOp):
   a,b=walk(n.left),walk(n.right)
   if isinstance(n.op,ast.Add):return a+b
   if isinstance(n.op,ast.Sub):return a-b
   if isinstance(n.op,ast.Mult):return a*b
   if isinstance(n.op,ast.Div) and b!=0:return a/b
   if isinstance(n.op,ast.Pow) and b.is_Rational and abs(b)<=8 and b.q<=8:return a**b
  raise ValueError('unsupported expression')
 return walk(tree.body)

def endpoint_polynomial(text):
 if not isinstance(text,str) or len(text)>700:raise ValueError('bounded endpoint polynomial required')
 text=re.sub(r'\s+','',text).replace('^','**');text=re.sub(r'(?<=\))(?=[A-Za-z])','*',text);names={}
 for variable in ('phi2','phi3','phi4','h1','h','xdot','x'):
  for end in ('a','b'):
   symbol=variable+'_'+end;names[symbol]=s.Symbol(symbol);text=text.replace(variable+'('+end+')',symbol)
 tree=ast.parse(text,mode='eval')
 if len(list(ast.walk(tree)))>140:raise ValueError('too large')
 def walk(n):
  if isinstance(n,ast.Name) and n.id in names:return names[n.id]
  if isinstance(n,ast.Constant) and type(n.value) is int and abs(n.value)<10000:return s.Integer(n.value)
  if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):return walk(n.operand)*(1 if isinstance(n.op,ast.UAdd) else -1)
  if isinstance(n,ast.BinOp):
   a,b=walk(n.left),walk(n.right)
   if isinstance(n.op,ast.Add):return a+b
   if isinstance(n.op,ast.Sub):return a-b
   if isinstance(n.op,ast.Mult):return a*b
   if isinstance(n.op,ast.Div) and b.is_Integer and b!=0:return a/b
  raise ValueError('unsupported endpoint expression')
 return s.expand(walk(tree.body))

def equivalent(key,value,target,fid):
 if value==target:return True,'native_value'
 if key in ('bulk','boundary_term'):
  if key=='boundary_term' and fid in ('IMR-BV-001','IMR-BV-002'):
   match=re.fullmatch(r'(?:integral_boundary|int_\{∂M\})(.+?)(dSigma_mu|dA_g)',value)
   expected_measure='dSigma_mu' if fid=='IMR-BV-002' else 'dA_g'
   if match and match.group(2)==expected_measure:
    integrand=match.group(1).replace('d^mu(phi)','dmu(phi)').replace('hdmu(phi)','h*dmu(phi)').replace('hdn(phi)','h*dn(phi)')
    try:return polynomial(integrand)==polynomial(target),'explicit_integrand_inside_boundary_integral'
    except (ValueError,TypeError):pass
  try:
   value_for_polynomial=re.sub(r'(?<=[0-9])(?=phi|h|m|w|x)', '*',value)
   value_for_polynomial=value_for_polynomial.replace('hdn(phi)','h*dn(phi)').replace('hdmu(phi)','h*dmu(phi)')
   if polynomial(value_for_polynomial)==polynomial(target):return True,'exact_published_polynomial_grammar'
  except (ValueError,TypeError):pass
  if key=='boundary_term' and fid in ('IMR-BV-003','IMR-BV-004'):
   bracket=re.fullmatch(r'\[(.*)\]_a\^b',value)
   if bracket:
    try:return polynomial(bracket.group(1))==polynomial(target),'exact_endpoint_bracket_notation'
    except (ValueError,TypeError):pass
   expected=polynomial(target)
   a=expected.xreplace({v:s.Symbol(str(v)+'_a') for v in expected.free_symbols});b=expected.xreplace({v:s.Symbol(str(v)+'_b') for v in expected.free_symbols})
   evaluated=re.fullmatch(r'\((.+)\)\(b\)-\((.+)\)\(a\)',value)
   if evaluated:
    try:
     pb,pa=[polynomial(x) for x in evaluated.groups()]
     vb=pb.xreplace({v:s.Symbol(str(v)+'_b') for v in pb.free_symbols});va=pa.xreplace({v:s.Symbol(str(v)+'_a') for v in pa.free_symbols})
     return s.expand(vb-va-(b-a))==0,'exact_evaluation_of_boundary_primitive_at_endpoints'
    except (ValueError,TypeError):pass
   try:return s.expand(endpoint_polynomial(value)-(b-a))==0,'exact_endpoint_difference_instead_of_primitive'
   except (ValueError,SyntaxError,TypeError):return None,'unparsed_boundary_expression'
  return None,'unparsed_boundary_expression'
 if key=='boundary_cases':
  try:return case_set(value)==case_set(target),'unordered_finite_case_set'
  except (ValueError,TypeError):return None,'unparsed_case_set'
 if key=='origin':
  # Accepted equivalences are limited, explicit and retained for manual inspection.
  v=re.sub(r'[\s_\-]','',str(value)).lower()
  if target=='conformal_anomaly' and v in ('weylanomaly','quantumweylanomaly','traceanomaly','conformalanomaly','quantumconformalanomaly','weyl(trace)anomaly','quantumweyl(trace)anomaly','quantumweylanomalyoftheregularizedfunctionalmeasure'):
   return True,'semantic_synonym_requires_manual_review'
  if target=='measure_jacobian' and v in ('measurejacobian','pathintegralmeasurejacobian','fermionmeasurejacobian','fujikawameasurejacobian','nontrivialmeasurejacobian','anomalousaxialjacobianofthefermionfunctionalmeasure','fujikawafermionmeasurejacobian','anomalousfermionfunctionalmeasurejacobian','anomalousaxialfujikawajacobianofthefermionmeasure','fermionfunctionalintegralmeasurejacobian','anomalousfermionmeasurejacobian'):
   return True,'semantic_synonym_requires_manual_review'
  return None,'unresolved_origin_description'
 if key in ('globally_exact','interchange_valid'):
  labels={'yes':True,'true':True,'1':True,'no':False,'false':False,'0':False}
  v=labels.get(str(value).lower().strip('{}'));t=labels.get(str(target).lower().strip('{}'))
  if v is not None and t is not None:return v==t,'explicit_boolean_synonym'
  return None,'unresolved_boolean_label'
 if key=='spec':
  try:
   def parse_set(x):return {exact_expression(t) for t in str(x).strip('{}').split(',')}
   return parse_set(value)==parse_set(target),'exact_spectrum_set'
  except (ValueError,SyntaxError,TypeError):return None,'unparsed_spectrum'
 try:return s.simplify(exact_expression(str(value))-exact_expression(str(target)))==0,'bounded_exact_symbolic_arithmetic'
 except (ValueError,SyntaxError,TypeError,AttributeError):return None,'unparsed_label'

def anomaly_density(coeff,structure):
 """Normalize the explicitly declared contraction jointly with its coefficient."""
 value=re.sub(r'\s+','',str(structure))
 explicit_epsilon='epsilon^{munurhosigma}F_mu_nuF_rho_sigma'
 labels={'epsFF':s.Integer(1),'FFtilde':s.Rational(1,2),
         'epsFF('+explicit_epsilon+')':s.Integer(1),
         'epsFF='+explicit_epsilon:s.Integer(1)}
 if value not in labels:raise ValueError('Unrecognized physical contraction')
 result=exact_expression(str(coeff))
 if not result.is_Rational:raise ValueError('Rational anomaly coefficient required')
 return result*labels[value]

def main():
 corpus=build_corpus();out=[]
 for r in jsonl(ROOT/'graded_original.jsonl'):
  if r['grade']['correct'] or r['status']!='completed':continue
  fid,arm=r['prompt_id'].split('/');f=corpus[fid]
  gold=f.canonical_gold if arm in ('canonical','paraphrase') else next(t.transported_gold for t in f.transforms if t.tid==arm)
  parser=make_parser(f.coords,f.type_spec,[],f.aliases)
  audit_text=re.sub(r'\\text\{(FINAL ANSWER:[^{}]*)\}',r'\1',r['response'])
  parsed=parser(audit_text);details={}
  if parsed:
   answer,_=parsed
   for key,target in gold.items():
    if fid=='IMR-AM-002' and key in ('coeff_num','structure'):continue
    ok,rule=equivalent(key,answer.get(key),target,fid)
    details[key]={'correct':ok,'rule':rule,'observed':str(answer.get(key)),'expected':str(target)}
   if fid=='IMR-AM-002':
    try:ok=anomaly_density(answer.get('coeff_num'),answer.get('structure'))==anomaly_density(gold['coeff_num'],gold['structure']);rule='joint_exact_coefficient_and_declared_contraction'
    except (ValueError,SyntaxError,TypeError):ok=None;rule='unresolved_physical_contraction'
    details['physical_density']={'correct':ok,'rule':rule,'observed':str(answer.get('coeff_num'))+' * '+str(answer.get('structure')),'expected':str(gold['coeff_num'])+' * '+str(gold['structure'])}
   category='explicit_mathematical_error' if any(x['correct'] is False for x in details.values()) else 'correct_after_notation_recovery' if all(x['correct'] is True for x in details.values()) else 'unresolved_notation'
  else:category='unresolved_notation'
  out.append({'run_id':r['run_id'],'model':r['model'],'prompt_id':r['prompt_id'],'replicate':r['replicate'],'response_sha256':r['response_sha256'],'classification':category,'coordinates':details,'post_observation':True})
 (ROOT/'original_notation_audit.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in out))
 from collections import Counter
 print(dict(Counter(r['classification'] for r in out)))
if __name__=='__main__':main()
