# Correct final answer with an invalid derivation: a targeted counterexample

This is a spot-check of one response, not an exhaustive derivation audit. It does not alter the prospectively defined typed-answer score. The response is GPT-6 Luna, `IMR-AM-001/T2`, run `4d79b20d13d632b2780bf1b4`. Its raw text and exact response hash are linked through `PROOF_SPOT_CHECKS.json`.

The prompt specifies Hermitian Euclidean gamma matrices, `D_mu = partial_mu + i q A_mu`, chirality `Gamma = -i gamma^0 gamma^1`, and the physical current `j_5^mu = -bar(psi) gamma^mu Gamma psi`. The submitted final density is the correct `q F_01/pi`, and the origin is correctly identified as the regulated fermion-measure Jacobian. However, its explanation uses the regulator `exp(-Dslash^2/M^2)` and an inconsistent integration-by-parts sign.

## Exact free-field check

Choose the Hermitian Pauli matrices

\[
\gamma^0=\begin{pmatrix}0&1\\1&0\end{pmatrix},\qquad
\gamma^1=\begin{pmatrix}0&-i\\i&0\end{pmatrix}.
\]

For a free Fourier mode, `Dslash = i(gamma^0 p_0 + gamma^1 p_1)`. Direct SymPy matrix multiplication gives

\[
\slashed D^2=-(p_0^2+p_1^2)I_2,
\qquad
-\frac{\slashed D^2}{M^2}=+\frac{p_0^2+p_1^2}{M^2}I_2.
\]

Therefore the regulator printed in the response grows as `exp(+p^2/M^2)`. It cannot yield the decaying Gaussian heat-kernel factor `M^2/(4 pi)` used in the next step. The convergent regulator in this anti-Hermitian-Dirac convention has the opposite exponent, `exp(+Dslash^2/M^2)`.

The physical intuition is direct: a heat-kernel regulator must suppress ultraviolet momentum modes. The printed exponent amplifies them. This defect is already visible with `A=0`, before any anomaly calculation or convention-dependent curvature coefficient is considered.

## Action-variation sign

Writing `B^mu = bar(psi) gamma^mu Gamma psi = -j_5^mu`, the response's local axial transformation gives

\[
\delta S_E=\int (\partial_\mu\alpha) B^\mu
=-\int (\partial_\mu\alpha)j_5^\mu
=+\int\alpha\,\partial_\mu j_5^\mu,
\]

with compactly supported `alpha` so the total derivative vanishes. The response instead writes a minus sign in the last expression. This is inconsistent with the physical-current definition in the prompt.

These two errors can cancel in the final Ward-identity coefficient. With the consistent regulator, `Dslash^2 = D_mu D_mu - q Gamma F_01` gives the local regulated chiral trace `-q F_01/(2 pi)` and hence `delta log J = +integral alpha q F_01/pi`. Combining this with the **positive** action-variation sign yields the correct final divergence `partial_mu j_5^mu = q F_01/pi`.

Thus a correct final answer and the right anomaly-origin label do not establish a correct derivation. The study's answer-level ceiling must not be read as a proof-level ceiling. The other original-bank derivations were not exhaustively certified, and the hard-bank response contract requests only exact JSON answers.

The matrix computation is reproduced in `PROOF_SPOT_CHECKS.json`. For the regulated-measure framework, see K. Fujikawa, [“Path integral for gauge theories with fermions,” *Physical Review D* **21**, 2848 (1980)](https://doi.org/10.1103/PhysRevD.21.2848), erratum **22**, 1499 (1980). The signs above follow from the explicitly stated prompt conventions and the displayed calculation, rather than importing a coefficient from a different convention.
