"""Finite-bank calibration summaries; no invented independence across templates."""
import argparse,collections,json,math
from fractions import Fraction
from pathlib import Path
from study import jsonl,write_json

def summary(rows):
 counts=collections.Counter(r['grade']['category'] for r in rows);n=len(rows);correct=counts['correct']
 uncertain=sum(counts[key] for key in ('format_error','label_ambiguity','truncated','apparatus','refusal'))
 return {'planned':n,'correct':correct,'unresolved':uncertain,'categories':dict(counts),'accuracy_lower':correct/n if n else None,'accuracy_upper_if_uncertain_correct':(correct+uncertain)/n if n else None,'accuracy_lower_exact':str(Fraction(correct,n)) if n else None,'accuracy_upper_exact':str(Fraction(correct+uncertain,n)) if n else None}

def compare(original,hard,alpha=0.05,comparisons=1):
 a,b=summary(original),summary(hard)
 if not original or not hard:return {'status':'insufficient_data','original':a,'hard':b}
 al,au=Fraction(a['correct'],len(original)),Fraction(a['correct']+a['unresolved'],len(original))
 bl,bu=Fraction(b['correct'],len(hard)),Fraction(b['correct']+b['unresolved'],len(hard))
 lower,upper=al-bu,au-bl
 # Independent-generation sensitivity only: bounded, not identically distributed observations.
 epsilon=math.sqrt(0.5*(1/len(original)+1/len(hard))*math.log(comparisons/alpha))
 gap=al-bl
 if a['categories'].get('apparatus',0) or b['categories'].get('apparatus',0):decision='incomplete_apparatus_coverage'
 elif au<Fraction(19,20):decision='original_ceiling_not_reproduced'
 elif al<Fraction(19,20):decision='original_ceiling_ambiguous'
 elif bl>=Fraction(19,20):decision='ceiling_persists_in_observed_scores'
 elif lower>=Fraction(1,10) and bu<=Fraction(17,20):
  decision='observed_reduction_with_floor_risk' if bu<Fraction(1,5) else 'observed_finite_bank_reduction'
 else:decision='inconclusive_after_format_and_apparatus_bounds'
 exact_epsilon=f"sqrt((1/2)*(1/{len(original)}+1/{len(hard)})*log({Fraction(comparisons)/Fraction(str(alpha))}))"
 return {'status':decision,'original':a,'hard':b,'observed_strict_accuracy_drop':float(gap),'conservative_mathematical_drop_interval':[float(lower),float(upper)],'conservative_mathematical_drop_interval_exact':[str(lower),str(upper)],
         'hard_floor_status':'below_floor_even_with_optimistic_credit' if bu<Fraction(1,5) else 'floor_not_ruled_out' if bl<Fraction(1,5) else 'verified_success_above_floor',
         'conditional_lower_bound_exact':f'max(-1, {lower} - {exact_epsilon})',
         'conditional_independent_generation_lower_bound':max(-1,lower-epsilon),'conditional_one_sided_alpha':alpha/comparisons,
         'inference_warning':'The bound assumes independent model generations and correct grading. It concerns expected performance on these fixed prompts, not a population of independent families. Native label mismatches require audit.'}

def analyze(plan,records):
 planned={r['run_id']:r for r in plan}
 if len(planned)!=len(plan):raise ValueError('Duplicate planned run')
 seen={}
 for record in records:
  key=record['run_id']
  if key not in planned or key in seen:raise ValueError('Unknown or duplicate observed run')
  reference=planned[key]
  for field in ('model','bank','prompt_id','replicate','prompt_sha256','arm','cluster'):
   if record.get(field)!=reference[field]:raise ValueError('Provenance mismatch '+field)
  seen[key]=record
 filled=[]
 for key,r in planned.items():
  filled.append(seen.get(key,{**r,'status':'missing','grade':{'category':'apparatus','valid':False,'correct':False,'reason':'not observed'}}))
 models=sorted({r['model'] for r in plan});out={}
 for model in models:
  rows=[r for r in filled if r['model']==model];sub={}
  for name,arms,exclude_am in [('canonical',{'canonical'},False),('canonical_without_AM',{'canonical'},True),('shared_arms',{'canonical','T1','T2','paraphrase'},False),('shared_arms_without_AM',{'canonical','T1','T2','paraphrase'},True)]:
   subset=[r for r in rows if r['arm'] in arms and not(exclude_am and r['cluster']=='AM') and (not name.startswith('shared') or r['replicate']==0)]
   sub[name]=compare([r for r in subset if r['bank']=='original'],[r for r in subset if r['bank']=='hard'],comparisons=max(1,len(models)*4))
  sub['by_cluster']={cluster:{bank:summary([r for r in rows if r['cluster']==cluster and r['bank']==bank and r['arm']=='canonical']) for bank in ('original','hard')} for cluster in ('QD','LG','AN','AM','BV','TN')}
  sub['hard_composition_supplement']=summary([r for r in rows if r['bank']=='hard' and r['arm']=='T2_after_T1'])
  out[model]=sub
 missing=len(plan)-len(seen)
 return {'status':'incomplete' if missing else 'complete_records','planned_runs':len(plan),'observed_records':len(seen),'missing_records':missing,'results':out,'population_claim':'not established','matching_warning':'Banks differ in mathematics, answer arity and response contract; comparisons estimate administered-bank performance, not a pure causal effect of mathematical complexity.'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--graded',type=Path,required=True,nargs='+');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 report=analyze(jsonl(a.plan),[r for file in a.graded for r in jsonl(file)]);write_json(a.output,report)
 print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
if __name__=='__main__':main()
