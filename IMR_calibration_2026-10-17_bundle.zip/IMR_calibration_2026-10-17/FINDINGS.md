# IMR calibration: saturation falls for Luna and persists for Sol

## Principal conclusion

The harder bank substantially reduces the **observed typed-answer ceiling for GPT-6 Luna** under the tested conditions. **GPT-6.1 Sol remains near the ceiling.** The data support a model-specific improvement in discrimination, with substantial variation across constructions. They do not support a claim that this bank generally resolves difficulty saturation or measures proof-level competence.

The fixed experiment completed **720 fresh Codex sessions** on 17 October 2026, using the user-authorized `gpt-6.1-sol` and `gpt-6-luna` aliases at **high reasoning**, with no observed tool calls. All 720 calls completed on their first attempt, with no wall timeouts or inference failures. Three successful apparatus preflights are excluded from these benchmark counts. The original and hard releases remain unchanged.

## Primary comparison

Each cell below contains **24 canonical instances × 4 fresh repetitions = 96 responses**. “Audited” means exact notation/format recovery plus explicitly documented semantic and manual judgments. Native scores are preserved separately. Unresolved responses receive no verified credit; the upper bound credits every one of them optimistically.

| Model | Original native | Hard native | Original audited correct | Hard audited correct | Hard wrong / unresolved | Audited hard interval | Original-minus-hard drop |
|---|---:|---:|---:|---:|---:|---:|---:|
| GPT-6.1 Sol | 57/96 | 90/96 | 96/96 = 100% | 94/96 = 97.92% | 2 / 0 | 97.92% | 2.08 percentage points |
| GPT-6 Luna | 55/96 | 4/96 | 94/96 = 97.92% | 28/96 = 29.17% | 59 / 9 | 29.17%–38.54% | 59.375–68.75 percentage points |

The prospective operational thresholds were original accuracy ≥95%, hard accuracy ≤85%, and a drop ≥10 percentage points after accounting for unresolved outcomes. Luna satisfies these finite-record criteria even with optimistic credit for every unresolved hard answer. Sol's verified hard accuracy itself exceeds the ceiling threshold.

These intervals are **deterministic bounds on the administered records, not confidence intervals**. They do not require independent templates or independently sampled questions. The supplementary one-sided Hoeffding calculation gives a conditional simultaneous lower bound of **36.38 percentage points** on Luna's expected canonical drop, under independent generations and valid grading, within the predeclared family of eight comparisons. That assumption is not independently established by the provider logs. The full derivation, exact rational endpoints, and limits are in [METHODS.md](METHODS.md) and [analysis_adjudicated.json](analysis_adjudicated.json). The statistical reference is [Hoeffding (1963)](https://doi.org/10.1080/01621459.1963.10500830).

## Robustness and transformed presentations

The original AM module concerns anomalies; hard AM concerns finite-dimensional Gaussian measures. Excluding AM therefore provides an essential sensitivity check rather than treating those topics as interchangeable.

| Scope | Model | Original audited | Hard audited interval | Conservative drop |
|---|---|---:|---:|---:|
| Canonical, AM excluded | Sol | 80/80 | 78/80 | 2.5 percentage points |
| Canonical, AM excluded | Luna | 80/80 | 16/80–23/80 | 71.25–80 percentage points |
| Four shared arms, one balanced pass | Sol | 96/96 | 95/96 | 1.04 percentage points |
| Four shared arms, one balanced pass | Luna | 96/96 | 30/96–38/96 | 60.42–68.75 percentage points |

The shared arms are canonical, T1, T2, and paraphrase; canonical repetitions are not pooled into that secondary score. The extra hard-bank composition arm has no original counterpart: Sol obtains **24/24**, and Luna **5/24 correct with three unresolved**.

The conclusion also survives excluding every manual decision and every semantic anomaly-origin synonym. In that exact-recovery-only analysis without AM, Luna's canonical drop is **67.5–80 percentage points**, and Sol still meets the observed ceiling criterion. This sensitivity is explicitly separate from the main adjudicated analysis; see [analysis_symbolic_only.json](analysis_symbolic_only.json).

After exact format recovery, Sol satisfies the answer-transport relation in **71/72 complete shared-arm pairs** and **24/24 composition pairs**. Luna satisfies it in **13/54 complete shared-arm pairs**, out of 72 eligible, and **3/15 complete composition pairs**, out of 24 eligible. Excluded pairs remain unknown. These conditional consistency rates are not unconditional accuracy estimates. The relation is evaluated on the actual submitted canonical answer, including complete wrong answers; missing values are never supplied from gold.

## What became difficult, and what remains poorly calibrated

The hard-bank canonical full-answer outcomes by construction are:

| Module | Sol correct / 16 | Luna correct / 16 | Luna unresolved / 16 |
|---|---:|---:|---:|
| QD | 14 | 0 | 3 |
| LG | 16 | 4 | 3 |
| AN | 16 | 5 | 1 |
| AM | 16 | 12 | 2 |
| BV | 16 | 1 | 0 |
| TN | 16 | 6 | 0 |

Luna's global verified success rate is above the proposed 20% floor, but QD is below it even with optimistic credit (at most 3/16), and BV is 1/16. The bank therefore needs better balance across constructions for Luna, as well as substantially more challenge for Sol. Repeating these instances does not create additional independent construction families: the bank contains **six templates**, each with four instances.

The failures are not solely parser failures. Among 1,064 planned scalar or polynomial entries in canonical answers, Sol has **1,060 correct and four wrong**; Luna has **715 correct, 306 wrong, and 43 unresolved**. Polynomial expressions each count as one entry. These entries are not independent statistical trials and are not used to enlarge significance-test denominators.

The output-quantity audit localizes important failures. Luna returns correct LG period and flux vectors in all 16 canonical responses, but only four correct pairings; nine pairings are explicitly wrong and three unresolved. In BV, 14/16 acceleration momenta are correct, while only 1/16 Euler expressions and 5/16 ordinary momenta are correct. In QD, 11/16 holonomies are correct, but no complete driven response is verified correct. These observations concern submitted quantities; they do not identify hidden reasoning causes.

Sol's two canonical failures are a QD response vector inconsistent with the supplied source and a QD resolvent-determinant sign error. Its additional shared-arm error is one transformed AN jet coefficient. [CASE_STUDIES.md](CASE_STUDIES.md) gives exact matrix and rational witnesses; [FAILURE_CATALOG.md](FAILURE_CATALOG.md) retains every native rejection with links to raw responses. Full per-quantity counts are in [STAGE_DIAGNOSTICS.json](STAGE_DIAGNOSTICS.json).

The hard bank also increases reported mean canonical reasoning-token use: approximately **4.21 times** for Sol and **5.11 times** for Luna. Increased generation cost is observable even where accuracy stays near the ceiling. These are measured usage ratios, not equal token allowances or a direct measure of conceptual depth.

## Mathematical and artifact verification

The fresh defining-equation audit covers every complete hard-bank answer, reusing only identical normalized answers for the same prompt within that fresh replay: **243 pass, 104 are rejected, and 37 incomplete/unparsed responses are not checked as complete answers**. There are 223 distinct prompt-answer checks. Every checked outcome agrees with exact-answer grading. Some incomplete responses still contain explicit wrong entries; their mathematical-error classification is supported by those entry witnesses, not by an invented completion.

The checks share SymPy and bank utilities, so this is an additional defining-equation verification rather than an independent proof-assistant implementation. The direct checks and their limits are recorded in [DEFINING_EQUATION_CHECKS.json](DEFINING_EQUATION_CHECKS.json).

All **354 original-bank tests, 106 hard-bank tests, and 20 analysis tests pass**. The original suite ran in a byte-verified temporary copy. All 185 original and 173 hard manifest-listed source files retain their pinned hashes. All 720 completed sessions have distinct session IDs; saved responses and token usage match their final event logs. CLI startup notices about disabled code mode and an experimental configuration switch are retained separately from inference failures. See [VERIFICATION.json](VERIFICATION.json) and [TEST_SUMMARY.json](TEST_SUMMARY.json).

## Limits of the scientific claim

The experiment measures complete **typed answers**. A targeted original-bank response reaches the correct anomaly coefficient using an ultraviolet-growing regulator and an inconsistent action-variation sign. Explicit Pauli-matrix calculations verify this counterexample in [PROOF_SPOT_CHECK.md](PROOF_SPOT_CHECK.md). Two other original-bank Luna responses have wrong final anomaly signs and account for its 94/96 canonical baseline; their convention checks are in [ORIGINAL_ANOMALY_ERROR_CHECKS.json](ORIGINAL_ANOMALY_ERROR_CHECKS.json). The regulated-measure reference is [Fujikawa (1980)](https://doi.org/10.1103/PhysRevD.21.2848). The original derivations were not exhaustively certified, and the hard prompts request JSON answers, so proof-level saturation is not measured.

The banks differ in mathematical content, answer arity, and response format: 47 original canonical coordinates versus 266 hard scalar/polynomial entries. The experiment does not isolate the causal contribution of deeper mathematics from arithmetic load, output length, or format burden. The matching establishes the same requested model alias, high reasoning, tool policy, common instructions, service defaults, and wall-time limit within each model. Immutable provider versions, explicit sampling seeds, temperature, and exact output-token caps were not available.

This is an **unblinded development calibration**. The evaluator inspected gold answers, and the recovery rules were developed after observing responses. Model test sessions received only the public problem strings; pretraining contamination and hidden provider state were not measured. No independent mathematical reviewer or untouched construction holdout was introduced. The candidate's confirmatory-admission flags remain unchanged.

## Files and replay

- [REPORT.md](REPORT.md): complete native, audited, sensitivity, transport, stage, and usage tables.
- [METHODS.md](METHODS.md): protocol, mathematical bounds, references, and audit limitations.
- [REPRODUCE.md](REPRODUCE.md): portable offline replay and artifact map.
- [Canonical outcome figure, PDF](canonical_outcomes.pdf) and [SVG](canonical_outcomes.svg); [module figure, PDF](canonical_by_module.pdf) and [SVG](canonical_by_module.svg).
- `responses.jsonl` and `runs/`: exact empirical responses, requests, invocations, events, and hashes.
- `MANIFEST.sha256` and `BUNDLE_VERIFICATION.json`: sealed evidence and archive checks.

The original and hard bank releases are preserved. The defensible outcome is a substantial observed reduction for Luna together with a persisting Sol ceiling, local floor problems, and explicit limits on proof-level and population-level conclusions.
