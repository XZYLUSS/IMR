import sys,json,subprocess,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from run_smoke import command,CODEX,ROOT,DISABLE
DISABLE.extend(['computer_use','in_app_browser','image_generation','code_mode_host','goals','hooks','tool_suggest','shell_snapshot'])
folder=ROOT/'preflight';cwd=tempfile.mkdtemp(prefix='imr-prompt-inspect-')
orig=command('gpt-6.1-sol',cwd,folder/'isolation.final.txt')
args=[CODEX,'debug','prompt-input'];i=0
while i<len(orig):
 if orig[i] in ['-c','--disable','--enable']:args+=orig[i:i+2];i+=2
 else:i+=1
args+=['-c','model="gpt-6.1-sol"','Compute 17 + 25. Return only the integer.']
p=subprocess.run(args,cwd=cwd,capture_output=True,text=True,timeout=60)
(folder/'prompt_inspection.json').write_text(p.stdout);(folder/'prompt_inspection.stderr.txt').write_text(p.stderr)
print('debug exit',p.returncode,'bytes',len(p.stdout));print(p.stdout[:18000]);print(p.stderr[:1000])
orig.remove('--json')
with (folder/'isolation.stdout.txt').open('w') as out,(folder/'isolation.stderr.txt').open('w') as err:
 p=subprocess.run(orig,input='This is an apparatus check, not a benchmark. Without calling any tools, list the names of tools available to you, if any. State whether you have any prior conversation or information about a mathematics family bank in your context. Then compute 17 + 25. Do not infer hidden information.\n',text=True,stdout=out,stderr=err,timeout=180)
print('model exit',p.returncode);print((folder/'isolation.stderr.txt').read_text()[-7000:]);print((folder/'isolation.stdout.txt').read_text()[-7000:])
