import subprocess,tempfile,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
CODEX='/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
DISABLE=['shell_tool','apps','plugins','remote_plugin','browser_use','browser_use_external','skill_search','skill_mcp_dependency_install','multi_agent','multi_agent_v2','memories','sleep_tool','view_image','workspace_dependencies']
def command(model,cwd,last):
 cmd=[CODEX,'exec','--ignore-user-config','--ephemeral','--skip-git-repo-check','--sandbox','read-only','--json','--color','never','--model',model,'--cd',str(cwd),'--output-last-message',str(last)]
 for value in ['model_reasoning_effort="high"','model_instructions_file='+json.dumps(str(ROOT/'system_prompt.txt')),'project_doc_max_bytes=0','memories.use_memories=false','memories.generate_memories=false','web_search="disabled"']:
  cmd.extend(['-c',value])
 for feature in DISABLE:cmd.extend(['--disable',feature])
 cmd.extend(['--enable','skip_host_skill_discovery','-'])
 return cmd
if __name__=='__main__':
 model='gpt-6-luna';folder=ROOT/'preflight';cwd=Path(tempfile.mkdtemp(prefix='imr-isolated-'))
 cmd=command(model,cwd,folder/'smoke.final.txt')
 (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 start=time.time()
 with (folder/'smoke.events.jsonl').open('w') as out,(folder/'smoke.stderr.txt').open('w') as err:
  p=subprocess.run(cmd,input='Compute 17 + 25. Return only the integer.\n',text=True,stdout=out,stderr=err,timeout=180)
 print(json.dumps({'exit_code':p.returncode,'seconds':time.time()-start,'cwd':str(cwd)}))
 print((folder/'smoke.stderr.txt').read_text()[-6000:])
 print((folder/'smoke.events.jsonl').read_text()[-6000:])
