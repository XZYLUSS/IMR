import json,os,subprocess,tempfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from run_smoke import command,ROOT,DISABLE
DISABLE.extend(['computer_use','in_app_browser','image_generation','code_mode_host','goals','hooks','tool_suggest','shell_snapshot'])
folder=ROOT/'preflight';cwd=tempfile.mkdtemp(prefix='imr-clean-inspect-')
env={k:v for k,v in os.environ.items() if not k.startswith('CODEX_') or k=='CODEX_HOME'}
(folder/'removed_environment_names.json').write_text(json.dumps(sorted(set(os.environ)-set(env)),indent=2)+'\n')
cmd=command('gpt-6-luna',cwd,folder/'clean.final.txt');cmd.remove('--json')
with (folder/'clean.stdout.txt').open('w') as out,(folder/'clean.stderr.txt').open('w') as err:
 p=subprocess.run(cmd,input='This is an apparatus check. Without calling any tools, list the tool names available to you, if any, and whether your context includes any prior conversation, memory, or information about a mathematics family bank. Then compute 17 + 25. Do not infer hidden information.\n',text=True,stdout=out,stderr=err,timeout=180,env=env)
print('exit',p.returncode);print((folder/'clean.stderr.txt').read_text()[-7000:]);print((folder/'clean.stdout.txt').read_text()[-7000:])
