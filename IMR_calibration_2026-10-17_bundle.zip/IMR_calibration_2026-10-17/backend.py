"""Isolated Codex CLI adapter; never imports gold or bank grading modules."""
import json,os,signal,subprocess,tempfile,time
from pathlib import Path
from study import ROOT,sha,write_json
CODEX='/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex'
DISABLE=['shell_tool','apps','plugins','remote_plugin','browser_use','browser_use_external','skill_search','skill_mcp_dependency_install','multi_agent','multi_agent_v2','memories','sleep_tool','view_image','workspace_dependencies','computer_use','in_app_browser','image_generation','code_mode_host','goals','hooks','tool_suggest','shell_snapshot']
CONFIG=['model_reasoning_effort="high"','model_instructions_file='+json.dumps(str(ROOT/'system_prompt.txt')),'project_doc_max_bytes=0','memories.use_memories=false','memories.generate_memories=false','web_search="disabled"','approval_policy="never"']
SETTINGS={'backend':'codex exec','cli_version':'0.163.0-alpha.10.2','reasoning_effort':'high','disabled_features':DISABLE,'enabled_features':['skip_host_skill_discovery'],'config':CONFIG,'wall_timeout_seconds':600,'concurrency':4,'max_attempts':2,'output_token_cap':'service default; not exposed or independently controlled','temperature':'service default; not exposed','seed':'not exposed','model_snapshot':'requested model alias; immutable serving revision unavailable','tool_policy':'no tools requested; any observed non-message item rejects the attempt','context':'new ephemeral session and empty temporary cwd; parent CODEX_* env removed except CODEX_HOME; user config ignored; memory disabled','memory_enforcement_limit':'CLI configuration and preflight; hidden server context is not independently observable'}
def command(model,cwd,last):
 cmd=[CODEX,'exec','--ignore-user-config','--ephemeral','--skip-git-repo-check','--sandbox','read-only','--json','--color','never','--model',model,'--cd',str(cwd),'--output-last-message',str(last)]
 for v in CONFIG:cmd+=['-c',v]
 for f in DISABLE:cmd+=['--disable',f]
 return cmd+['--enable','skip_host_skill_discovery','-']
def stop(proc):
 if proc.poll() is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
def inspect_events(path):
 events=[];invalid=[]
 if path.exists():
  for line in path.read_text(errors='replace').splitlines():
   try:events.append(json.loads(line))
   except json.JSONDecodeError:invalid.append(line[:100])
 violations=[e for e in events if e.get('type','').startswith('item.') and e.get('item',{}).get('type') not in ('agent_message','reasoning','error')]
 return events,invalid,violations
def attempt(row,attempt_number,settings_sha):
 folder=ROOT/'runs'/row['run_id']/f'attempt_{attempt_number}';folder.mkdir(parents=True,exist_ok=False)
 (folder/'prompt.txt').write_text(row['prompt'])
 cwd=Path(tempfile.mkdtemp(prefix='imr-eval-'))
 cmd=command(row['model'],cwd,folder/'response.txt');write_json(folder/'command.json',cmd)
 env={k:v for k,v in os.environ.items() if not k.startswith('CODEX_') or k=='CODEX_HOME'}
 started=time.time();status='apparatus_error';events_path=folder/'events.jsonl';stderr_path=folder/'stderr.txt'
 with events_path.open('w') as out,stderr_path.open('w') as err:
  proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True,env=env,start_new_session=True)
  proc.stdin.write(row['prompt']);proc.stdin.close()
  while proc.poll() is None:
   events,invalid,violations=inspect_events(events_path)
   if violations:status='tool_violation';stop(proc);break
   if time.time()-started>SETTINGS['wall_timeout_seconds']:status='wall_timeout';stop(proc);break
   if events_path.stat().st_size>2_000_000:status='output_limit';stop(proc);break
   time.sleep(.4)
  exit_code=proc.wait()
 events,invalid,violations=inspect_events(events_path)
 completed=[e for e in events if e.get('type')=='turn.completed'];response=(folder/'response.txt').read_text() if (folder/'response.txt').exists() else ''
 if violations:status='tool_violation'
 elif status not in ('wall_timeout','output_limit') and exit_code==0 and completed and response and not invalid:status='completed'
 record={k:v for k,v in row.items() if k!='prompt'}
 record.update(status=status,attempt=attempt_number,response=response,response_sha256=sha(response.encode()),settings_sha256=settings_sha,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(started)),elapsed_seconds=time.time()-started,exit_code=exit_code,events_sha256=sha(events_path.read_bytes()),stderr_sha256=sha(stderr_path.read_bytes()),usage=completed[-1].get('usage') if completed else None,tool_violation_count=len(violations),invalid_event_lines=len(invalid),artifact_directory=str(folder.relative_to(ROOT)),actual_model_revision=None,requested_reasoning_effort='high')
 write_json(folder/'result.json',record)
 # The empty cwd has no project or response artifacts.
 try:cwd.rmdir()
 except OSError:pass
 return record
