Verbatim prompts for the generation protocol (paper, Section 9.2).

system_prompt.txt         the single fixed system prompt, identical across all
                          arms, all families, and all models.
format_repair_prompt.txt  the single fixed re-ask issued at most once per
                          generation when the normalizer returns parse-fail.
                          {ANSWER_TYPE} is substituted with the family's
                          declared answer type and nothing else is varied.

Seed derivation is SHA-256 over master seed, model, family, arm and replicate,
truncated to 64 bits; see analysis.derive_seed. Python's built-in hash() is
process-randomized and is not used anywhere in this bundle.

Every generation runs in a fresh conversation with no shared history and no
cross-arm caching. The canonical arm is generated independently for each of
T1, T2 and s; canonical replicates are never reused across arms.
