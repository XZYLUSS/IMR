# Family-bank correction: 27 September review

Revision: `2026-10-03-september-review`. This is a revised calibration bank,
not the frozen artifact identified by the original manuscript hashes.

Both PDFs in `IMR-update-27-Sep.zip` were read in full. Their bytes agree with
the previously extracted PDFs. The archive contains review questions and an
aggregate results report; it does not contain raw model responses or the live
evaluation harness. The aggregate results have therefore not been regraded or
independently reproduced.

## What changed

All 24 families now have self-contained canonical, T1, T2, and paraphrase
questions in `presentations.json`. The full objects and relevant conventions
are stated; worked answers have been removed from the question text. The
review's proposed questions were checked and adopted with the corrections
below. No families were added, removed, or made confirmatory-eligible.

`model_prompts.json` contains the 96 model-facing records without golds,
transported golds, or certificates. Send these presentations, together with
`prompts/system_prompt.txt`, to the model. The per-family `*-problem.json` and
`*-transform.json` files are grader artifacts and **must not be sent wholesale
to the model**. They intentionally contain reference answers.

The source registry, generated records, actual transformed-question
certificates, and all 72 copies under `families_repo/all_files` are synchronized.
The existing family-prefixed filenames are preserved. Certificate references
now resolve in both layouts. Regeneration preserves this layout and rewrites
the flat export automatically. Finder `.DS_Store` files are excluded from the
checksum manifest.

The parser now reads the committed `FINAL ANSWER:` line when present, instead
of accidentally taking a value from an intermediate calculation. Without that
line, the existing accepted-form parser remains available. These are restricted
typed parsers, not universal natural-language mathematical graders.

## Boundary families: the mathematical correction

The old `boundary_vanishes_iff` coordinate was invalid as an open-ended answer
contract. Familiar boundary conditions form neither a unique exhaustive list
nor an if-and-only-if classification. Compactness of the **domain** does not
remove its boundary. A variation with compact support **inside the interior**
does remove the relevant boundary jets. Ordinary fixed, nonzero Neumann data
do not by themselves cancel the boundary term of these unmodified actions.

The first variations follow from integration by parts and Stokes' theorem;
see [Tong, classical field theory, §1.1](https://www.damtp.cam.ac.uk/user/tong/qft/qfthtml/S1.html)
and [Lee, *Introduction to Smooth Manifolds*, 2nd ed., chapter on Stokes' theorem](https://link.springer.com/book/10.1007/978-1-4419-9982-5).
The identities below and their endpoint specializations are checked symbolically.

For BV-001, with a fixed Riemannian metric and outward unit normal,

\[
\delta S[\phi;h]=\int_M(-\Delta_g\phi)h\,dV_g
 +\int_{\partial M}h\,\partial_n\phi\,dA_g.
\]

For BV-002, with \(\eta=\mathrm{diag}(1,-1,-1,-1)\),

\[
\delta S[\phi;h]=\int_M[-\Box\phi-m^2\phi]h\,d^4x
 +\int_{\partial M}h\,\partial^\mu\phi\,d\Sigma_\mu.
\]

The oriented surface element fixes the flux sign without assuming a spacelike
normal. For BV-003 and BV-004, respectively,

\[
\delta S[x;h]=\int_a^b(-\ddot x-\omega^2x)h\,dt
 +[\dot xh]_a^b,
\]

\[
\delta S[\phi;h]=\int_a^b\phi^{(4)}h\,dx
 +[\phi''h'-\phi'''h]_a^b.
\]

The new scored coordinates are `bulk`, `boundary_term`, and `boundary_cases`.
`bulk` is the signed coefficient in the first variation, so multiplying it by
a nonzero constant is not permitted. The stationary equation is still explained
in the derivation. `boundary_term` specifies the full integrand or endpoint
primitive, with its measure/evaluation rule stated in the question.

Each question explicitly lists a finite menu of candidate assumptions and asks
for **all** cases in that menu that suffice for every compatible field and
variation. The correct sets are:

| Family | Sufficient cases in its stated menu |
|---|---|
| BV-001, BV-002 | Dirichlet; homogeneous Neumann; closed domain; interior-supported variation; matched periodic data |
| BV-003 | fixed endpoints; zero endpoint velocities; interior-supported variation; matched periodic endpoint data |
| BV-004 | clamped variations; free natural data; simply supported data; interior-supported variation; matched periodic jets |

All cases are defined by equations in the questions and `boundary_contract.py`.
For BV-004, clamped means \(h=h'=0\), free means
\(\phi''=\phi'''=0\), and simply supported means \(h=\phi''=0\), at
both endpoints. Periodicity requires the field derivatives and variations
specified in the question to match at the paired endpoints or faces.

Set order and algebraically equivalent polynomial expressions are accepted.
Unknown cases, omitted sufficient cases, extra insufficient cases, missing flux
terms, and wrong signs are rejected. This is a new answer schema, not a silent
reinterpretation of old `boundary_vanishes_iff` strings.

Concrete checks expose why the old golds failed:

* On the compact interval \([0,1]\), \(\phi=h=x\) gives
  \([\phi'h]_0^1=1\), despite compactness. The same example works for BV-003.
  For BV-002 use \([0,1]\times\mathbb T^3\), unit spatial volume, and
  \(\phi=h=t\); the temporal flux is also 1.
* For BV-004, \(\phi=h=x^2\) gives boundary contribution 4 on \([0,1]\).
  Dirichlet variation alone fails: \(\phi=x^2,h=x(1-x)\) gives -4.
  Neumann variation alone fails: \(\phi=x^4,h=1\) gives -24.
* Preserving a prescribed nonzero derivative is insufficient: with
  \(\phi=x,h=3x^2-2x^3\), one has \(h'(0)=h'(1)=0\) but
  \([\phi'h]_0^1=1\).

Physically, a total derivative records variation entering or leaving through
the boundary. Its cancellation is controlled by boundary data, allowed
variations, or paired-face cancellation, not by the finite extent of a region.

## Missing objects and conventions

The tensor families now specify

\[
A=\begin{pmatrix}2&1\\0&3\end{pmatrix},\qquad
B=\begin{pmatrix}1&4\\2&1\end{pmatrix},\qquad
AB=\begin{pmatrix}4&9\\6&3\end{pmatrix}.
\]

Thus the unchanged reference values are \(\operatorname{tr}A=5\),
\(\det A=6\), \(\chi_A(\lambda)=\lambda^2-5\lambda+6\),
\(\operatorname{spec}A=\{2,3\}\), \(\operatorname{tr}(AB)=7\),
\(\det(AB)=-42\), \(\det(A\otimes B)=1764\), and
\(\operatorname{tr}[A,B]=0\). The review's matrices agree with the existing
TN-002 verifier; TN-001 uses a representative similar to the older diagonal
matrix. The actual matrix products, characteristic polynomials, Kronecker
determinants and specified conjugations are checked with SymPy. Similarity
invariance is reviewed in [Strang, MIT 18.06, lecture 28](https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/9697b309089fad2aefcbf5779c5bc3b2_MIT18_06S10_L28.pdf).

For LG-002 the retained curvature is
\(F=\tfrac12\sin\theta\,d\theta\wedge d\phi\), giving
\((2\pi)^{-1}\int F=1\). The PDF's commentary mentions \(2\sin\theta\),
but its proposed question and the existing verifier use \(\tfrac12\sin\theta\).
The former would give 4. The T1 correction is
\(d(\sin^2\theta\,d\phi)\); this primitive is globally smooth because it is
\(x\,dy-y\,dx\) on the unit sphere. T2 uses
\(\phi=\psi+\tfrac12\sin\theta\sin\psi\), a smooth global map whose
azimuthal derivative is at least \(1/2\). The previous verifier's
latitude-independent azimuthal deformation was not smooth at the poles and
has been replaced. For curvature and characteristic-class conventions see
[Tong, *Gauge Theory*, §1.1](https://www.damtp.cam.ac.uk/user/tong/gaugetheory/gt.pdf).

AM-001 and AM-002 now state the Euclidean action, covariant derivative,
orientation/chirality convention, and current. With the stated conventions,
the local gamma traces reproduce the existing coefficients. In particular,

\[
\widetilde F^{\mu\nu}=\tfrac12\epsilon^{\mu\nu\rho\sigma}F_{\rho\sigma}
\quad\Longrightarrow\quad
\frac1{16}\epsilon^{\mu\nu\rho\sigma}F_{\mu\nu}F_{\rho\sigma}
=\frac18 F_{\mu\nu}\widetilde F^{\mu\nu}.
\]

These are the same physical answer. Coefficient and tensor contraction are
graded jointly; a coefficient cannot be compared without its structure label.
The question now explicitly permits both defined forms. T1 still changes the
stored representative from `1/16, epsFF` to `1/8, FFtilde`; this is not a claim
of a new physical anomaly. The origin in the measure is the result of
[Fujikawa, *Physical Review Letters* **42** (1979), 1195–1198](https://journals.aps.org/prl/abstract/10.1103/PhysRevLett.42.1195).

AM-003 explicitly refers to the **chiral** index, with its chirality and
instanton normalization, rather than the index of the full Dirac operator.
For the stated fundamental SU(2) instanton the oriented index is 1; the Dirac
axial-charge violation is twice that index. Zero modes are properties of the
Dirac operator, not modes created by a quantum anomaly. See
[Atiyah and Singer, *Annals of Mathematics* **87** (1968), 484–530](https://annals.math.princeton.edu/1968/87-3/p05)
and [Tong, *Gauge Theory*, §§3.2–3.3](https://www.damtp.cam.ac.uk/user/tong/gaugetheory/gt.pdf).

AM-004 specifies the stress-tensor OPE normalization. Its free-scalar value
\(c=1\) is checked through the Wick double contraction; the closed-surface
Euler counterterm has zero metric variation. See
[Tong, *String Theory*, chapter 4](https://www.damtp.cam.ac.uk/user/tong/string/string4.pdf).
Module D remains L1/V1: algebraic convention checks do not establish all
analytic or quantum-field-theoretic hypotheses of those results.

The remaining analytic and topology questions keep their original reference
values while removing answer leakage. Their exact integrals and transformed
objects are replayed in the certificates. Supporting references include
[NIST DLMF §25.6.1](https://dlmf.nist.gov/25.6.E1) for \(\zeta(2)\),
[NIST DLMF §7.2](https://dlmf.nist.gov/7.2) for the Gaussian integral,
[Sheffield, MIT 18.175, lecture 4](https://math.mit.edu/~sheffield/2016175/Lecture4.pdf)
for convergence/interchange hypotheses, and
[Hatcher, *Algebraic Topology*](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html)
for the sphere and torus Euler characteristics. Residue and differential-form
calculations are explicit in the certificates; their global meaning uses
Stokes' theorem and contour winding, not equality of local coordinate formulas.

## Validation and limits

Before repair, the existing suite reported **297 passed, 5 failed**. The five
failures were missing old filenames, certificate lookup failures, and stale
manifest membership/digests. The revised suite additionally tests the concrete
review defects; see `test_september_review.py` and `VALIDATION.json` for the
executed verification record. `RUNNING.md` gives the current reproduction order.

High accuracy on these small examples is a difficulty/calibration limitation,
not a mathematical defect that can be repaired by rewording. This repair does
not claim to eliminate saturation, add non-identity physical transports, or
validate the PDF's cross-model conclusions. New harder families require a
separate bank revision and new calibration. The frozen admission decisions
remain ineligible for confirmatory analysis. No model/API runs were performed.

The source review ZIP, historical banks, manuscript PDF/TeX, and original
submission tarball are unchanged. A complete pre-edit copy of this bank is
saved at
`../../../../IMR-update-27-Sep/family-bank-before-2026-10-03.tar.gz`.
Its SHA-256 is
`8a71354c8b8e06c9270234c6201f02d2f57e9013be4d36b2196b97d731ded82f`.
Do not associate the revised bank's hashes or answer schema with the old PDF's
empirical results without rerunning or appropriately re-adjudicating the raw
responses.
