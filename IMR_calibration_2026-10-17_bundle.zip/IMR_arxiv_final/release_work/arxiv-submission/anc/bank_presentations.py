"""Model-facing questions, deliberately separate from grader golds."""
import json
from pathlib import Path

REVISION = '2026-10-03-september-review'
PRESENTATIONS = json.loads(Path(__file__).with_name('presentations.json').read_text())['families']

def attach_presentations(corpus):
    if set(corpus) != set(PRESENTATIONS):
        raise ValueError('presentation registry and family bank disagree')
    for fid, family in corpus.items():
        arms = PRESENTATIONS[fid]
        if set(arms) != {'canonical', 'T1', 'T2', 'paraphrase'}:
            raise ValueError(f'{fid}: incomplete presentation set')
        family.presentation = arms['canonical']
        family.paraphrase = arms['paraphrase']
        for record, transform in zip(family.transform_records, family.transforms):
            record['presentation'] = arms[record['id']]
            transform.name = record['kind']
        family.response_contract = (
            'Finish with FINAL ANSWER: followed by semicolon-separated name = value assignments '
            'for these coordinates, in this order: ' + ', '.join(family.coords) + '. '
            'Use exact integers or rational fractions where requested, ^ for powers, lam '
            'as the characteristic-polynomial variable, and brace-delimited sets. '
            'Put the derivation and the requested explanation before that final line.')

def model_records(corpus):
    """Only these records may be sent to a model; problem.json includes golds."""
    records = []
    for fid, family in sorted(corpus.items()):
        for arm in ('canonical', 'T1', 'T2', 'paraphrase'):
            records.append({'family_id': fid, 'record_id': f'{fid}/{arm}',
                            'presentation': PRESENTATIONS[fid][arm] + '\n\n' + family.response_contract,
                            'answer_coordinates': family.coords, 'type_spec': family.type_spec})
    return {'schema': 'imr-model-prompts/2', 'bank_revision': REVISION, 'records': records}
