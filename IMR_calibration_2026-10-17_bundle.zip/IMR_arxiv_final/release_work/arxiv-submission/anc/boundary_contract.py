"""Finite, explicit answer contract for the September boundary-family repair.

The cases are sufficient conditions, not an exhaustive classification of all
boundary data. Equality is exact equality on a stated finite case set, together
with polynomial equality of the signed bulk coefficient and boundary primitive.
No model-supplied expression is passed to eval, sympify or parse_expr.
"""
import ast
import re
import sympy as sp
from core import Family, Transform, make_parser, tau_identity, anti_unconditional

COMMON_CASES = {
    "Dirichlet": "h vanishes on the entire boundary",
    "homogeneous_Neumann": "the outward normal derivative of phi is zero on the entire boundary",
    "closed": "M is compact and has no boundary",
    "interior_support": "h has compact support contained in the interior of M",
    "periodic": "M is a rectangular flat cell; phi and h extend smoothly and periodically across every pair of opposite faces",
    "compact_domain": "M is compact, possibly with boundary; phi and h are otherwise unrestricted",
    "fixed_nonzero_Neumann": "a nonzero normal derivative of phi is prescribed and preserved by the variation; the boundary value of h is unrestricted",
}
CASE_DEFINITIONS = {
    "IMR-BV-001": dict(COMMON_CASES),
    "IMR-BV-002": {
        **COMMON_CASES,
        "homogeneous_Neumann": "the conormal derivative n_mu eta^{mu nu} partial_nu phi vanishes on every boundary face",
        "closed": "the flat spacetime domain is a compact quotient with no boundary",
        "fixed_nonzero_Neumann": "a nonzero conormal derivative is prescribed and preserved by the variation; the boundary value of h is unrestricted",
    },
    "IMR-BV-003": {
        "fixed_endpoints": "h(a)=h(b)=0",
        "homogeneous_Neumann": "x'(a)=x'(b)=0",
        "interior_support": "h has compact support in (a,b)",
        "periodic": "x(a)=x(b), x'(a)=x'(b), and h(a)=h(b)",
        "compact_domain": "[a,b] is compact; x and h are otherwise unrestricted",
        "fixed_nonzero_Neumann": "x'(a)=x'(b)=1 and h'(a)=h'(b)=0, with h(a),h(b) unrestricted",
    },
    "IMR-BV-004": {
        "clamped": "h(a)=h(b)=h'(a)=h'(b)=0",
        "free": "phi''=phi'''=0 at both endpoints, with h,h' unrestricted there",
        "simply_supported": "phi''=0 and h=0 at both endpoints",
        "interior_support": "h has compact support in (a,b)",
        "periodic": "phi,phi',phi'',phi''',h,h' have matching values at a and b",
        "compact_domain": "[a,b] is compact; phi and h are otherwise unrestricted",
        "Dirichlet_only": "h=0 at both endpoints, with h' unrestricted",
        "Neumann_only": "h'=0 at both endpoints, with h unrestricted",
    },
}
GOLDS = {
    "IMR-BV-001": {"bulk": "-lap(phi)", "boundary_term": "h*dn(phi)",
                   "boundary_cases": "{Dirichlet,homogeneous_Neumann,closed,interior_support,periodic}"},
    "IMR-BV-002": {"bulk": "-box(phi)-m^2*phi", "boundary_term": "h*dmu(phi)",
                   "boundary_cases": "{Dirichlet,homogeneous_Neumann,closed,interior_support,periodic}"},
    "IMR-BV-003": {"bulk": "-xddot-w^2*x", "boundary_term": "xdot*h",
                   "boundary_cases": "{fixed_endpoints,homogeneous_Neumann,interior_support,periodic}"},
    "IMR-BV-004": {"bulk": "phi4", "boundary_term": "phi2*h1-phi3*h",
                   "boundary_cases": "{clamped,free,simply_supported,interior_support,periodic}"},
}
NOTATION = {
    "IMR-BV-001": "Use lap(phi) for the Laplace-Beltrami operator div_g grad_g phi and dn(phi) for the outward normal derivative. boundary_term is the integrand with respect to dA_g on the entire boundary.",
    "IMR-BV-002": "Use box(phi)=eta^{mu nu} partial_mu partial_nu phi and dmu(phi)=partial^mu phi. boundary_term is the mu-component of the flux integrated against the outward oriented surface element dSigma_mu; repeated mu is summed in the integral.",
    "IMR-BV-003": "Use xdot and xddot for the first and second path derivatives. boundary_term is the primitive evaluated at b minus its value at a. In the tau presentation use these same derivative names.",
    "IMR-BV-004": "Use phi2, phi3, phi4 for the second, third and fourth derivatives and h1 for the first derivative of h, with respect to the stated interval coordinate. boundary_term is the primitive evaluated at b minus its value at a.",
}

_SYMBOLS = {name: sp.Symbol(name) for name in (
    "phi", "h", "m", "w", "x", "xdot", "xddot", "phi2", "phi3", "phi4", "h1",
    "lap_phi", "box_phi", "dn_phi", "dmu_phi")}

def polynomial(text):
    """Parse only a small arithmetic AST over the published derivative symbols."""
    if not isinstance(text, str) or len(text) > 256:
        raise ValueError("expected a short polynomial expression")
    text = re.sub(r"\s+", "", text).replace("^", "**")
    for name in ("lap", "box", "dn", "dmu"):
        text = text.replace(f"{name}(phi)", f"{name}_phi")
    def degree(node):
        if isinstance(node, ast.Expression): return degree(node.body)
        if isinstance(node, ast.Name): return 1
        if isinstance(node, ast.Constant): return 0
        if isinstance(node, ast.UnaryOp): return degree(node.operand)
        if isinstance(node, ast.BinOp):
            a,b=degree(node.left),degree(node.right)
            if isinstance(node.op,(ast.Add,ast.Sub)): return max(a,b)
            if isinstance(node.op,ast.Mult): return a+b
            if isinstance(node.op,ast.Div) and b==0: return a
            if isinstance(node.op,ast.Pow) and isinstance(node.right,ast.Constant) and type(node.right.value) is int and 0<=node.right.value<=4:
                return a*node.right.value
        raise ValueError("unsupported expression")
    def visit(node):
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Name) and node.id in _SYMBOLS:
            return _SYMBOLS[node.id]
        if isinstance(node, ast.Constant) and type(node.value) is int and abs(node.value) <= 10000:
            return sp.Integer(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            value = visit(node.operand)
            return -value if isinstance(node.op, ast.USub) else value
        if isinstance(node, ast.BinOp):
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Add): return left + right
            if isinstance(node.op, ast.Sub): return left - right
            if isinstance(node.op, ast.Mult): return left * right
            if isinstance(node.op, ast.Div) and right.is_Integer and right != 0: return left / right
            if isinstance(node.op, ast.Pow) and right.is_Integer and 0 <= right <= 4: return left ** right
        raise ValueError("unsupported expression")
    try:
        tree=ast.parse(text, mode="eval")
        if len(list(ast.walk(tree)))>80 or degree(tree)>4:
            raise ValueError("expression exceeds the declared polynomial grammar")
        return sp.expand(visit(tree))
    except (SyntaxError, RecursionError) as exc:
        raise ValueError("invalid expression") from exc

def case_set(text):
    if not isinstance(text, str) or not re.fullmatch(r"\s*\{[A-Za-z_,\s]*\}\s*", text):
        raise ValueError("expected a brace-delimited case set")
    values = [x.strip() for x in text.strip()[1:-1].split(",") if x.strip()]
    if len(set(values)) != len(values):
        raise ValueError("duplicate case")
    return frozenset(values)

def boundary_family(fid, presentation, transforms_meta):
    gold = dict(GOLDS[fid])
    coords = list(gold)
    types = {key: "label" for key in coords}
    aliases = {"bulk": ["bulk_term"], "boundary_term": ["boundary_integrand"],
               "boundary_cases": ["sufficient_cases"]}
    base_parser = make_parser(coords, types, ["witness"], aliases)
    def keys(answer):
        cases = case_set(answer.get("boundary_cases"))
        if not cases <= set(CASE_DEFINITIONS[fid]) | {"always"}:
            raise ValueError("unknown boundary case")
        return (polynomial(answer.get("bulk")), polynomial(answer.get("boundary_term")), cases)
    def equal(a, b):
        try: return keys(a) == keys(b)
        except (ValueError, TypeError, AttributeError): return False
    def distance(a, b):
        try: return sum(x != y for x, y in zip(keys(a), keys(b))) / 3
        except (ValueError, TypeError, AttributeError): return 1.0
    def parse(text):
        parsed = base_parser(text)
        if parsed is None: return None
        try: keys(parsed[0])
        except (ValueError, TypeError): return None
        return parsed
    negative = {**gold, "boundary_cases": "{always}"}
    transforms = [Transform(tid, rec["kind"], tau_identity, tau_identity, dict(gold))
                  for tid, rec in zip(("T1", "T2"), transforms_meta)]
    return Family(fid, "E-boundary-variation", "L2", coords, gold, transforms,
                  equal, distance, parse, negative, {}, ["witness"], dict(gold),
                  anti_unconditional("boundary_cases"),
                  answer_type={"kind": "BulkBoundaryAndFiniteCases", "encoding": coords,
                               "case_definitions": CASE_DEFINITIONS[fid],
                               "case_semantics": "all and only sufficient cases among the listed candidates"},
                  type_spec=types, aliases=aliases,
                  allowed_forms=["polynomial_equivalence", "unordered_finite_case_set"],
                  exclusions=["compact_domain_alone", "unconditional_vanishing", "open_ended_iff_list"],
                  transform_records=transforms_meta, presentation=presentation)
