"""
imr/materialize_families.py  --  emit the per-family artifact tree for ALL 24
pilot families (I3 base ten + I4 expansion = 24). For each family it writes:
    families_repo/<FID>/<FID>-problem.json      -- canonical record + typed schema
    families_repo/<FID>/<FID>-transform.json    -- T1,T2 + paraphrase + negative control
    families_repo/<FID>/<FID>-certificate.sympy -- the SymPy-checkable certificate
                                             with anchors #T1, #T2, #neg
Run as part of the audit:  python materialize_families.py
"""
import json, os
from pathlib import Path
from families import build_corpus
from bank_presentations import REVISION, model_records

REPO = os.path.join(os.path.dirname(__file__), "families_repo")

def artifact_path(fid, filename):
    return os.path.join(REPO, fid, f"{fid}-{filename}")

# Per-family certificate bodies (anchors #T1, #T2, #neg are resolved here).
NEGATIVE_CERTIFICATES = {'IMR-AM-001': 'from sympy import Symbol, pi, simplify\n'
               "F01=Symbol('F01'); q=Symbol('q')\n"
               "assert simplify((q/pi)*F01) != 0 and 'classical_action' != 'measure_jacobian'  # true "
               'density nonzero; classical law omits measure Jacobian',
 'IMR-AM-002': 'from sympy import Rational, Symbol\n'
               "FFt=Symbol('FFtilde')\n"
               "assert Rational(0)*FFt == 0 and 'classical_action' != 'measure_jacobian'  # dj5=0 is the "
               'classical law, omits the measure Jacobian',
 'IMR-AM-003': 'assert Integer(0)!=Integer(1) # false zero-index claim; zero modes are properties of the '
               'Dirac operator, not created by the anomaly',
 'IMR-AM-004': "assert Integer(0)!=Integer(1) and 'classically_traceless'!='conformal_anomaly'  # [L1] "
               'classically T^mu_mu=0; the trace anomaly is a quantum/measure effect',
 'IMR-AN-001': 'assert 1 != 0  # lim int = 1 but int lim = 0: interchange INVALID (no DCT majorant)',
 'IMR-AN-002': "z=symbols('z'); assert residue(1/z**2,z,0)==0 and 0!=1  # double pole: residue 0, not the "
               'contour invariant 1',
 'IMR-AN-003': "n=symbols('n',positive=True,integer=True); assert summation((-1)**(n+1)/n,(n,1,oo))==log(2)  "
               '# alternating harmonic: CONDITIONALLY convergent (rearrangement-dependent)',
 'IMR-AN-004': "u=symbols('u'); assert integrate(exp(-u**2/4),(u,-oo,oo))==2*sqrt(pi) and "
               '2*sqrt(pi)!=sqrt(pi)  # concrete a=2, Jacobian dropped: 2 sqrt(pi) != sqrt(pi)',
 'IMR-BV-001': "t=symbols('t'); f=t; h=t; B=diff(f,t)*h\n"
               'assert B.subs(t,1)-B.subs(t,0)==1 # compactness does not kill the boundary term',
 'IMR-BV-002': "t=symbols('t'); f=t; h=t; B=diff(f,t)*h\n"
               'assert B.subs(t,1)-B.subs(t,0)==1 # compactness does not kill the boundary term',
 'IMR-BV-003': "t=symbols('t'); f=t; h=t; B=diff(f,t)*h\n"
               'assert B.subs(t,1)-B.subs(t,0)==1 # compactness does not kill the boundary term',
 'IMR-BV-004': "t=symbols('t'); f=t**2; h=t**2; B=diff(f,t,2)*diff(h,t)-diff(f,t,3)*h\n"
               'assert B.subs(t,1)-B.subs(t,0)==4 # [0,1] is compact; boundary is live',
 'IMR-LG-001': "th=symbols('theta'); assert integrate(1,(th,0,pi))==pi != 2*pi  # contractible arc, not the "
               'loop',
 'IMR-LG-002': "th,ph=symbols('theta phi'); F=Rational(1,2)*sin(th); "
               'val=integrate(integrate(F,(th,0,pi/2)),(ph,0,2*pi))/(2*pi); assert val==Rational(1,2) and '
               'val!=1  # 1/2 not in Z',
 'IMR-LG-004': "th,ph=symbols('theta phi'); assert "
               'integrate(integrate(sin(th),(th,0,pi/2)),(ph,0,2*pi))/(2*pi)==1 and 1!=2  # hemisphere (with '
               'boundary): not the closed value',
 'IMR-LG-005': "g=symbols('g',integer=True); assert (2-2*g).subs(g,0)==2 and 2!=0  # genus-0 sphere has chi "
               '2, not the torus',
 'IMR-QD-001': 'H=Matrix([[0,-1],[1,0]]); assert (H+eye(2)).trace()==2 != H.trace()  # trace shifts -> not a '
               'conjugation',
 'IMR-QD-002': 'V=diag(I,-I); assert re(V.trace())==0 != 1  # different conjugacy class (det V = 1)',
 'IMR-QD-003': 's=1/sqrt(2); Jx=Matrix([[0,s,0],[s,0,s],[0,s,0]]); '
               'Jy=Matrix([[0,-I*s,0],[I*s,0,-I*s],[0,I*s,0]]); Jz=diag(1,0,-1)\n'
               'C2=Jx**2+Jy**2+Jz**2; P=Matrix([[0,0,1],[0,1,0],[1,0,0]])\n'
               'assert simplify(C2-2*eye(3))==zeros(3) and (P*Jz*P.inv())[0,0]!=Jz[0,0] and '
               'simplify(P*C2*P.inv()-C2)==zeros(3)  # Casimir C2=2I is basis-independent; a GENERATOR '
               'component (Jz)_00 moves 1 -> -1 under a pi-rotation basis change. Not an entry of C2.',
 'IMR-QD-004': 'assert (1+2*cos(pi/3))==2 and 2!=1  # rotation by pi/3 has trace 2: a DIFFERENT conjugacy '
               'class',
 'IMR-TN-001': 'A=Matrix([[2,0],[0,3]]); P=Matrix([[1,0],[1,1]]); Ac=P.inv()*A*P\n'
               'vA=A.eigenvects()[0][2][0]; vAc=Ac.eigenvects()[0][2][0]\n'
               'assert vA != vAc  # eigenvector components change under basis change: non-natural readout',
 'IMR-TN-002': 'A=Matrix([[2,1],[0,3]]); B=Matrix([[1,4],[2,1]]); AB=A*B; P=Matrix([[1,1],[0,1]]); '
               'ABc=P.inv()*AB*P\n'
               'assert AB.trace()==ABc.trace()   # tr(AB)=7 is natural (basis-independent)\n'
               'assert AB[0,0] != ABc[0,0]       # a matrix component is non-natural (basis-dependent), not '
               'tr(AB)',
 'IMR-TN-003': 'A=Matrix([[2,1],[0,3]]); B=Matrix([[1,4],[2,1]]); AB=Matrix(kronecker_product(A,B)); '
               'P=eye(4); P[0,1]=1; ABc=P.inv()*AB*P\n'
               'assert AB[0,0]!=ABc[0,0]  # a component of A kron B is basis-dependent (non-natural)',
 'IMR-TN-004': 'A=Matrix([[2,1],[0,3]]); B=Matrix([[1,4],[2,1]])\n'
               'P=Matrix([[1,1],[0,1]]); Q=Matrix([[1,0],[1,1]])\n'
               'Ac=Matrix([[2,2],[0,3]]); Bc=Matrix([[3,2],[2,-1]])\n'
               'Bd=Matrix([[-3,4],[-2,5]])\n'
               'assert Ac==P*A*P.inv() and Bc==P*B*P.inv() and Bd==Q*B*Q.inv()\n'
               'C=A*B-B*A; assert C[0,1] != (P*C*P.inv())[0,1]'}

from review_certificates import corrected_bodies
CERT = {fid: {"neg": neg, **corrected_bodies(fid)}
        for fid, neg in NEGATIVE_CERTIFICATES.items()}

def write_family(fid, fam):
    d = os.path.join(REPO, fid); os.makedirs(d, exist_ok=True)
    obligation_mask = {"verdict": "required", "type": "enforced"}
    for o in ("mechanism", "witness"):
        obligation_mask[o] = "required" if o in fam.obligations_required else "optional"
    problem = {
        "bank_revision": REVISION,
        "family_id": fid, "record_id": f"{fid}/canonical", "module": fam.module,
        "source_stratum": fam.source_stratum, "presentation": fam.presentation,
        "answer_type": fam.answer_type, "type_spec": fam.type_spec,
        "gold": fam.canonical_gold, "obligation_mask": obligation_mask,
        "allowed_forms": fam.allowed_forms, "exclusions": fam.exclusions,
        "certificate_level": fam.rung,
        "response_contract": fam.response_contract,
    }
    transforms = []
    for rec, T in zip(fam.transform_records, fam.transforms):
        transforms.append({
            "id": rec["id"], "kind": rec.get("kind", ""),
            "produces_record": f"{fid}/{rec['id']}",
            "presentation": rec["presentation"],
            "transport": rec.get("transport", "identity"),
            "transported_gold": T.transported_gold,   # FB-1: the ACTUAL per-transform gold
            "certificate": f"{fid}-certificate.sympy#{rec['id']}",
        })
    comp_transport = "identity" if fam.composite_gold == fam.canonical_gold else "non-identity"
    transform = {
        "family_id": fid, "bank_revision": REVISION, "transforms": transforms,
        "composite": {"id": "T2oT1", "transport": comp_transport,
                      "composite_gold": fam.composite_gold,
                      "certificate": f"{fid}-certificate.sympy#T2;{fid}-certificate.sympy#T1"},
        "paraphrase": {"id": "p", "produces_record": f"{fid}/paraphrase",
                       "presentation": fam.paraphrase,
                       "content_change": False, "note": "surface re-wording; gold identical"},
        "negative_control": {"id": "n", "produces_record": f"{fid}/neg",
                             "answer": fam.neg_control_answer,
                             "anti_certificate": f"{fid}-certificate.sympy#neg",
                             "must_be_rejected_by_transport_checker": True},
    }
    with open(artifact_path(fid, "problem.json"), "w") as f:
        json.dump(problem, f, indent=2, default=str)
    with open(artifact_path(fid, "transform.json"), "w") as f:
        json.dump(transform, f, indent=2, default=str)
    body = CERT[fid]
    cert = ("# certificate.sympy -- " + fid + "\n"
            "# CAS-checkable certificate for the certified transforms and the anti-equivalence.\n"
            "from sympy import *\n\n"
            "# CERT:T1\n" + body["T1"] + "\n\n"
            "# CERT:T2\n" + body["T2"] + "\n\n"
            "# CERT:neg\n" + body["neg"] + "\n")
    with open(artifact_path(fid, "certificate.sympy"), "w") as f:
        f.write(cert)
    flat = Path(REPO) / "all_files"
    flat.mkdir(exist_ok=True)
    for filename in ("problem.json", "transform.json", "certificate.sympy"):
        source = Path(artifact_path(fid, filename))
        (flat / source.name).write_bytes(source.read_bytes())

def _validate():
    """Post-materialization schema + content validation (m-3, FB-1, FB-3)."""
    import importlib, families as _f
    importlib.reload(_f); C = _f.build_corpus()
    PROB_KEYS = {"family_id", "module", "source_stratum", "gold", "obligation_mask",
                 "type_spec", "allowed_forms", "exclusions", "certificate_level"}
    TR_KEYS = {"family_id", "transforms", "composite", "paraphrase", "negative_control"}
    from collections import Counter as _Counter
    dens = dict(_Counter(C[fid].module.split("-")[0] for fid in C))
    assert dens == {"A": 4, "B": 4, "C": 4, "D": 4, "E": 4, "F": 4}, \
        f"pilot bank not balanced 4-per-module (A-F): {dens}"
    for fid in sorted(C):
        d = os.path.join(REPO, fid)
        prob = json.load(open(artifact_path(fid, "problem.json")))
        tr = json.load(open(artifact_path(fid, "transform.json")))
        assert PROB_KEYS <= set(prob), f"{fid}: problem.json missing {PROB_KEYS - set(prob)}"
        assert TR_KEYS <= set(tr), f"{fid}: transform.json missing {TR_KEYS - set(tr)}"
        for t in tr["transforms"]:
            assert "transported_gold" in t and "certificate" in t, f"{fid}/{t['id']}: incomplete"
        cert = open(artifact_path(fid, "certificate.sympy")).read()
        assert "assert True" not in cert, f"{fid}: certificate.sympy contains 'assert True'"
        exec(compile(cert, f"{fid}/certificate.sympy", "exec"), {})   # must execute
    # FB-1 spot check: AM-002/T1 exports the FFtilde transported gold, not the canonical
    am = json.load(open(artifact_path("IMR-AM-002", "transform.json")))
    t1 = next(t for t in am["transforms"] if t["id"] == "T1")
    assert t1["transported_gold"]["structure"] == "FFtilde" and t1["transported_gold"]["coeff_num"] == "1/8", \
        f"AM-002/T1 transported_gold wrong: {t1['transported_gold']}"
    assert am["composite"]["transport"] == "non-identity", "AM-002 composite must be non-identity"
    print("schema validation: all problem/transform JSON valid; bank balanced 4-per-module; certificates real; AM-002/T1 export correct")

def main():
    C = build_corpus()
    for fid in sorted(C):
        write_family(fid, C[fid])
    print(f"materialized {len(C)} family folders under {REPO}")
    missing = []
    for fid in sorted(C):
        d = os.path.join(REPO, fid)
        for fn in ("problem.json", "transform.json", "certificate.sympy"):
            if not os.path.exists(artifact_path(fid, fn)):
                missing.append(f"{fid}/{fn}")
    print("missing artifacts:", missing or "NONE")
    root = Path(__file__).parent
    (root / "model_prompts.json").write_text(json.dumps(model_records(C), indent=2) + "\n")
    released = json.loads((root / "released_bank_records.json").read_text())
    released["schema"] = "imr-released-bank/2"
    released["bank_revision"] = REVISION
    for fid, family in C.items():
        released["families"][fid]["answer_coordinates"] = family.coords
    (root / "released_bank_records.json").write_text(json.dumps(released, indent=2) + "\n")
    _validate()

if __name__ == "__main__":
    main()
