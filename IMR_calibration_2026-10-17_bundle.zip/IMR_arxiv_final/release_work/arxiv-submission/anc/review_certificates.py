"""Certificate bodies for the actual September-review presentations.

Each emitted body is standalone SymPy source. The anomaly families retain
their literature-backed L1 status: gamma traces check conventions, not the
analytic hypotheses of the index theorem or the regulator construction.
"""

MATRICES = {
    'IMR-QD-001': ('H=Matrix([[0,-1],[1,0]])',
        'P=Matrix([[1,1],[0,1]]); V=Matrix([[1,-2],[1,-1]])',
        'P=diag(2,1); V=Matrix([[0,-2],[Rational(1,2),0]])'),
    'IMR-QD-002': ('H=diag((1+I*sqrt(3))/2,(1-I*sqrt(3))/2)',
        'P=Matrix([[1,1],[0,1]]); V=Matrix([[(1+I*sqrt(3))/2,-I*sqrt(3)],[0,(1-I*sqrt(3))/2]])',
        'P=Matrix([[1,1],[I,-I]])/sqrt(2); V=Matrix([[Rational(1,2),sqrt(3)/2],[-sqrt(3)/2,Rational(1,2)]])'),
    'IMR-QD-004': ('H=Matrix([[0,-1,0],[1,0,0],[0,0,1]])',
        'P=Matrix([[0,0,1],[1,0,0],[0,1,0]]); V=Matrix([[1,0,0],[0,0,-1],[0,1,0]])',
        'P=Matrix([[0,1,0],[0,0,1],[1,0,0]]); V=Matrix([[0,0,1],[0,1,0],[-1,0,0]])'),
    'IMR-TN-001': ('H=Matrix([[2,1],[0,3]])',
        'P=Matrix([[1,1],[0,1]]); V=Matrix([[2,2],[0,3]])',
        'P=Matrix([[1,0],[1,1]]); V=Matrix([[1,1],[-2,4]])'),
}

FIRST_ORDER_CASES = '''
# Independent endpoint-jet check: each positive condition annihilates the
# integrated boundary term for arbitrary remaining jets. Closed domains have
# no boundary; interior-supported variations have zero boundary jet.
p0,p1,h0,h1=symbols('p0 p1 h0 h1')
B=p1*h1-p0*h0
assert B.subs({h0:0,h1:0})==0                # Dirichlet / fixed endpoints
assert B.subs({p0:0,p1:0})==0                # homogeneous Neumann
assert B.subs({p1:p0,h1:h0})==0             # periodic matched data
t=symbols('t'); phi=t; h=3*t**2-2*t**3
assert diff(h,t).subs(t,0)==diff(h,t).subs(t,1)==0
assert (diff(phi,t)*h).subs(t,1)-(diff(phi,t)*h).subs(t,0)==1
# Thus fixed nonzero Neumann data do NOT suffice without a boundary action.
'''

FOURTH_ORDER_CASES = '''
p2,p3,h,h1=symbols('p2 p3 h h1'); B=p2*h1-p3*h
assert B.subs({h:0,h1:0})==0                 # clamped variations
assert B.subs({p2:0,p3:0})==0                # free natural data
assert B.subs({p2:0,h:0})==0                 # simply supported
# Interior support kills h,h1. Periodic jets give the same B at both endpoints.
a2,a3,u,u1=symbols('a2 a3 u u1')
assert (B-(a2*u1-a3*u)).subs({p2:a2,p3:a3,h:u,h1:u1})==0
t=symbols('t')
def endpoint(phi,h):
    b=diff(phi,t,2)*diff(h,t)-diff(phi,t,3)*h
    return b.subs(t,1)-b.subs(t,0)
assert endpoint(t**2,t*(1-t))==-4           # Dirichlet alone fails
assert endpoint(t**4,Integer(1))==-24      # Neumann variation alone fails
assert endpoint(t**2,t**2)==4               # compact interval alone fails
'''

def corrected_bodies(fid):
    if fid in MATRICES:
        start, t1, t2 = MATRICES[fid]
        check = ('\nassert simplify(P*H*P.inv()-V)==zeros(H.rows)\n'
                 'assert simplify(V.trace()-H.trace())==0\n'
                 'assert simplify(V.det()-H.det())==0\n'
                 "lam=symbols('lam'); assert simplify((lam*eye(H.rows)-V).det()-(lam*eye(H.rows)-H).det())==0")
        return {'T1': start+'\n'+t1+check, 'T2': start+'\n'+t2+check}
    if fid == 'IMR-QD-003':
        base = '''s=1/sqrt(2)
Jx=s*Matrix([[0,1,0],[1,0,1],[0,1,0]])
Jy=s*Matrix([[0,-I,0],[I,0,-I],[0,I,0]])
Jz=diag(1,0,-1)
'''
        end = '''
assert simplify(X-P*Jx*P.inv())==zeros(3)
assert simplify(Y-P*Jy*P.inv())==zeros(3)
assert P*Jz*P.inv()==Jz
assert simplify(X**2+Y**2+Jz**2)==2*eye(3)
'''
        return {
            'T1': base+'''P=diag(2,1,1)
X=s*Matrix([[0,2,0],[Rational(1,2),0,1],[0,1,0]])
Y=s*Matrix([[0,-2*I,0],[I/2,0,-I],[0,I,0]])'''+end,
            'T2': base+'''P=diag(I,1,1)
X=s*Matrix([[0,I,0],[-I,0,1],[0,1,0]])
Y=s*Matrix([[0,1,0],[1,0,-I],[0,I,0]])'''+end}
    if fid.startswith('IMR-TN-'):
        base = '''A=Matrix([[2,1],[0,3]]); B=Matrix([[1,4],[2,1]])
P=Matrix([[1,1],[0,1]]); Q=Matrix([[1,0],[1,1]])
Ac=Matrix([[2,2],[0,3]]); Bc=Matrix([[3,2],[2,-1]])
Bd=Matrix([[-3,4],[-2,5]])
assert Ac==P*A*P.inv() and Bc==P*B*P.inv() and Bd==Q*B*Q.inv()
'''
        if fid == 'IMR-TN-002':
            return {'T1':base+'assert (Ac*Bc).trace()==7 and (Ac*Bc).det()==-42',
                    'T2':base+'assert (B*A).trace()==7 and (B*A).det()==-42'}
        if fid == 'IMR-TN-003':
            return {'T1':base+'assert kronecker_product(Ac,Bc).det()==1764',
                    'T2':base+'assert kronecker_product(Ac,Bd).det()==1764'}
        return {'T1':base+'assert (Ac*Bc-Bc*Ac).trace()==0',
                'T2':base+'assert (Ac*Bd-Bd*Ac).trace()==0',
                'neg':base+'C=A*B-B*A; assert C[0,1] != (P*C*P.inv())[0,1]'}
    if fid == 'IMR-LG-001':
        return {'T1':"t=symbols('t'); assert integrate(1-sin(t),(t,0,2*pi))==2*pi",
                'T2':"t=symbols('t'); f=t+sin(t)/2; assert diff(f,t)==1+cos(t)/2; assert integrate(diff(f,t),(t,0,2*pi))==2*pi\n# f'>=1/2: degree-one, orientation-preserving circle diffeomorphism."}
    if fid == 'IMR-LG-002':
        return {'T1':"t,p=symbols('t p'); F=sin(t)/2+2*sin(t)*cos(t); beta=sin(t)**2\nassert simplify(F-sin(t)/2-diff(beta,t))==0\nassert integrate(integrate(F,(t,0,pi)),(p,0,2*pi))/(2*pi)==1\n# beta*dphi = x*dy-y*dx on S^2, hence a global smooth one-form.",
                'T2':"t,p=symbols('t p'); phi=p+sin(t)*sin(p)/2; F=sin(t)*(1+sin(t)*cos(p)/2)/2\nassert simplify(F-sin(t)*diff(phi,p)/2)==0\nassert integrate(integrate(F,(p,0,2*pi)),(t,0,pi))/(2*pi)==1\n# dphi/dp>=1/2; in Cartesian coordinates this rotates (x,y) by y/2, smooth at the poles."}
    if fid == 'IMR-LG-004':
        return {'T1':"t,p=symbols('t p'); K=Rational(1,4); dA=4*sin(t); assert integrate(integrate(K*dA,(t,0,pi)),(p,0,2*pi))/(2*pi)==2",
                'T2':"t=symbols('t'); f=t+sin(2*t)/4; a=diff(f,t); b=sin(f)\n# For ds^2=a^2 dt^2+b^2 dphi^2, K dA=-d(b'/a)/dt dt dphi.\nassert simplify(diff(b,t)/a-cos(f))==0\nassert f.subs(t,0)==0 and f.subs(t,pi)==pi\nassert (-cos(f)).subs(t,pi)-(-cos(f)).subs(t,0)==2\n# a=1+cos(2t)/2>=1/2; the polar reparametrization is smooth and invertible."}
    if fid == 'IMR-LG-005':
        return {'T1':"x,y=symbols('x y'); assert integrate(integrate(Integer(0),(x,0,2*pi)),(y,0,2*pi))==0 # constant flat metric",
                'T2':"x,y=symbols('x y'); u=cos(x); K=-exp(-2*u)*(diff(u,x,2)+diff(u,y,2)); dA=exp(2*u)\nassert simplify(K*dA)==cos(x)\nassert integrate(integrate(simplify(K*dA),(x,0,2*pi)),(y,0,2*pi))/(2*pi)==0"}
    if fid == 'IMR-AN-001':
        return {'T1':"n=symbols('n',positive=True,integer=True); u=symbols('u'); assert integrate(n/2,(u,0,2/n))==1\n# For any u>0, f_n(u)=0 once n>2/u, so the almost-everywhere limit is zero.",
                'T2':"n=symbols('n',positive=True,integer=True); x=symbols('x'); assert integrate(n+1,(x,0,1/(n+1)))==1\n# For any x>0, the shifted sequence is eventually zero; integral of the a.e. limit is zero."}
    if fid == 'IMR-AN-002':
        return {'T1':"t=symbols('t',real=True); z=2*cos(t)+I*sin(t); velocity=diff(z,t)/z\nassert simplify(im(velocity)-2/(1+3*cos(t)**2))==0\nu=symbols('u',real=True); assert 4*integrate(2/(u**2+4),(u,0,oo))==2*pi\nassert integrate(re(velocity),(t,0,2*pi))==0\n# Counterclockwise ellipse, winding +1, contour integral 2*pi*i; residue is 1.",
                'T2':"w,t=symbols('w t'); f=2/(2*w+1); assert residue(f,w,-Rational(1,2))==1\ngamma=(exp(I*t)-1)/2; assert simplify(f.subs(w,gamma)*diff(gamma,t))==I"}
    if fid == 'IMR-AN-003':
        return {'T1':"k=symbols('k',positive=True,integer=True); pair=1/(2*k)**2+1/(2*k-1)**2\nassert summation(pair,(k,1,oo))==pi**2/6 # swap adjacent terms of an absolutely convergent positive series",
                'T2':"x=symbols('x',positive=True); n=symbols('n',positive=True,integer=True)\n# 1/n^2 = int_0^1 (-log(x))*x^(n-1) dx. The three residue classes sum to the same positive kernel.\nassert cancel((1+x+x**2)/(1-x**3)-1/(1-x))==0\nassert summation(1/n**2,(n,1,oo))==pi**2/6 # Tonelli justifies grouping the nonnegative terms"}
    if fid == 'IMR-AN-004':
        return {'T1':"u=symbols('u',real=True); assert integrate(exp(-u**2/4)/2,(u,-oo,oo))==sqrt(pi)",
                'T2':"u=symbols('u',real=True); assert -integrate(exp(-(-u)**2),(u,oo,-oo))==sqrt(pi)"}
    if fid.startswith('IMR-BV-'):
        if fid == 'IMR-BV-004':
            bulk = "t=symbols('t'); f=Function('phi')(t); h=Function('h')(t)\nB=diff(f,t,2)*diff(h,t)-diff(f,t,3)*h\nassert simplify(diff(f,t,2)*diff(h,t,2)-diff(f,t,4)*h-diff(B,t))==0"
            return {'T1':bulk,'T2':bulk+'\n'+FOURTH_ORDER_CASES,
                    'neg':"t=symbols('t'); f=t**2; h=t**2; B=diff(f,t,2)*diff(h,t)-diff(f,t,3)*h\nassert B.subs(t,1)-B.subs(t,0)==4 # [0,1] is compact; boundary is live"}
        bulk = "t=symbols('t'); f=Function('phi')(t); h=Function('h')(t); mass=symbols('mass')\nL=diff(f,t)*diff(h,t)-mass**2*f*h\nassert simplify(L-(-diff(f,t,2)-mass**2*f)*h-diff(diff(f,t)*h,t))==0"
        if fid == 'IMR-BV-001': bulk=bulk.replace('mass**2','Integer(0)')
        if fid == 'IMR-BV-002':
            bulk += "\nx=symbols('x0:4'); f=Function('phi')(*x); h=Function('h')(*x); signs=(1,-1,-1,-1)\nbox=sum(s*diff(f,c,2) for s,c in zip(signs,x))\nkinetic=sum(s*diff(f,c)*diff(h,c) for s,c in zip(signs,x))\nflux_div=sum(diff(s*h*diff(f,c),c) for s,c in zip(signs,x))\nassert simplify(kinetic-mass**2*f*h-(-box-mass**2*f)*h-flux_div)==0"
        return {'T1':bulk, 'T2':bulk+'\n'+FIRST_ORDER_CASES,
                'neg':"t=symbols('t'); f=t; h=t; B=diff(f,t)*h\nassert B.subs(t,1)-B.subs(t,0)==1 # compactness does not kill the boundary term"}
    if fid == 'IMR-AM-001':
        return {'T1':"q,F=symbols('q F01'); g0=Matrix([[0,1],[1,0]]); g1=Matrix([[0,-I],[I,0]]); star=I*g0*g1\nE=I*q*g0*g1*F; density=2*trace(star*E)/(4*pi)\nassert simplify(density-q*F/pi)==0 # local heat-kernel coefficient with exp(Dslash^2/Lambda^2)",
                'T2':"g0=Matrix([[0,1],[1,0]]); g1=Matrix([[0,-I],[I,0]])\nstar=I*g0*g1; Gamma=-I*g0*g1\nassert -Gamma==star # physical current unchanged"}
    if fid == 'IMR-AM-002':
        t1='''q=symbols('q'); f=symbols('F01 F02 F03 F12 F13 F23'); F=zeros(4)
for (a,b),v in zip(((0,1),(0,2),(0,3),(1,2),(1,3),(2,3)),f): F[a,b]=v; F[b,a]=-v
epsFF=sum(LeviCivita(a,b,c,d)*F[a,b]*F[c,d] for a in range(4) for b in range(4) for c in range(4) for d in range(4))
dual=Matrix(4,4,lambda a,b:sum(LeviCivita(a,b,c,d)*F[c,d] for c in range(4) for d in range(4))/2)
FFtilde=sum(F[a,b]*dual[a,b] for a in range(4) for b in range(4))
assert expand(epsFF-2*FFtilde)==0
s1=Matrix([[0,1],[1,0]]); s2=Matrix([[0,-I],[I,0]]); s3=diag(1,-1)
g=[kronecker_product(s1,eye(2)),kronecker_product(s2,eye(2)),kronecker_product(s3,s1),kronecker_product(s3,s2)]
star=-g[0]*g[1]*g[2]*g[3]
E=sum((I*q*g[a]*g[b]*F[a,b]/2 for a in range(4) for b in range(4)),zeros(4))
local_density=2*trace(star*E**2)/(2*(4*pi)**2)
assert simplify(local_density-q**2*epsFF/(16*pi**2))==0
assert simplify(local_density-q**2*FFtilde/(8*pi**2))==0
'''
        return {'T1':t1,'T2':t1+"\nassert simplify(2*trace((-star)*E**2)/(2*(4*pi)**2)-q**2*(-epsFF)/(16*pi**2))==0 # both epsilon and chirality reverse"}
    if fid == 'IMR-AM-003':
        return {'T1':"k,T_R=symbols('k T_R'); assert (2*T_R*k).subs({T_R:Rational(1,2),k:1})==1\n# L1 index theorem input; F=(1/2)F_mn dx^m wedge dx^n gives the factor 1/4.\nassert Rational(1,8)*Rational(1,4)==Rational(1,32)",
                'T2':"np,nm=symbols('n_plus n_minus',integer=True); mp,mm=nm,np\nassert mm-mp==np-nm # chirality relabelling, not a change of oriented index",
                'neg':"assert Integer(0)!=Integer(1) # false zero-index claim; zero modes are properties of the Dirac operator, not created by the anomaly"}
    if fid == 'IMR-AM-004':
        return {'T1':"a=symbols('a',positive=True); contractions=2*a**2/(4*a**2)\nassert contractions==Rational(1,2) # Wick double contraction: <dphi dphi>=-a/(z-w)^2, T=-(dphi)^2/(2a), so c/2=1/2",
                'T2':"chi=symbols('chi'); assert diff(4*pi*chi,chi)==4*pi\n# On a fixed closed topology int sqrt(g) R = 4*pi*chi is metric independent (Gauss-Bonnet), so its stress-tensor variation vanishes.\ns=symbols('s'); assert diff(4*pi*chi,s)==0"}
    raise KeyError(fid)
