"""Regressions for the defects documented in the two 27 September PDFs."""
import json
import re
from fractions import Fraction
from pathlib import Path

import pytest
import sympy as sp

from bank_presentations import PRESENTATIONS, model_records, REVISION
from boundary_contract import CASE_DEFINITIONS, case_set, polynomial
from core import render_gold
from families import build_corpus
from materialize_families import artifact_path

ROOT = Path(__file__).parent
CORPUS = build_corpus()

@pytest.mark.parametrize('fid', sorted(CORPUS))
def test_questions_and_exports_match(fid):
    family = CORPUS[fid]
    question = json.loads(Path(artifact_path(fid, 'problem.json')).read_text())
    transform = json.loads(Path(artifact_path(fid, 'transform.json')).read_text())
    assert question['presentation'] == PRESENTATIONS[fid]['canonical'] == family.presentation
    assert question['bank_revision'] == transform['bank_revision'] == REVISION
    assert transform['paraphrase']['presentation'] == family.paraphrase
    for arrow in transform['transforms']:
        assert arrow['presentation'] == PRESENTATIONS[fid][arrow['id']]
    for filename in ('problem.json', 'transform.json', 'certificate.sympy'):
        path = Path(artifact_path(fid, filename))
        assert path.read_bytes() == (ROOT/'families_repo/all_files'/path.name).read_bytes()
    for ref in [t['certificate'] for t in transform['transforms']] + [transform['negative_control']['anti_certificate']] + transform['composite']['certificate'].split(';'):
        name, anchor = ref.split('#')
        for folder in (ROOT/'families_repo'/fid, ROOT/'families_repo/all_files'):
            assert f'# CERT:{anchor}' in (folder/name).read_text()

def test_model_export_separates_answers_and_has_96_questions():
    generated = model_records(CORPUS)
    assert json.loads((ROOT/'model_prompts.json').read_text()) == generated
    records = generated['records']
    assert len(records) == len({r['record_id'] for r in records}) == 96
    for r in records:
        assert set(r) == {'family_id', 'record_id', 'presentation', 'answer_coordinates', 'type_spec'}
        text = r['presentation']
        assert len(text) > 100
        for banned in ('Your answer:', 'Answer unchanged', 'Models, original', 'under the convention ledger',
                       'A above', 'A, B as above', 'boundary_vanishes_iff', 'residue = 1',
                       'chi = 2 - 2g = 0', '= zeta(2) = pi^2/6', 'det(B)^2 = 1764'):
            assert banned not in text
    flat = ROOT/'families_repo/all_files'
    assert len([p for p in flat.iterdir() if p.name != '.DS_Store']) == 72

@pytest.mark.parametrize('fid', sorted(CASE_DEFINITIONS))
def test_boundary_sets_are_order_independent_and_reject_false_cases(fid):
    f = CORPUS[fid]; gold = f.canonical_gold
    cases = sorted(case_set(gold['boundary_cases']))
    reversed_answer = {**gold, 'boundary_cases': '{' + ', '.join(reversed(cases)) + '}'}
    parsed = f.normalizer(render_gold(reversed_answer, f.coords))
    assert parsed is not None and f.eqf(parsed[0], gold)
    assert f.distf(parsed[0], gold) == 0
    assert 'periodic' in cases and 'interior_support' in cases
    for bad in set(CASE_DEFINITIONS[fid]) - set(cases):
        wrong = {**gold, 'boundary_cases': '{' + ','.join(cases+[bad]) + '}'}
        assert not f.eqf(wrong, gold)
        assert f.distf(wrong, gold) == pytest.approx(1/3)
    # The question asks ALL sufficient cases from the finite menu; omission is
    # an error here, unlike the old open-ended "give familiar conditions" task.
    missing = {**gold, 'boundary_cases': '{' + ','.join(cases[1:]) + '}'}
    assert not f.eqf(missing, gold)
    legacy = {'bulk': gold['bulk'], 'boundary_vanishes_iff': '{compact}'}
    assert f.normalizer(render_gold(legacy, list(legacy))) is None
    for bad in ('{compact}', '{Neumann}', '{periodic,periodic}', '{periodic,unknown}'):
        assert f.normalizer(render_gold({**gold, 'boundary_cases': bad}, f.coords)) is None

@pytest.mark.parametrize('fid', sorted(CASE_DEFINITIONS))
def test_boundary_flux_and_signed_bulk_are_scored(fid):
    f=CORPUS[fid]; g=f.canonical_gold
    equivalent={**g,'bulk': f'2*({g["bulk"]})/2', 'boundary_term':f'({g["boundary_term"]})+h-h'}
    assert f.eqf(equivalent,g)
    assert f.normalizer(render_gold(equivalent,f.coords)) is not None
    # Equation classes can ignore a scalar factor; the signed first variation cannot.
    assert not f.eqf({**g, 'bulk': f'-({g["bulk"]})'},g)
    assert not f.eqf({**g, 'boundary_term':'0'},g)
    assert not f.eqf({**g, 'boundary_term':f'-({g["boundary_term"]})'},g)
    assert f.anti_certificate(f.neg_control_answer,g)
    assert not f.eqf(f.neg_control_answer,g)

def test_boundary_golds_from_independent_variations():
    t,m,w=sp.symbols('t m w'); p=sp.Function('phi')(t); h=sp.Function('h')(t)
    eps=sp.Symbol('eps')
    for fid,lagrangian,bulk,boundary in [
        ('IMR-BV-001',sp.diff(p+eps*h,t)**2/2,-sp.diff(p,t,2),sp.diff(p,t)*h),
        ('IMR-BV-003',(sp.diff(p+eps*h,t)**2-w**2*(p+eps*h)**2)/2,-sp.diff(p,t,2)-w**2*p,sp.diff(p,t)*h),
        ('IMR-BV-004',sp.diff(p+eps*h,t,2)**2/2,sp.diff(p,t,4),sp.diff(p,t,2)*sp.diff(h,t)-sp.diff(p,t,3)*h),
    ]:
        variation=sp.diff(lagrangian,eps).subs(eps,0)
        assert sp.simplify(variation-bulk*h-sp.diff(boundary,t))==0
        substitutions={sp.Symbol('lap_phi'):sp.diff(p,t,2),sp.Symbol('dn_phi'):sp.diff(p,t),
                       sp.Symbol('x'):p,sp.Symbol('xdot'):sp.diff(p,t),sp.Symbol('xddot'):sp.diff(p,t,2),
                       sp.Symbol('h'):h,sp.Symbol('phi2'):sp.diff(p,t,2),sp.Symbol('phi3'):sp.diff(p,t,3),
                       sp.Symbol('phi4'):sp.diff(p,t,4),sp.Symbol('h1'):sp.diff(h,t)}
        gold=CORPUS[fid].canonical_gold
        assert sp.simplify(polynomial(gold['bulk']).subs(substitutions)-bulk)==0
        assert sp.simplify(polynomial(gold['boundary_term']).subs(substitutions)-boundary)==0
    # Mostly-minus Minkowski convention and the full oriented flux vector.
    coords=sp.symbols('x0:4'); p=sp.Function('phi')(*coords); h=sp.Function('h')(*coords)
    signs=(1,-1,-1,-1)
    lag=(sum(s*sp.diff(p+eps*h,x)**2 for s,x in zip(signs,coords))-m**2*(p+eps*h)**2)/2
    box=sum(s*sp.diff(p,x,2) for s,x in zip(signs,coords))
    div=sum(sp.diff(s*h*sp.diff(p,x),x) for s,x in zip(signs,coords))
    assert sp.simplify(sp.diff(lag,eps).subs(eps,0)-(-box-m**2*p)*h-div)==0
    gold=CORPUS['IMR-BV-002'].canonical_gold
    assert sp.simplify(polynomial(gold['bulk']).subs({sp.Symbol('box_phi'):box,sp.Symbol('phi'):p})+box+m**2*p)==0
    assert polynomial(gold['boundary_term'])==sp.Symbol('h')*sp.Symbol('dmu_phi')

@pytest.mark.parametrize('expression', ["__import__('os').system('false')",'h.__class__', 'h[0]',
                                      'sin(h)', 'h/0', 'h^100', 'h+unknown','1.0*h'])
def test_boundary_parser_rejects_unsupported_expressions(expression):
    with pytest.raises(ValueError): polynomial(expression)

def test_final_answer_overrides_intermediate_work():
    f=CORPUS['IMR-TN-002']
    parsed=f.normalizer('A mistaken intermediate result: tr_AB = 0; det_AB = 0\n'
                        'Correcting this by direct multiplication.\nFINAL ANSWER: tr_AB = 7; det_AB = -42')
    assert parsed is not None and f.eqf(parsed[0], f.canonical_gold)
    assert parsed[1]['mechanism']

def test_am002_physical_density_equivalence_and_wrong_pair_rejection():
    f=CORPUS['IMR-AM-002']; gold=f.canonical_gold
    correct={'coeff_num':Fraction(1,8),'structure':'FFtilde','origin':'measure_jacobian'}
    assert f.eqf(gold,correct) and f.distf(gold,correct)==0
    assert f.normalizer('FINAL ANSWER: coeff_num = 1/8; structure = FFtilde; origin = measure_jacobian') is not None
    assert f.normalizer('FINAL ANSWER: coeff_num = 1/0; structure = epsFF; origin = measure_jacobian') is None
    for wrong in ({**correct,'coeff_num':Fraction(1,16)}, {**gold,'coeff_num':Fraction(1,8)},
                  {**gold,'origin':'classical_action'}, {**gold,'coeff_num':'1/0'},
                  {**gold,'structure':'undefined'}):
        assert not f.eqf(wrong,gold)

def matrix_in(fid, arm, name):
    # These are trusted, versioned bank inputs, never model-supplied responses.
    match=re.search(r'\b'+re.escape(name)+r'\s*=\s*(?:\(1/sqrt\(2\)\)\*)?(\[\[.*?\]\])', PRESENTATIONS[fid][arm])
    assert match,(fid,arm,name)
    return sp.Matrix(sp.sympify(match[1],locals={'i':sp.I,'sqrt':sp.sqrt}))

@pytest.mark.parametrize('fid', ['IMR-QD-001','IMR-QD-004','IMR-TN-001'])
def test_question_matrices_are_actual_conjugates(fid):
    name='R' if fid=='IMR-QD-004' else 'A'
    A=matrix_in(fid,'canonical',name)
    assert matrix_in(fid,'paraphrase',name)==A
    Ps={'IMR-QD-001':[sp.Matrix([[1,1],[0,1]]),sp.diag(2,1)],
        'IMR-TN-001':[sp.Matrix([[1,1],[0,1]]),sp.Matrix([[1,0],[1,1]])],
        'IMR-QD-004':[sp.Matrix([[0,0,1],[1,0,0],[0,1,0]]),sp.Matrix([[0,1,0],[0,0,1],[1,0,0]])]}
    for arm,P in zip(('T1','T2'),Ps[fid]):
        assert matrix_in(fid,arm,name)==P*A*P.inv()
    gold=CORPUS[fid].canonical_gold
    assert A.trace()==gold['trace'] and A.det()==gold['det']
    if 'char_poly' in gold:
        lam=sp.Symbol('lam'); assert sp.expand((lam*sp.eye(2)-A).det()-sp.sympify(gold['char_poly'].replace('^','**').replace('5lam','5*lam')))==0

@pytest.mark.parametrize('fid',['IMR-TN-002','IMR-TN-003','IMR-TN-004'])
def test_question_tensor_matrices_match_certified_moves(fid):
    A=matrix_in(fid,'canonical','A'); B=matrix_in(fid,'canonical','B')
    P=sp.Matrix([[1,1],[0,1]]); Q=sp.Matrix([[1,0],[1,1]])
    assert A*B==sp.Matrix([[4,9],[6,3]])
    for arm in ('canonical','T1','T2','paraphrase'):
        a=matrix_in(fid,arm,'A'); b=matrix_in(fid,arm,'B')
        if arm=='T1': assert a==P*A*P.inv() and b==P*B*P.inv()
        elif arm=='T2' and fid!='IMR-TN-002': assert a==P*A*P.inv() and b==Q*B*Q.inv()
        else: assert a==A and b==B
        if fid=='IMR-TN-002': assert (a*b).trace()==7 and (a*b).det()==-42
        if fid=='IMR-TN-003': assert sp.kronecker_product(a,b).det()==1764
        if fid=='IMR-TN-004': assert (a*b-b*a).trace()==0

def test_question_spin_and_holonomy_matrices():
    fid='IMR-QD-003'
    canonical=[matrix_in(fid,'canonical',n)/sp.sqrt(2) for n in ('J_x','J_y')]+[sp.diag(1,0,-1)]
    for arm,P in [('canonical',sp.eye(3)),('paraphrase',sp.eye(3)),('T1',sp.diag(2,1,1)),('T2',sp.diag(sp.I,1,1))]:
        actual=[matrix_in(fid,arm,n)/sp.sqrt(2) for n in ('J_x','J_y')]+[sp.diag(1,0,-1)]
        assert all(sp.simplify(a-P*b*P.inv())==sp.zeros(3) for a,b in zip(actual,canonical))
        assert sp.simplify(sum((a*a for a in actual),sp.zeros(3)))==2*sp.eye(3)
    U=sp.diag((1+sp.I*sp.sqrt(3))/2,(1-sp.I*sp.sqrt(3))/2)
    for arm,P in [('T1',sp.Matrix([[1,1],[0,1]])),('T2',sp.Matrix([[1,1],[sp.I,-sp.I]])/sp.sqrt(2))]:
        actual=matrix_in('IMR-QD-002',arm,'U')
        assert sp.simplify(actual-P*U*P.inv())==sp.zeros(2)
        assert sp.simplify(actual.trace())==1

def test_review_curvature_is_unit_chern_class_and_transform_is_smooth():
    text=PRESENTATIONS['IMR-LG-002']
    assert 'F = (1/2)*sin(theta)' in text['canonical']
    assert '2*sin(theta)*cos(theta)' in text['T1']
    assert '(1+(1/2)*sin(theta)*cos(psi))' in text['T2']
    theta,psi=sp.symbols('theta psi',real=True)
    fields=[sp.sin(theta)/2,sp.sin(theta)/2+2*sp.sin(theta)*sp.cos(theta),
            sp.sin(theta)*(1+sp.sin(theta)*sp.cos(psi)/2)/2]
    assert all(sp.integrate(sp.integrate(F,(psi,0,2*sp.pi)),(theta,0,sp.pi))/(2*sp.pi)==1 for F in fields)
    # The review's prose says 2*sin(theta), which would give four instead.
    assert sp.integrate(sp.integrate(2*sp.sin(theta),(psi,0,2*sp.pi)),(theta,0,sp.pi))/(2*sp.pi)==4
