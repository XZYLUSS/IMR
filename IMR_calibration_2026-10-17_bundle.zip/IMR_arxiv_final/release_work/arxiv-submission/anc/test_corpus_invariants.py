"""
The eight family unit-test invariants (I2 Def M.1), run on all ten pilot families,
plus dedicated tests for the post-review hardening (FB-2 composition, FB-4 parser).
"""
import sys, os
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.dirname(_HERE))
import pytest
from fractions import Fraction
from families import build_corpus
from materialize_families import artifact_path
from core import (PARSE_FAIL, Transform, compose_transforms, check_composition_law,
                  check_functorial_laws, render_gold, eq_tuple)

CORPUS = build_corpus()
FIDS = sorted(CORPUS)

# ----- invariants 1,3,4 : per-transform functorial laws -----
@pytest.mark.parametrize("fid", FIDS)
def test_inv1_3_4_per_transform_laws(fid):
    fam = CORPUS[fid]
    for T in fam.transforms:
        r = check_functorial_laws(fam.canonical_gold, T, fam.eqf)
        assert r["identity"],       f"{fid} {T.tid}: tau_id != id"
        assert r["inverse"],        f"{fid} {T.tid}: inverse law"
        assert r["gold_transport"], f"{fid} {T.tid}: tau_T(a_x) != a_Tx"

# ----- invariant 2 : genuine composition law over the (T1,T2) pair (FB-2) -----
@pytest.mark.parametrize("fid", FIDS)
def test_inv2_composition_law(fid):
    fam = CORPUS[fid]
    T1, T2 = fam.transforms[0], fam.transforms[1]
    assert check_composition_law(fam.canonical_gold, T1, T2, fam.composite_gold, fam.eqf), \
        f"{fid}: tau_(T2 o T1) != tau_T2 o tau_T1 against frozen composite gold"

def test_inv2_composition_law_nontrivial():
    """A composition test with NON-identity transport, to prove the machinery
    genuinely checks tau_{U o T} = tau_U o tau_T (not a self-inverse round-trip).
    A vector coordinate v transforms by a basis change: tau_P(v)=P^-1 v.
    With P then Q the composite must be (Q P)^-1 v -- a frozen anchor."""
    a = {"v0": 1, "v1": 0}
    # T: basis change by P = [[1,1],[0,1]]  -> tau_P(v) = P^-1 v,  P^-1 = [[1,-1],[0,1]]
    tauP    = lambda x: {"v0": x["v0"] - x["v1"], "v1": x["v1"]}
    tauP_in = lambda x: {"v0": x["v0"] + x["v1"], "v1": x["v1"]}
    # U: basis change by Q = [[1,0],[2,1]]  -> tau_Q(v) = Q^-1 v,  Q^-1 = [[1,0],[-2,1]]
    tauQ    = lambda x: {"v0": x["v0"], "v1": -2 * x["v0"] + x["v1"]}
    tauQ_in = lambda x: {"v0": x["v0"], "v1": 2 * x["v0"] + x["v1"]}
    T = Transform("T", "P", tauP, tauP_in, tauP(a))
    U = Transform("U", "Q", tauQ, tauQ_in, tauQ(a))
    # tau_Q o tau_P = Q^-1 P^-1 = (P Q)^-1.  P Q = [[3,1],[2,1]], (P Q)^-1 = [[1,-1],[-2,3]];
    # (P Q)^-1 a = {v0: 1, v1: -2}  (frozen composite gold, computed independently).
    composite_gold = {"v0": 1, "v1": -2}
    eqf = lambda x, y: eq_tuple(x, y, ["v0", "v1"])
    # the chain tau_U(tau_T(a)) must equal the frozen composite gold
    assert eqf(U.tau(T.tau(a)), composite_gold)
    assert check_composition_law(a, T, U, composite_gold, eqf)
    # and a WRONG composite gold must be rejected (the test has teeth)
    assert not check_composition_law(a, T, U, {"v0": 0, "v1": 0}, eqf)

# ----- invariant 5 : parser soundness on the gold form -----
@pytest.mark.parametrize("fid", FIDS)
def test_inv5_parser_soundness(fid):
    fam = CORPUS[fid]
    parsed = fam.normalizer(render_gold(fam.canonical_gold, fam.coords))
    assert parsed is not PARSE_FAIL and fam.eqf(parsed[0], fam.canonical_gold)

# ----- invariant 6 : parser non-coercion on prose -----
@pytest.mark.parametrize("fid", FIDS)
def test_inv6_parser_non_coercion(fid):
    assert CORPUS[fid].normalizer("there is no typed answer in this prose") is PARSE_FAIL

# ----- FB-4 : the parser handles realistic model output AND blocks coercion -----
def test_parser_realistic_and_coercion():
    qd = CORPUS["IMR-QD-002"]
    assert qd.normalizer("The Wilson loop is W = 1 because tr is a class function.")[0] == {"wilson_loop": 1}
    assert qd.normalizer(r"Hence \boxed{1}.")[0] == {"wilson_loop": 1}
    assert qd.normalizer("W = 1/2") is PARSE_FAIL              # int coord, non-integer -> coercion guard
    lg = CORPUS["IMR-LG-002"]
    assert lg.normalizer("Therefore c_1 = 1 (an integer).")[0] == {"chern_number": 1}
    assert lg.normalizer("c_1 = 1/2") is PARSE_FAIL            # non-integer Chern -> type failure
    assert lg.normalizer(r"\boxed{1/2}") is PARSE_FAIL

# ----- invariant 7 : negative-control rejection via anti-certificate replay (M-2) -----
@pytest.mark.parametrize("fid", FIDS)
def test_inv7_negative_control_rejected(fid):
    fam = CORPUS[fid]
    assert not fam.eqf(fam.neg_control_answer, fam.canonical_gold)          # not accepted
    assert fam.anti_certificate(fam.neg_control_answer, fam.canonical_gold) # obstruction replays

def test_inv7_anti_certificate_has_teeth():
    """The anti-certificate must FAIL on a genuine orbit copy (a relabelled gold),
    so invariant 7 is not vacuously true."""
    fam = CORPUS["IMR-QD-002"]
    # an actual orbit copy has the SAME Wilson loop -> anti-certificate must NOT fire
    assert not fam.anti_certificate(dict(fam.canonical_gold), fam.canonical_gold)

# ----- invariant 8 : evaluator invariance gate -----
@pytest.mark.parametrize("fid", FIDS)
def test_inv8_kernel_gold_self_consistency(fid):
    assert CORPUS[fid].kernel_gold_self_consistency() == 0.0

# ----- full audit -----
@pytest.mark.parametrize("fid", FIDS)
def test_full_audit_passes(fid):
    assert CORPUS[fid].audit()["passed"] is True


# ===================== expanded coverage (M-1) =====================
import os, glob, json
from fractions import Fraction
from core import route_failure, dist_tuple, dist_compound
import numpy as np
import analysis as an
from analysis import (Arm, Family, composite_defect, family_differences,
                      point_estimate, variance, percentile_t_lcb,
                      wild_cluster_pvalue, sharp_bounds, threshold_curve,
                      evaluator_gate, yield_gate, decide, DELTA_SEM)

def _route(**kw):
    base = dict(eval_gate_ok=True, harness_ok=True, refused=False, parsed={"x": 1},
                typed_ok=True, canonical_ok=True, transport_ok=True,
                mechanism_ok=True, witness_ok=True, required=[])
    base.update(kw)
    return route_failure(**base)

def test_route_failure_branches():
    assert _route(eval_gate_ok=False) == "evaluator"
    assert _route(harness_ok=False) == "generator"
    assert _route(refused=True) == "refusal"
    assert _route(parsed=PARSE_FAIL) == "parse"
    assert _route(typed_ok=False) == "type"
    assert _route(canonical_ok=False) == "canonical"
    assert _route(transport_ok=False) == "transport"
    assert _route(mechanism_ok=False, required=["mechanism"]) == "mechanism"
    assert _route(witness_ok=False, required=["witness"]) == "witness"
    assert _route() == "correct"
    # type precedes canonical (M-1): a wrong-typed AND wrong-canonical output routes to type
    assert _route(typed_ok=False, canonical_ok=False) == "type"

def test_metrics_bounds_and_values():
    coords = ["a", "b"]
    assert dist_tuple({"a": 1, "b": 2}, {"a": 1, "b": 2}, coords) == 0.0
    assert dist_tuple({"a": 1, "b": 2}, {"a": 9, "b": 9}, coords) == 1.0
    assert dist_tuple({"a": 1, "b": 2}, {"a": 1, "b": 9}, coords) == 0.5
    w = {"a": 0.25, "b": 0.75}
    assert dist_compound({"a": 1, "b": 2}, {"a": 1, "b": 2}, w) == 0.0
    assert abs(dist_compound({"a": 1, "b": 2}, {"a": 9, "b": 2}, w) - 0.25) < 1e-12
    assert abs(dist_compound({"a": 1, "b": 2}, {"a": 1, "b": 9}, w) - 0.75) < 1e-12

def test_artifact_completeness_and_resolution():
    repo = os.path.join(_HERE, "families_repo")
    for fid in FIDS:
        d = os.path.join(repo, fid)
        for fn in ("problem.json", "transform.json", "certificate.sympy"):
            assert os.path.exists(artifact_path(fid, fn)), f"missing {fid}/{fn}"
        cert = open(artifact_path(fid, "certificate.sympy")).read()
        tj = json.load(open(artifact_path(fid, "transform.json")))
        refs = {t["certificate"].split("#")[1] for t in tj["transforms"]}
        refs.add(tj["negative_control"]["anti_certificate"].split("#")[1])
        for r in refs:
            assert f"# CERT:{r}" in cert, f"{fid}: unresolved certificate anchor #{r}"
        exec(compile(cert, f"{fid}/certificate.sympy", "exec"), {})   # certificate must execute
    # the materialized directory set equals the registry FID set (m-5)
    dirs = {os.path.basename(p) for p in glob.glob(os.path.join(repo, "IMR-*"))}
    assert dirs == set(FIDS), f"materialized dirs != registry: {dirs ^ set(FIDS)}"

def _fam(fid, module, s1, s2, surf, miss=False):
    arms = (Arm("structural", s1), Arm("structural", s2),
            Arm("surface", None if miss else surf))
    return Family(fid, module, arms)

def test_composite_defect_counts_behaviour_but_not_apparatus_failure():
    assert composite_defect(Arm("structural", 0.0)) == 0.0
    assert composite_defect(Arm("structural", 0.0, responded=False)) == 1.0   # refusal
    assert composite_defect(Arm("structural", 0.0, parsed=False)) == 1.0      # parse fail
    assert composite_defect(Arm("structural", None)) is None                  # unobserved

def test_point_estimate_variance_and_lcb_are_deterministic():
    fams = [_fam(f"F{i}", f"M{i%4}", 1.0 if i % 3 else 0.0,
                 1.0 if i % 2 else 0.0, 0.0) for i in range(24)]
    d, c = family_differences(fams)
    assert d.size == 24
    theta, var = point_estimate(d, c), variance(d, c)
    assert 0.0 <= theta <= 1.0 and var > 0
    l1, g1 = percentile_t_lcb(d, c, B=400, seed=1)
    l2, g2 = percentile_t_lcb(d, c, B=400, seed=1)
    assert l1 == l2 and g1 == g2 and l1 <= theta

def test_sharp_bounds_bracket_the_complete_case_estimate():
    fams = [_fam(f"F{i}", f"M{i%4}", 1.0, 0.0, 0.0, miss=(i % 5 == 0))
            for i in range(20)]
    lo, hi = sharp_bounds(fams)
    d, c = family_differences(fams)              # complete-case point estimate
    assert lo <= point_estimate(d, c) <= hi

def test_threshold_curve_is_monotone_decreasing_in_delta():
    fams = [_fam(f"F{i}", f"M{i // 4}", float(i % 3 == 0), 1.0,
                 float(i % 4 == 0)) for i in range(16)]
    d, c = family_differences(fams)
    curve = threshold_curve(d, c, B=200, seed=3)
    ks = sorted(curve)
    assert all(curve[ks[i]] > curve[ks[i+1]] for i in range(len(ks)-1))

def test_gates_and_decision_rule():
    mods = list("ABCDEF")
    good = evaluator_gate({m: [0.0] * an.required_cluster_count() for m in mods},
                          declared_modules_list=mods)
    bad = evaluator_gate({m: [0.0] * 4 for m in mods}, declared_modules_list=mods)
    assert good["passes"] and not bad["passes"]
    assert good["sampling_unit"] == "family"

def test_evaluator_gate_requires_every_declared_module():
    """Supplying one module must not pass the gate for six."""
    mods = list("ABCDEF")
    g = evaluator_gate({"A": [0.0] * 200}, declared_modules_list=mods)
    assert not g["passes"] and g["unaudited_modules"] == list("BCDEF")

def test_evaluator_gate_is_simultaneous_over_modules():
    """The gate is a max over modules, so bounds are Bonferroni-corrected."""
    mods = list("ABCDEF")
    g = evaluator_gate({m: [0.0] * 4 for m in mods}, declared_modules_list=mods)
    assert abs(g["alpha_per_module"] - 0.05 / 6) < 1e-12
    assert g["max_upper"] > 1.0 - 0.05 ** 0.25          # worse than the marginal bound
    assert an.required_cluster_count() == 94             # families PER MODULE

def test_evaluator_gate_uses_a_binary_family_indicator():
    assert an.binary_family_failures([0.0, 0.2, 0.0]) == [0.0, 1.0, 0.0]

def test_yield_gate_is_per_arm_class():
    """A pooled-acceptable rate must not pass when one arm class is below floor."""
    assert yield_gate({"structural": (0.97, 0.9), "surface": (0.98, 0.93)})["passes"]
    assert not yield_gate({"structural": (0.85, 0.9), "surface": (0.99, 0.99)})["passes"]
    assert not yield_gate({"structural": (0.97, 0.9)})["passes"]   # class missing
    assert not yield_gate({"structural": (0.97, 0.50),
                           "surface": (0.99, 0.99)})["passes"]     # parse floor
    mods = list("ABCDEF")
    good = evaluator_gate({m: [0.0] * an.required_cluster_count() for m in mods},
                          declared_modules_list=mods)
    bad = evaluator_gate({m: [0.0] * 4 for m in mods}, declared_modules_list=mods)
    ok_yield = yield_gate({"structural": (0.97, 0.91), "surface": (0.98, 0.93)})
    assert decide(lcb=0.20, eval_gate_result=good,
                  yield_gate_result=ok_yield)["reject_H0"]
    assert not decide(lcb=0.20, eval_gate_result=bad,
                      yield_gate_result=ok_yield)["admissible"]
    assert not decide(lcb=0.01, eval_gate_result=good,
                      yield_gate_result=ok_yield)["reject_H0"]

def test_wild_cluster_pvalue_is_a_probability():
    fams = [_fam(f"F{i}", f"M{i // 4}", float(i % 3 == 0), 1.0,
                 float(i % 4 == 0)) for i in range(12)]
    d, c = family_differences(fams)
    p = wild_cluster_pvalue(d, c, B=200, seed=5)
    assert 0.0 <= p <= 1.0

def test_am002_nonidentity_transport_has_teeth():
    am = CORPUS["IMR-AM-002"]
    T1 = am.transforms[0]
    # T1 is genuinely non-identity (it changes the presentation)
    assert T1.tau(am.canonical_gold) != am.canonical_gold
    # the correct transport is convention-equal to the frozen transported gold
    assert am.eqf(T1.tau(am.canonical_gold), T1.transported_gold)
    # a WRONG non-identity transport (coeff x4, breaking epsFF=2FFtilde) is caught
    wrong = {"coeff_num": Fraction(1, 4), "structure": "FFtilde", "origin": "measure_jacobian"}
    assert not am.eqf(wrong, T1.transported_gold)


# ===================== parser regression for AM/BV/TN (m-2, FB-2) =====================
def test_parser_regression_am_bv_tn():
    # TN-002: literal tr(AB)/det(AB) aliases AND natural-language 'is' forms
    tn = CORPUS["IMR-TN-002"]
    assert tn.normalizer("tr(AB) = 7; det(AB) = -42 because trace cyclic")[0] == {"tr_AB": 7, "det_AB": -42}
    assert tn.normalizer("trace of AB is 7 and determinant of AB is -42 because determinant multiplicative")[0] \
        == {"tr_AB": 7, "det_AB": -42}
    # TN-001: similarity invariants with aliases + 'is'
    t1 = CORPUS["IMR-TN-001"]
    assert t1.normalizer("trace = 5; det = 6; char_poly = lam^2-5lam+6; spec = {2,3}")[0] \
        == {"trace": 5, "det": 6, "char_poly": "lam^2-5lam+6", "spec": "{2,3}"}
    # AM-002: explanatory prose after a label must NOT be swallowed
    am = CORPUS["IMR-AM-002"]
    r = am.normalizer("coefficient = 1/16; structure = epsFF; origin = measure_jacobian because Fujikawa")
    assert r is not PARSE_FAIL and r[0]["origin"] == "measure_jacobian"
    assert am.eqf(r[0], am.canonical_gold)            # parses to the canonical convention answer
    # BV-001: set-valued label with commas survives, prose stripped
    bv = CORPUS["IMR-BV-001"]
    rb = bv.normalizer("bulk = -lap(phi); boundary_term = dn(phi)*h; "
                       "boundary_cases = {periodic,interior_support,closed,homogeneous_Neumann,Dirichlet}")
    assert rb is not PARSE_FAIL and bv.eqf(rb[0], bv.canonical_gold)

def test_certificates_are_real_no_assert_true():
    repo = os.path.join(_HERE, "families_repo")
    for fid in FIDS:
        cert = open(artifact_path(fid, "certificate.sympy")).read()
        assert "assert True" not in cert, f"{fid}: certificate.sympy still contains 'assert True'"

def test_am002_transform_json_exports_real_transported_gold():
    repo = os.path.join(_HERE, "families_repo")
    tr = json.load(open(artifact_path("IMR-AM-002", "transform.json")))
    t1 = next(t for t in tr["transforms"] if t["id"] == "T1")
    assert t1["transported_gold"]["structure"] == "FFtilde"
    assert t1["transported_gold"]["coeff_num"] == "1/8"          # FB-1: not the canonical 1/16
    assert tr["composite"]["transport"] == "non-identity"

def test_degenerate_variance_is_reported_not_hidden():
    """All-identical family differences give zero variance; the estimator must
    return nan with full degeneracy rather than a spurious bound."""
    fams = [_fam(f"F{i}", f"M{i%4}", 1.0, 1.0, 0.0) for i in range(12)]
    d, c = family_differences(fams)
    lcb, degen = percentile_t_lcb(d, c, B=100, seed=2)
    assert np.isnan(lcb) and degen == 1.0


# ---------------------------------------------------------------------------
# Release-integrity tests (added in response to the submission audit).
# ---------------------------------------------------------------------------
def test_manifest_covers_every_released_file():
    """The manifest must pin exactly the intended released file set, minus
    itself. A file that ships unpinned is a file the root of trust does not
    cover."""
    import freeze_manifest as fm
    manifest_path = os.path.join(_HERE, "MANIFEST.sha256")
    assert os.path.exists(manifest_path), "MANIFEST.sha256 missing from the bundle"
    listed = set()
    with open(manifest_path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                listed.add(line.split("  ", 1)[1])
    intended = set(fm.intended_files())
    assert listed == intended, (
        f"manifest/file-set mismatch; unpinned={sorted(intended - listed)[:5]} "
        f"stale={sorted(listed - intended)[:5]}")
    assert fm.SELF not in listed, "the manifest must not pin itself"


def test_manifest_digests_match_disk():
    """Every pinned digest must match the file currently on disk."""
    import hashlib
    manifest_path = os.path.join(_HERE, "MANIFEST.sha256")
    with open(manifest_path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            digest, rel = line.split("  ", 1)
            with open(os.path.join(_HERE, rel), "rb") as f:
                got = hashlib.sha256(f.read()).hexdigest()
            assert got == digest, f"digest mismatch for {rel}"


def test_analysis_module_implements_the_papers_protocol():
    """The shipped analysis layer must expose the Section 9 primitives, not an
    older design."""
    import analysis as an
    for name in ("composite_defect", "family_difference", "family_differences",
                 "declared_modules", "check_strata", "fixed_weights",
                 "point_estimate", "variance", "percentile_t_lcb",
                 "wild_cluster_pvalue", "sharp_bounds", "threshold_curve",
                 "max_t_global", "differential_evaluator_sensitivity",
                 "census_defect", "family_cluster_upper", "evaluator_gate",
                 "required_cluster_count", "yield_gate", "simulate_families",
                 "marginal_excess", "solve_beta", "run_grid",
                 "_run_legacy_scalar_analysis", "decide", "derive_seed",
                 "majority_defect", "Admission", "common_support",
                 "binary_family_failures", "required_cluster_count"):
        assert hasattr(an, name), f"analysis.py is missing {name}"
    assert an.DELTA_SEM == 0.05 and an.EVAL_GATE == 0.05
    assert an.RESPONSE_FLOOR == 0.90 and an.PARSE_FLOOR == 0.80
    assert an.BOOT_B == 20000 and an.BOOT_SEED == 20240517
    # the disclosed pilot shortfall, on the correct sampling unit and level
    assert an.required_cluster_count() == 94              # families PER module
    assert an.family_cluster_upper([0.0] * 4, alpha=0.05 / 6) > an.EVAL_GATE
    assert an.family_cluster_upper([0.0] * 94, alpha=0.05 / 6) < an.EVAL_GATE
    assert (an.B_PRIM, an.B_WILD, an.B_CURVE, an.B_SENS) == (20000, 4000, 4000, 2000)
    assert an.R_REPLICATES == 4


def test_failure_router_contract_matches_the_paper():
    """Paper and code must agree on the response-level precedence, including
    that answer-typing is checked before canonical correctness."""
    from core import STAGE0, STAGE1
    assert STAGE0 == ["evaluator", "generator"]
    assert STAGE1 == ["refusal", "parse", "type", "canonical",
                      "transport", "mechanism", "witness"]


# ---------------------------------------------------------------------------
# Adversarial tests for the analysis pipeline (round-3 audit, Patch D3).
# ---------------------------------------------------------------------------
def _sim(n=24, modules=6, beta=0.8, **kw):
    rng = np.random.default_rng(kw.pop("seed", 5))
    return an.simulate_families(n, modules, beta=beta, mu=[-1.2] * modules,
                                sigma=[0.6] * modules, rng=rng, **kw)


def test_wholly_missing_module_makes_the_run_inadmissible():
    """A module that yields no observation must NOT be silently dropped and the
    remaining modules recoded; the run is inadmissible."""
    fams = _sim()
    # blank out every family of one declared module
    dead = an.declared_modules(fams)[2]
    fams = [an.Family(f.fid, f.module,
                      tuple(an.Arm(a.kind, None) for a in f.arms))
            if f.module == dead else f for f in fams]
    mods = an.declared_modules(fams)
    d, c = an.family_differences(fams, modules=mods)
    st = an.check_strata(c, len(mods))
    assert st["empty_strata"] == [2] and not st["admissible"]
    r = an._run_legacy_scalar_analysis(
        fams, admission=an.Admission(permissive=True), require_manifest=False,
        family_defects_by_module={m: [0.0] * 94 for m in mods},
        B_prim=200, B_wild=150, B_curve=150, B_sens=100)
    assert not r["admissible"] and "empty declared strata" in r["verdict"]
    assert r["estimation_performed"] is False


def test_fallback_is_wired_into_the_actual_decision():
    """When the fallback rule fires, the reported decision must come from the
    fallback, not from the percentile-t bound."""
    fams = _sim(n=24, modules=6)          # 4 clusters per stratum < 8
    mods = an.declared_modules(fams)
    r = an._run_legacy_scalar_analysis(
        fams, admission=an.Admission(permissive=True), require_manifest=False,
        family_defects_by_module={m: [0.0] * 94 for m in mods},
        B_prim=400, B_wild=300, B_curve=300, B_sens=200)
    assert r["used_fallback"] is True
    assert "wild-cluster" in r["decision_basis"]
    assert np.isfinite(r["wild_p_value"])
    # the sensitivity analyses must use the SAME engine that decided
    assert r["differential_evaluator"]["engine"] == "wild-cluster"
    assert r["threshold_curve_kind"].startswith("wild-cluster")


def test_infinite_studentized_replicates_are_retained_in_the_quantile():
    """Degenerate resamples must not be silently dropped: dropping them
    narrows the interval."""
    fams = [an.Family(f"F{i}", f"M{i % 4}",
                      (an.Arm("structural", 1.0), an.Arm("structural", 1.0),
                       an.Arm("surface", 0.0))) for i in range(12)]
    d, c = an.family_differences(fams)
    lcb, degen = an.percentile_t_lcb(d, c, B=200, seed=2)
    assert degen == 1.0 and not np.isfinite(lcb)


def test_wild_bootstrap_preserves_heterogeneous_module_means():
    """The null is imposed on the global weighted mean only; module means must
    survive the constrained fit, or a heterogeneous bank is flattened."""
    fams = []
    for i in range(24):
        m = i // 4
        lvl = 1.0 if m < 3 else 0.0          # strongly heterogeneous modules
        fams.append(an.Family(f"F{i}", f"M{m}",
                              (an.Arm("structural", lvl),
                               an.Arm("structural", float(i % 2)),
                               an.Arm("surface", 0.0))))
    mods = an.declared_modules(fams)
    w = an.fixed_weights(fams, mods)
    d, c = an.family_differences(fams, modules=mods)
    p = an.wild_cluster_pvalue(d, c, B=300, seed=4, weights=w)
    assert 0.0 <= p <= 1.0
    means = [d[c == k].mean() for k in range(len(mods))]
    assert max(means) - min(means) > 0.3      # the heterogeneity is real


def test_directional_missingness_bounds_are_ordered_and_directional():
    """A single constant applied to every missing arm does not bound D_F,
    because d_surf enters with a minus sign."""
    fams = []
    for i in range(20):
        miss_surf = (i % 4 == 0)
        fams.append(an.Family(f"F{i}", f"M{i % 4}",
                              (an.Arm("structural", 1.0),
                               an.Arm("structural", float(i % 2)),
                               an.Arm("surface", None if miss_surf else 0.0))))
    mods = an.declared_modules(fams)
    w = an.fixed_weights(fams, mods)
    lo, hi = an.sharp_bounds(fams, modules=mods, weights=w)
    assert lo <= hi
    # the non-directional rule (same constant on every missing arm) is NOT a bound
    naive_lo, c = an.family_differences(fams, impute_str=0.0, impute_surf=0.0,
                                        modules=mods)
    assert an.point_estimate(naive_lo, c, w) > lo


def test_bounds_collapse_to_the_estimate_without_missingness():
    fams = [an.Family(f"F{i}", f"M{i % 4}",
                      (an.Arm("structural", float(i % 3 == 0)),
                       an.Arm("structural", 1.0),
                       an.Arm("surface", float(i % 4 == 0)))) for i in range(16)]
    mods = an.declared_modules(fams)
    w = an.fixed_weights(fams, mods)
    lo, hi = an.sharp_bounds(fams, modules=mods, weights=w)
    d, c = an.family_differences(fams, modules=mods)
    pt = an.point_estimate(d, c, w)
    assert abs(lo - pt) < 1e-12 and abs(hi - pt) < 1e-12


def test_target_population_mismatch_is_reported_not_hidden():
    """The complete-case statistic and the bounds target different family sets,
    so the statistic can fall outside the interval. That must be surfaced as a
    target-population mismatch, not diagnosed as informative missingness."""
    fams = []
    for i in range(20):
        surf = None if i % 4 == 0 else 0.0
        fams.append(an.Family(f"F{i}", f"M{i % 4}",
                              (an.Arm("structural", 1.0),
                               an.Arm("structural", float(i % 2)),
                               an.Arm("surface", surf))))
    mods = an.declared_modules(fams)
    w = an.fixed_weights(fams, mods)
    diag = an.target_population_mismatch(fams, mods, w)
    assert diag["n_dropped"] == 5
    assert diag["estimate_outside_bounds"] is True
    assert "target-population mismatch" in diag["note"]
    assert not diag["note"].startswith("informative")


def test_joint_max_t_controls_familywise_error():
    """The critical value must come from the JOINT null distribution, and the
    per-model rejections must be taken at that critical value."""
    fams = _sim(n=24, modules=6, beta=0.0, seed=9)
    mods = an.declared_modules(fams)
    w = an.fixed_weights(fams, mods)
    d, c = an.family_differences(fams, modules=mods)
    per_model = {"A": d, "B": np.roll(d, 5), "C": d * 0.7}
    mt = an.max_t_global(per_model, c, weights=w, B=400, seed=3)
    assert np.isfinite(mt["critical_value"])
    assert 0.0 <= mt["p_value"] <= 1.0
    assert set(mt["reject_per_model"]) == {"A", "B", "C"}
    # any per-model rejection implies the global rejection
    assert (not any(mt["reject_per_model"].values())) or mt["reject_global"]


def test_solve_beta_hits_the_target_marginal_excess():
    mu, sg = [-1.2] * 6, [0.6] * 6
    for target in (0.05, 0.10, 0.15):
        b = an.solve_beta(target, mu, sg)
        assert abs(an.marginal_excess(b, mu, sg) - target) < 0.01


# ---------------------------------------------------------------------------
# Round-4 tests: admission enforcement, replicate protocol, seeds, support.
# ---------------------------------------------------------------------------
def test_admission_manifest_is_enforced_before_weights():
    """Module-D style exclusion must be enforced in code, not just documented."""
    fams = _sim(n=24, modules=6)
    mods = an.declared_modules(fams)
    recs = {f.fid: {"module": f.module, "certificate_rung": "V2",
                    "ni_control": True, "surface_complexity_matched": True,
                    "non_identity_transport": False,
                    "arms": {"structural": 2, "surface": 1},
                    "replicates_per_arm": an.R_REPLICATES,
                    "confirmatory_eligible": f.module != mods[3]}
            for f in fams}
    adm = an.Admission(records=recs, module_universe=tuple(m for m in mods
                                                          if m != mods[3]))
    kept = adm.admit(fams)
    assert len(kept) == 20 and all(f.module != mods[3] for f in kept)
    # weights are built from the ADMITTED families and the frozen universe
    w = an.fixed_weights(kept, list(adm.module_universe))
    assert len(w) == 5 and abs(float(w.sum()) - 1.0) < 1e-12
    r = an._run_legacy_scalar_analysis(
        fams, admission=adm, require_manifest=False,
        audit_records=[an.EvaluatorAuditRecord(f.fid, a, f.module, False,
                                              "cert", "judge")
                       for f in kept for a in an.REQUIRED_ARROWS],
        B_prim=200, B_wild=150, B_curve=150, B_sens=100)
    assert r["n_families_admitted"] == 20
    assert len(r["modules"]) == 5
    # four audited families per module cannot pass the simultaneous gate,
    # so the run is inadmissible for THAT reason and never estimates
    assert not r["admissible"] and r["estimation_performed"] is False
    assert "evaluator gate" in r["verdict"]


def test_seed_derivation_is_sha256_and_stable():
    a = an.derive_seed(20240517, "m", "IMR-QD-001", "T1", 0)
    b = an.derive_seed(20240517, "m", "IMR-QD-001", "T1", 0)
    c = an.derive_seed(20240517, "m", "IMR-QD-001", "T1", 1)
    assert a == b and a != c and 0 <= a < 2 ** 64


def test_conservative_majority_reduction():
    assert an.majority_defect([1, 1, 0, 0]) == 1.0      # tie -> defect
    assert an.majority_defect([1, 0, 0, 0]) == 0.0
    assert an.majority_defect([1, 1, 1, 0]) == 1.0


def test_simulation_uses_four_replicates_and_the_reduced_scale():
    """solve_beta must invert the MAJORITY-REDUCED excess, not the replicate one."""
    mu, sg = [-1.2] * 6, [0.6] * 6
    b = an.solve_beta(0.15, mu, sg)
    assert abs(an.marginal_excess(b, mu, sg) - 0.15) < 0.01
    # the reduced scale differs from the replicate scale, so beta must differ
    p = 0.3
    assert abs(an._majority_prob(p, 4) - p) > 0.01


def test_common_support_aligns_models_on_one_panel():
    fams = _sim(n=24, modules=6)
    vecs, codes, ids = an.common_support({"A": fams, "B": fams[:20], "C": fams})
    assert len(ids) == 20
    assert all(v.size == codes.size for v in vecs.values())


def test_prompts_are_shipped_verbatim():
    d = os.path.join(_HERE, "prompts")
    for fn in ("system_prompt.txt", "format_repair_prompt.txt", "README.txt"):
        assert os.path.exists(os.path.join(d, fn)), f"missing prompts/{fn}"
    rp = open(os.path.join(d, "format_repair_prompt.txt"), encoding="utf-8").read()
    assert "{ANSWER_TYPE}" in rp


def test_wild_pvalue_excludes_degenerate_from_both_numerator_and_denominator():
    fams = [an.Family(f"F{i}", f"M{i % 4}",
                      (an.Arm("structural", float(i % 3 == 0)),
                       an.Arm("structural", 1.0),
                       an.Arm("surface", float(i % 4 == 0)))) for i in range(16)]
    mods = an.declared_modules(fams)
    w = an.fixed_weights(fams, mods)
    d, c = an.family_differences(fams, modules=mods)
    p = an.wild_cluster_pvalue(d, c, B=300, seed=6, weights=w)
    assert 0.0 < p <= 1.0


def test_grid_cells_are_decided_by_the_primary_analysis():
    rows = an.run_grid(targets=(0.0,), n_families=(24,), reps=4, calib_reps=6,
                       B_prim=120, B_wild=100, B_curve=100, B_sens=60)
    r = rows[0]
    assert "fallback_rate" in r and "calibrated_lower_endpoint" in r
    assert 0.0 <= r["rejection_rate"] <= 1.0


# ---------------------------------------------------------------------------
# Round-5 tests: proof-summary layer, admission manifest, exact intervals,
# derived yield, gate ordering, replicate-level simulation.
# ---------------------------------------------------------------------------
import proof_summary as ps


def _ov(partial):
    """Build a complete nine-coordinate record; unspecified coordinates are NA."""
    out = {c: ps.NA for c in ps.COORDINATES}
    out.update(partial)
    return out


def test_lambda_is_a_bijection_and_refuses_retirement():
    """Retirement and introduction are impossible under strictly invertible
    arrows, so the constructor must refuse them."""
    inv = ("logic", "global", "transport")
    lam = ps.LambdaT({"logic": "logic", "global": "quotient",
                      "transport": "transport"}, inv, ("logic", "quotient", "transport"))
    assert lam("global") == "quotient"
    with pytest.raises(ValueError):                      # not surjective: retirement
        ps.LambdaT({"logic": "logic", "global": "logic", "transport": "transport"},
                   inv, ("logic", "quotient", "transport"))
    with pytest.raises(ValueError):                      # not total on the source
        ps.LambdaT({"logic": "logic"}, inv, ("logic",))


def test_lambda_satisfies_the_three_functor_laws():
    a = ("logic", "global")
    b = ("quotient", "logic")
    c = ("boundary", "analytic")
    lam_T = ps.LambdaT({"logic": "quotient", "global": "logic"}, a, b)
    lam_U = ps.LambdaT({"quotient": "boundary", "logic": "analytic"}, b, c)
    laws = ps.check_lambda_laws(lam_T, lam_identity=ps.LambdaT.identity(a),
                                lam_inverse=lam_T.inverse(), lam_U=lam_U,
                                lam_composite=lam_U.compose(lam_T))
    assert all(v is True for v in laws.values()), laws
    assert lam_U.compose(lam_T)("logic") == "boundary"
    assert lam_T.inverse().compose(lam_T) == ps.LambdaT.identity(a)


def test_delta_P_unavailable_when_no_coordinate_is_comparable():
    inv = ("logic",)
    src = ps.ObligationVector(_ov({"logic": ps.UNKNOWN, "domain": 1}), inv)
    tgt = ps.ObligationVector(_ov({"logic": 1, "domain": 1}), inv)
    lam = ps.LambdaT.identity(inv)
    out = ps.delta_P("a", "a", src, tgt, lam)
    assert out["delta_P"] == ps.UNAVAILABLE and out["n_comparable"] == 0
    assert out["adjudication"] == ["logic"]


def test_delta_P_routes_unknown_to_adjudication_and_compares_the_rest():
    inv = ("logic", "global")
    src = ps.ObligationVector(_ov({"logic": 1, "global": ps.UNKNOWN}), inv)
    tgt = ps.ObligationVector(_ov({"logic": 0, "global": 1}), inv)
    lam = ps.LambdaT.identity(inv)
    out = ps.delta_P("a", "a", src, tgt, lam)
    assert out["delta_P"] == 1.0 and out["mismatched"] == ["logic"]
    assert out["adjudication"] == ["global"]


def test_presentation_specific_obligations_are_not_transported():
    inv = ("logic",)
    src = ps.ObligationVector(_ov({"logic": 1, "boundary": 1}), inv)
    assert src.presentation_specific == ("boundary",)
    assert "explanation" not in src.mask


def test_admission_manifest_ships_and_is_required():
    path = os.path.join(_HERE, "admission.json")
    assert os.path.exists(path), "admission.json must ship with the bundle"
    adm = an.load_admission(path)
    assert adm.version and len(adm.records) == 24
    assert "D" in adm.excluded_modules
    with pytest.raises(FileNotFoundError):
        an.load_admission(os.path.join(_HERE, "no_such_manifest.json"))


def test_evaluator_interval_is_exact_at_nonzero_counts():
    """The round-5 countercheck: a percentile bootstrap would pass this gate."""
    one_failure = [1.0] + [0.0] * 93
    exact = an.family_cluster_upper(one_failure, alpha=0.05 / 6)
    assert abs(exact - 0.0706) < 0.002
    assert exact > an.EVAL_GATE                     # must FAIL the gate
    assert abs(an.clopper_pearson_upper(1, 94, 0.05 / 6) - exact) < 1e-9


def test_yield_is_derived_from_records_not_supplied():
    """A caller must not be able to assert perfect yield over bad records."""
    bad = an.Arm("structural", replicates=(an.Replicate(responded=False),
                                           an.Replicate(parsed=False),
                                           an.Replicate(defect=0.0),
                                           an.Replicate(defect=0.0)))
    good = an.Arm("surface", replicates=tuple(an.Replicate(defect=0.0)
                                              for _ in range(4)))
    fams = [an.Family(f"F{i}", "M0", (bad, bad, good)) for i in range(4)]
    y = an.observed_yield(fams)
    assert y["structural"][0] < an.RESPONSE_FLOOR
    r = an._run_legacy_scalar_analysis(
        fams, admission=an.Admission(permissive=True), require_manifest=False,
        family_defects_by_module={"M0": [0.0] * 94},
        B_prim=100, B_wild=80, B_curve=80, B_sens=50)
    assert not r["admissible"] and "yield" in r["verdict"]


def test_no_endpoint_is_computed_when_a_gate_fails():
    fams = _sim(n=24, modules=6)
    mods = an.declared_modules(fams)
    r = an._run_legacy_scalar_analysis(
        fams, admission=an.Admission(permissive=True), require_manifest=False,
        family_defects_by_module={m: [0.0] * 4 for m in mods},   # gate fails
        B_prim=100, B_wild=80, B_curve=80, B_sens=50)
    assert r["estimation_performed"] is False
    for k in ("partial_identification", "lcb_lower_endpoint", "threshold_curve"):
        assert k not in r


def test_simulation_produces_four_independent_response_records():
    rng = np.random.default_rng(11)
    fams = an.simulate_families(12, 3, beta=0.5, mu=[-1.2] * 3, sigma=[0.6] * 3,
                                rng=rng, p_apparatus=0.15, p_refusal=0.1,
                                p_parsefail=0.1, p_judge=0.02)
    for f in fams:
        for a in f.arms:
            assert len(a.records()) == an.R_REPLICATES
    kinds = {r.apparatus_ok for f in fams for a in f.arms for r in a.records()}
    assert True in kinds               # apparatus events occur PER REPLICATE


def test_partially_unobserved_arm_aggregates_over_observed_replicates():
    arm = an.Arm("structural", replicates=(an.Replicate(apparatus_ok=False),
                                           an.Replicate(defect=1.0),
                                           an.Replicate(defect=1.0),
                                           an.Replicate(defect=0.0)))
    assert an.composite_defect(arm) == 1.0
    allbad = an.Arm("structural", replicates=tuple(
        an.Replicate(apparatus_ok=False) for _ in range(4)))
    assert an.composite_defect(allbad) is None


def test_full_grid_driver_exists_and_smoke_grid_is_fast():
    assert hasattr(an, "run_full_grid") and hasattr(an, "benchmark_analysis")
    rows = an.run_grid(targets=(0.0,), n_families=(24,), reps=3, calib_reps=6,
                       B_prim=120, B_wild=100, B_curve=100, B_sens=60)
    r = rows[0]
    assert "scope" in r and "paired records" in r["scope"]
    # distinct bootstrap counts are recorded per cell (round-6 B09)
    assert (r["B_prim"], r["B_wild"], r["B_curve"], r["B_sens"]) == (120, 100, 100, 60)
    # both conditionings are reported (round-6 M14)
    assert "rejection_rate" in r and "fallback_rate" in r
    # the calibrated endpoint is stored, so a cell cannot be mislabelled (B08)
    assert "calibrated_lower_endpoint" in r


# ---------------------------------------------------------------------------
# Round-6 tests: fail-closed identity, audit provenance, calibration identity.
# ---------------------------------------------------------------------------
def test_unknown_family_id_is_rejected_not_admitted():
    """Round-6 B01: admission is a POSITIVE test against the frozen record."""
    adm = an.load_admission()
    unk = an.Family("UNKNOWN-001", "A",
                    (an.Arm("structural", replicates=(an.Replicate(),)),))
    with pytest.raises(an.ProtocolError):
        adm.admit([unk])


def test_module_mismatch_and_duplicate_ids_are_rejected():
    adm = an.load_admission()
    fid = adm.records and sorted(adm.records)[0]
    wrong = an.Family(fid, "ZZ", (an.Arm("structural", replicates=(an.Replicate(),)),))
    with pytest.raises(an.ProtocolError):
        adm.admit([wrong])
    dup = an.Family(fid, adm.records[fid]["module"],
                    (an.Arm("structural", replicates=(an.Replicate(),)),))
    with pytest.raises(an.ProtocolError):
        adm.admit([dup, dup])


def test_module_universe_is_frozen_in_the_manifest():
    """Round-6 B02: the Bonferroni denominator comes from the manifest."""
    adm = an.load_admission()
    assert len(adm.module_universe) == 6
    assert set(adm.module_universe) == set("ABCDEF")


def test_confirmatory_design_validator_rejects_malformed_families():
    """Round-6 B03: wrong arm composition, replicate count, or defect domain."""
    ok_arm = lambda k: an.Arm(k, replicates=tuple(an.Replicate(defect=0.0)
                                                  for _ in range(an.R_REPLICATES)))
    good = [an.Family("F", "A", (ok_arm("structural"), ok_arm("structural"),
                                 ok_arm("surface")))]
    an.validate_confirmatory_design(good)                      # passes
    with pytest.raises(an.ProtocolError):                      # scalar arm
        an.validate_confirmatory_design(
            [an.Family("F", "A", (an.Arm("structural", 0.0), an.Arm("surface", 0.0)))])
    with pytest.raises(an.ProtocolError):                      # wrong composition
        an.validate_confirmatory_design(
            [an.Family("F", "A", (ok_arm("structural"), ok_arm("surface")))])
    with pytest.raises(an.ProtocolError):                      # wrong replicate count
        an.validate_confirmatory_design(
            [an.Family("F", "A", (an.Arm("structural",
                                         replicates=(an.Replicate(),)),
                                  ok_arm("structural"), ok_arm("surface")))])
    with pytest.raises(an.ProtocolError):                      # non-binary defect
        an.validate_confirmatory_design(
            [an.Family("F", "A", (an.Arm("structural", replicates=tuple(
                an.Replicate(defect=0.5) for _ in range(an.R_REPLICATES))),
                ok_arm("structural"), ok_arm("surface")))])


def test_invalid_evaluator_values_are_rejected_not_coerced():
    """Round-6 B07: NaN and out-of-domain values must not become successes."""
    for bad in ([float("nan")] * 94, [-1.0] * 94, [2.0] * 94, ["x"] * 94):
        with pytest.raises(an.ProtocolError):
            an.family_cluster_upper(bad, alpha=0.05 / 6)
    assert an.binary_family_failures([True, False, 0.0, 1.0]) == [1.0, 0.0, 0.0, 1.0]


def test_audit_records_require_provenance_and_coverage():
    """Round-6 B06: keyed records, unique, manifest-checked, module-covering."""
    adm = an.Admission(permissive=True)
    mods = ["A", "B"]
    recs = [an.EvaluatorAuditRecord("F1", "T1", "A", False, "cert", "judge"),
            an.EvaluatorAuditRecord("F2", "T1", "B", False, "cert", "judge")]
    out = an.validate_audit_records(recs, adm, mods, strict=False)
    assert set(out) == {"A", "B"}
    with pytest.raises(an.ProtocolError):                      # duplicate key
        an.validate_audit_records(recs + [recs[0]], adm, mods, strict=False)
    with pytest.raises(an.ProtocolError):                      # module uncovered
        an.validate_audit_records(recs[:1], adm, mods, strict=False)
    with pytest.raises(an.ProtocolError):                      # non-Boolean outcome
        an.validate_audit_records(
            [an.EvaluatorAuditRecord("F1", "T1", "A", 0.5, "cert", "judge")], adm,
            ["A"], strict=False)


def test_confirmatory_path_refuses_anonymous_audit_vectors():
    adm = an.load_admission()
    ok_arm = lambda k: an.Arm(k, replicates=tuple(an.Replicate(defect=0.0)
                                                  for _ in range(an.R_REPLICATES)))
    fid = sorted(adm.records)[0]
    fams = [an.Family(fid, adm.records[fid]["module"],
                      (ok_arm("structural"), ok_arm("structural"), ok_arm("surface")))]
    r = an._run_legacy_scalar_analysis(fams, admission=adm,
                                family_defects_by_module={"A": [0.0] * 94})
    assert not r["admissible"] and r["estimation_performed"] is False


def test_delta_P_claim_mismatch_is_decisive():
    """Round-6 B04: a definite claim failure must not return 'unavailable'."""
    inv = ("logic",)
    src = ps.ObligationVector(_ov({"logic": ps.UNKNOWN}), inv)
    tgt = ps.ObligationVector(_ov({"logic": 1}), inv)
    out = ps.delta_P("DIFFERENT", "a", src, tgt, ps.LambdaT.identity(inv))
    assert out["delta_claim"] == 1.0
    assert out["delta_obligation"] == ps.UNAVAILABLE
    assert out["delta_P"] == 1.0
    # and when the claim matches, the obligation component may be unavailable
    out2 = ps.delta_P("a", "a", src, tgt, ps.LambdaT.identity(inv))
    assert out2["delta_P"] == ps.UNAVAILABLE


def test_obligation_vector_validates_its_domain():
    with pytest.raises(ValueError):
        ps.ObligationVector(_ov({"logic": 7}), ("logic",))
    with pytest.raises(ValueError):
        ps.ObligationVector(_ov({"logic": 1}), ("logic", "logic"))


def test_lambda_laws_use_independently_declared_maps():
    a = ("logic", "global")
    b = ("quotient", "logic")
    lam = ps.LambdaT({"logic": "quotient", "global": "logic"}, a, b)
    wrong_inverse = ps.LambdaT({"quotient": "global", "logic": "logic"}, b, a)
    laws = ps.check_lambda_laws(lam, lam_inverse=wrong_inverse)
    assert laws["inverse_declared"] is False        # extensional comparison bites
    assert laws["identity_declared"] is None        # unchecked, not silently passed


def test_apparatus_retry_policy_is_simulated():
    """Round-6 M12: up to three identical re-administrations."""
    assert an.APPARATUS_RETRIES == 3
    rng = np.random.default_rng(3)
    fams = an.simulate_families(150, 6, beta=0.4, mu=[-1.2] * 6, sigma=[0.6] * 6,
                                rng=rng, p_apparatus=0.3)
    recs = [r for f in fams for a in f.arms for r in a.records()]
    lost = sum(1 for r in recs if not r.apparatus_ok) / len(recs)
    assert lost < 0.05                    # ~p^4 = 0.0081, not p = 0.3


def test_seed_serialization_is_injective():
    """Round-6 M18: delimiter concatenation is not injective."""
    assert an.derive_seed(1, "a|b", "F", "T1", 0) != an.derive_seed(1, "a", "b|F", "T1", 0)


def test_calibration_targets_the_analysed_endpoint():
    """Round-6 B08: beta is solved against the realized lower endpoint."""
    rows = an.run_grid(targets=(0.05,), reps=3, calib_reps=40,
                       B_prim=120, B_wild=100, B_curve=100, B_sens=60)
    r = rows[0]
    assert abs(r["calibrated_lower_endpoint"] - 0.05) < 0.02
    assert r["target_lower_endpoint"] == 0.05


# ---------------------------------------------------------------------------
# Round-7 tests: protocol identity, paired observation, derived estimands.
# ---------------------------------------------------------------------------
import observation as ob
import json as _json, tempfile as _tf, os as _os


def _syn_manifest(n_per_module=8):
    mods = list("ABCDEF")
    fids = [f"SYN-{m}-{i:02d}" for m in mods for i in range(n_per_module)]
    doc = {"schema": "imr-admission/2", "version": "syn-1", "frozen": "2026-07-31",
           "policy": {"module_universe": mods,
                      "arms_per_family": {"structural": 2, "surface": 1},
                      "replicates_per_arm": an.R_REPLICATES,
                      "module_D_transition": "synthetic: all modules eligible"},
           "families": {f: {"module": f.split("-")[1], "certificate_rung": "V2",
                            "ni_control": True, "surface_complexity_matched": True,
                            "non_identity_transport": False,
                            "confirmatory_eligible": True,
                            "arms": {"structural": 2, "surface": 1},
                            "replicates_per_arm": an.R_REPLICATES} for f in fids}}
    p = _os.path.join(_tf.mkdtemp(), "admission.json")
    open(p, "w", encoding="utf-8").write(_json.dumps(doc))
    return p, mods, fids


def _syn_run(n_per_module=8, seed=2):
    p, mods, fids = _syn_manifest(n_per_module)
    rng = np.random.default_rng(seed)
    obs = an.simulate_observed_families(len(fids), 6, beta=0.8, mu=[-1.3] * 6,
                                        sigma=[0.5] * 6, rng=rng,
                                        p_apparatus=0.03, p_refusal=0.01,
                                        p_parsefail=0.02, modules=mods,
                                        family_ids=fids)
    recs = [an.EvaluatorAuditRecord(o.family_id, a, o.module, False,
                                    f"cert-{o.family_id}-{a}", "sim-judge-1",
                                    "sim-parser-1", "sim-renderer-1")
            for o in obs for a in an.REQUIRED_ARROWS]
    return p, obs, recs


def test_confirmatory_api_has_no_protocol_override():
    """Round-7 blocker 1: no declared_modules_list, no caller Admission."""
    import inspect
    sig = inspect.signature(an.run_confirmatory_analysis).parameters
    for forbidden in ("declared_modules_list", "admission", "require_manifest",
                      "manifest_path"):
        assert forbidden not in sig, f"{forbidden} must not be caller-settable"


def test_confirmatory_requires_the_whole_eligible_set():
    p, obs, recs = _syn_run()
    full = an._run_confirmatory_with_manifest(obs, recs, p, registry=an.simulation_registry(obs))
    assert full["mode"] == "test-helper" and full["n_bonferroni"] == 6
    # at eight audited families per module the simultaneous gate cannot pass,
    # so the complete run is inadmissible for that reason and never estimates
    assert not full["admissible_test"] and "evaluator gate" in full["verdict"]
    subset = an._run_confirmatory_with_manifest(obs[:-1], recs, p, registry=an.simulation_registry(obs))
    assert not subset["admissible_test"]
    assert "administered set != eligible set" in subset["verdict"]


def test_confirmatory_requires_full_arrow_coverage():
    p, obs, recs = _syn_run()
    partial = [r for r in recs if r.arrow_id != "s"]
    out = an._run_confirmatory_with_manifest(obs, partial, p, registry=an.simulation_registry(obs))
    assert not out["admissible_test"] and "audit" in out["verdict"]


def test_exploratory_results_are_never_bare_admissible():
    """Round-7 M18."""
    fams = _sim(n=24, modules=6)
    r = an.run_exploratory_analysis(
        fams, admission=an.Admission(permissive=True), require_manifest=False,
        family_defects_by_module={m: [0.0] * 94 for m in an.declared_modules(fams)},
        B_prim=100, B_wild=80, B_curve=80, B_sens=50)
    assert r["mode"] == "exploratory"
    assert "admissible" not in r and "admissible_exploratory" in r
    assert r["verdict"].startswith("EXPLORATORY")


def test_paired_record_derives_every_quantity():
    """Round-7 blockers 2 and 4, round-8 B02/B07: nothing is precomputed."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    a = ob.ArrowResponse("F", "A", "T1", 0, "cert", ok("x", 1), ok("Tx", 2),
                         1, tau, "j", "p", "r")
    assert a.joint_parse() and a.canonical_correct() is True
    assert a.transformed_correct() is False
    assert a.transport_discrepancy() == 1.0 and a.composite_defect() == 1.0
    assert a.failure_label() == "F_transport"
    b = ob.ArrowResponse("F", "A", "T1", 1, "cert", ok("x", 2), ok("Tx", 2),
                         1, tau, "j", "p", "r")
    assert b.canonical_correct() is False and b.transport_discrepancy() == 0.0
    assert b.failure_label() == "F_canonical"
    c = ob.ArrowResponse("F", "A", "T1", 2, "cert",
                         ob.SideResponse("x", ob.Status.APPARATUS),
                         ok("Tx", 1), 1, tau, "j", "p", "r")
    assert c.apparatus_lost() and c.composite_defect() is None
    d = ob.ArrowResponse("F", "A", "T1", 3, "cert", ok("x", 1),
                         ob.SideResponse("Tx", ob.Status.REFUSAL),
                         1, tau, "j", "p", "r")
    assert d.joint_parse() is False and d.composite_defect() == 1.0
    assert d.failure_label() == "F_refusal"


def test_total_non_identity_transport_is_applied_to_every_value():
    """Round-8 B02: the audit's own counterexample table, tau(v) = 2v."""
    # round-9: a doubling map is admissible only when the TARGET TYPE says so
    tau = ob.Transport("double", "1", "int", "even_int", "cert",
                       lambda v: 2 * v, lambda v: v // 2,
                       source_domain=(1, 3, 7), arrow_certificate_digest="cert")
    tau.check_roundtrip()
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    commuting = ob.ArrowResponse("F", "A", "T1", 0, "cert", ok("x", 3),
                                 ok("Tx", 6), 3, tau, "j", "p", "r")
    non_commuting = ob.ArrowResponse("F", "A", "T1", 1, "cert", ok("x", 3),
                                     ok("Tx", 3), 3, tau, "j", "p", "r")
    assert commuting.transport_discrepancy() == 0.0      # was 1 before round 8
    assert non_commuting.transport_discrepancy() == 1.0  # was 0 before round 8
    assert commuting.transported_gold == 6


def test_wrong_answer_type_routes_to_answer_type_not_canonical():
    """Round-8 B07."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    a = ob.ArrowResponse("F", "A", "T1", 0, "cert",
                         ob.SideResponse("x", ob.Status.OK, normalized=1),
                         ob.SideResponse("Tx", ob.Status.ANSWER_TYPE),
                         1, tau, "j", "p", "r")
    assert a.failure_label() == "F_answer-type"


def test_record_construction_validates(): 
    """Round-8 M07/B03: malformed records are refused at construction."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    with pytest.raises(ob.ObservationError):          # blank provenance
        ob.ArrowResponse("F", "A", "T1", 0, "cert", ok("x", 1), ok("Tx", 1),
                         1, tau, "", "p", "r")
    with pytest.raises(ob.ObservationError):          # replicate out of range
        ob.ArrowResponse("F", "A", "T1", 9, "cert", ok("x", 1), ok("Tx", 1),
                         1, tau, "j", "p", "r")
    with pytest.raises(ob.ObservationError):          # certificate mismatch
        ob.ArrowResponse("F", "A", "T1", 0, "other", ok("x", 1), ok("Tx", 1),
                         1, tau, "j", "p", "r")
    with pytest.raises(ob.ObservationError):          # OK without an answer
        ob.SideResponse("x", ob.Status.OK, normalized=ob.PARSE_FAIL)


def test_parse_fail_sentinel_is_not_a_string():
    """Round-8 M08: an equal-looking string must not count as parse failure."""
    assert ob.PARSE_FAIL != "PARSE_FAIL"
    assert ob.PARSE_FAIL == ob.PARSE_FAIL
    s = ob.SideResponse("x", ob.Status.OK, normalized="PARSE_FAIL")
    assert s.parsed() is True          # a legitimate string answer stays parsed


def test_family_rejects_internal_key_mismatch_and_duplicates():
    """Round-8 B03."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    good = [ob.ArrowResponse("F", "A", aid, rep, "cert", ok("x", 1), ok("Tx", 1),
                             1, tau, "j", "p", "r")
            for aid in ob.REQUIRED_ARROWS for rep in range(ob.R_REPLICATES)]
    ob.ObservedFamily("F", "A", tuple(good))                      # valid
    wrong_family = list(good)
    wrong_family[0] = ob.ArrowResponse("OTHER", "A", "T1", 0, "cert", ok("x", 1),
                                       ok("Tx", 1), 1, tau, "j", "p", "r")
    with pytest.raises(ob.ObservationError):
        ob.ObservedFamily("F", "A", tuple(wrong_family))
    with pytest.raises(ob.ObservationError):                       # duplicate rep
        ob.ObservedFamily("F", "A", tuple(good + [good[0]]))


def test_orbit_robust_is_family_level_not_replicate_level():
    """Round-8 B08: one bad replicate must not fail the family."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    arrows = []
    for aid in ob.REQUIRED_ARROWS:
        for rep in range(ob.R_REPLICATES):
            bad = (aid == "T1" and rep == 0)          # a single bad replicate
            arrows.append(ob.ArrowResponse(
                "F", "A", aid, rep, "cert", ok("x", 1),
                ok("Tx", 2 if bad else 1), 1, tau, "j", "p", "r"))
    fam = ob.ObservedFamily("F", "A", tuple(arrows))
    assert fam.orbit_robust_bounds() == (1.0, 1.0)  # majority absorbs one replicate
    ms = ob.metric_suite([fam])
    assert ms["aggregation"]["A_orb"].startswith("family-level")


def test_metric_suite_is_derived_not_supplied():
    p, obs, recs = _syn_run()
    ms = ob.metric_suite(obs)
    for k in ("D_u_bounds", "A_G_bounds", "A_orb_bounds"):
        lo, hi = ms[k]
        assert lo is None or (0.0 <= lo <= hi <= 1.0)
    assert ms["failure_counts"]
    assert set(ms["tie_rate_by_arm_class"]) == {"structural", "surface"}
    out = an._run_confirmatory_with_manifest(obs, recs, p, registry=an.simulation_registry(obs))
    assert "metrics" in out and out["metrics"]["D_u_bounds"][0] is not None


def test_simulation_generates_both_sides_independently():
    """Round-7 blocker 5: asymmetric outcomes must be reachable."""
    rng = np.random.default_rng(9)
    obs = an.simulate_observed_families(60, 6, beta=0.7, mu=[-1.0] * 6,
                                        sigma=[0.6] * 6, rng=rng,
                                        p_apparatus=0.05, p_refusal=0.05,
                                        p_parsefail=0.05, p_judge=0.02)
    arrows = [a for f in obs for a in f.arrows]
    asym = [a for a in arrows
            if a.canonical.parsed() != a.transformed.parsed()]
    assert asym, "one-sided parse outcomes must occur"
    both_ok_diff = [a for a in arrows
                    if a.joint_parse() and a.transport_discrepancy() == 1.0]
    assert both_ok_diff, "both parsed but not transported must occur"


def test_admission_schema_requires_six_modules_and_all_fields():
    doc = _json.load(open(_os.path.join(_HERE, "admission.json"), encoding="utf-8"))
    import copy as _c
    five = _c.deepcopy(doc); five["policy"]["module_universe"] = list("ABCDE")
    with pytest.raises(an.ProtocolError):
        an.validate_admission_document(five)
    noarms = _c.deepcopy(doc)
    noarms["families"][sorted(noarms["families"])[0]].pop("arms")
    with pytest.raises(an.ProtocolError):
        an.validate_admission_document(noarms)


def test_audit_requires_nonempty_provenance():
    adm = an.Admission(permissive=True)
    blank = [an.EvaluatorAuditRecord("F", a, "A", False, "", "") 
             for a in an.REQUIRED_ARROWS]
    with pytest.raises(an.ProtocolError):
        an.validate_audit_records(blank, adm, ["A"], strict=True)


def test_grid_heterogeneity_varies_mu_and_sigma():
    rows = an.run_grid(targets=(0.0,), reps=2, calib_reps=6, heterogeneity=(4.0,),
                       B_prim=100, B_wild=80, B_curve=80, B_sens=60)
    assert rows[0]["heterogeneity"] == 4.0
    assert rows[0]["mu0"] == -1.2         # module 0 anchors; later modules differ


# ---------------------------------------------------------------------------
# Round-8 regression tests: one per reproduced counterexample.
# ---------------------------------------------------------------------------
def test_r8_manifest_is_not_caller_selectable():
    """B01: the public confirmatory API has no manifest_path."""
    import inspect
    assert "manifest_path" not in inspect.signature(
        an.run_confirmatory_analysis).parameters
    assert an.run_confirmatory_analysis.__doc__
    # the substitute-manifest route exists only as a named private helper
    assert hasattr(an, "_run_confirmatory_with_manifest")
    p, obs, recs = _syn_run()
    out = an._run_confirmatory_with_manifest(obs, recs, p, registry=an.simulation_registry(obs))
    assert out["manifest_provenance"] == "caller-supplied (test helper)"


def test_r8_digest_pin_can_only_tighten():
    with pytest.raises(an.ProtocolError):
        an.run_confirmatory_analysis([], audit_records=[],
                                     expected_manifest_digest="0" * 64)


def test_r8_audit_certificate_and_judge_must_match_administered():
    """B03/M14: WRONG-CERT and OTHER-JUDGE must both be refused."""
    p, obs, recs = _syn_run()
    wrong_cert = [an.EvaluatorAuditRecord(r.family_id, r.arrow_id, r.module,
                                          r.discrepant, "WRONG-CERT",
                                          r.judge_version, r.parser_version,
                                          r.renderer_version) for r in recs]
    out = an._run_confirmatory_with_manifest(obs, wrong_cert, p, registry=an.simulation_registry(obs))
    assert not out["admissible_test"] and "certificate" in out["verdict"]
    other_judge = [an.EvaluatorAuditRecord(r.family_id, r.arrow_id, r.module,
                                           r.discrepant, r.certificate_digest,
                                           "OTHER-JUDGE", r.parser_version,
                                           r.renderer_version) for r in recs]
    out2 = an._run_confirmatory_with_manifest(obs, other_judge, p, registry=an.simulation_registry(obs))
    assert not out2["admissible_test"] and "judge" in out2["verdict"]


def test_r8_failed_negative_control_blocks_confirmation():
    """B04: negative_control rejected=False must make the run inadmissible."""
    p, obs, recs = _syn_run()
    def _degenerate(o):
        nc = o.negative_control
        return ob.NegativeControl(
            family_id=nc.family_id, presentation_id=nc.presentation_id,
            canonical_gold=nc.canonical_gold,
            neighboring_gold=nc.canonical_gold,      # same gold: not distinct
            anti_certificate_id=nc.anti_certificate_id,
            anti_certificate_digest=nc.anti_certificate_digest,
            normalizer_status=ob.Status.OK,
            normalizer_output=nc.canonical_gold,     # collapsed
            parser_version=nc.parser_version,
            renderer_version=nc.renderer_version,
            provenance_digest=nc.provenance_digest)
    broken = [ob.ObservedFamily(o.family_id, o.module, o.arrows,
                                negative_control=_degenerate(o)) for o in obs]
    out = an._run_confirmatory_with_manifest(broken, recs, p, registry=an.simulation_registry(obs))
    assert not out["admissible_test"]
    assert "n-i negative control" in out["verdict"].lower()
    missing = [ob.ObservedFamily(o.family_id, o.module, o.arrows,
                                 negative_control=None) for o in obs]
    out2 = an._run_confirmatory_with_manifest(missing, recs, p, registry=an.simulation_registry(obs))
    assert not out2["admissible_test"] and "N-i control" in out2["verdict"]


def test_r8_confirmatory_returns_threshold_and_sensitivity():
    """B06/M13: the paired confirmatory path must report them."""
    p, obs, recs = _syn_run(n_per_module=94, seed=5)
    out = an._run_confirmatory_with_manifest(obs, recs, p, delta_eval=0.01, registry=an.simulation_registry(obs))
    assert out["admissible_test"] and out["estimation_performed"]
    for key in ("threshold_curve", "threshold_curve_kind",
                "differential_evaluator", "target_population_mismatch"):
        assert key in out, key
    assert out["differential_evaluator"]["engine"] in ("percentile-t",
                                                       "wild-cluster")
    assert out["differential_evaluator"]["engine"] in out["decision_basis"]


def test_r8_grid_uses_the_paired_model():
    """B05: the grid must not call the scalar simulator."""
    import inspect
    src = inspect.getsource(an.run_grid)
    assert "simulate_observed_families" in src
    assert "Admission(permissive=True)" not in src
    rows = an.run_grid(targets=(0.05,), reps=2, calib_reps=6, B_prim=100,
                       B_wild=80, B_curve=80, B_sens=50)
    assert "paired records" in rows[0]["scope"]
    assert rows[0]["transport_factor"] == 1.0


def test_r8_grid_exercises_non_identity_transport():
    rows = an.run_grid(targets=(0.05,), reps=2, calib_reps=6, transport_factor=3,
                       B_prim=100, B_wild=80, B_curve=80, B_sens=50)
    assert rows[0]["transport_factor"] == 3.0


def test_r8_metric_aggregation_levels_are_declared():
    """B08."""
    p, obs, recs = _syn_run()
    ms = ob.metric_suite(obs)
    agg = ms["aggregation"]
    assert agg["D_u"].startswith("arrow-level")
    assert agg["A_orb"].startswith("family-level")


# ---------------------------------------------------------------------------
# Round-9 regression tests: one per reproduced counterexample.
# ---------------------------------------------------------------------------
def test_r9_transport_must_be_a_verified_bijection():
    """R9-1: tau(v)=2v declared int->int is not an automorphism of int."""
    with pytest.raises(ob.ObservationError):
        ob.Transport("scale2", "1", "int", "int", "c",
                     lambda v: 2 * v, lambda v: v // 2, source_domain=(1, 2, 3))
    with pytest.raises(ob.ObservationError):          # non-injective
        ob.Transport("const", "1", "int", "int", "c",
                     lambda v: 1, lambda v: 1, source_domain=(1, 2))
    with pytest.raises(ob.ObservationError):          # no certified domain
        ob.Transport("id", "1", "int", "int", "c", lambda v: v, lambda v: v)
    with pytest.raises(ob.ObservationError):          # blank provenance
        ob.Transport("", "1", "int", "int", "c", lambda v: v, lambda v: v,
                     source_domain=(1,))
    with pytest.raises(ob.ObservationError):          # token is registry-only
        ob.Transport("id", "1", "int", "int", "c", lambda v: v, lambda v: v,
                     source_domain=(1,), _registry_token=object())
    good = ob.negation_transport("int", "c", (1, 2))
    good.check_roundtrip()
    assert good.apply(2) == -2
    typed = ob.Transport("double", "1", "int", "even_int", "c",
                         lambda v: 2 * v, lambda v: v // 2, source_domain=(1, 2),
                         arrow_certificate_digest="c")
    assert typed.apply(2) == 4


def test_r9_negative_control_verdict_is_derived_not_supplied():
    """R9-2 and R10-2: same-gold, collapsed and unreplayed controls all fail,
    and replay is performed by the frozen registry, never asserted."""
    base = dict(family_id="F", presentation_id="F:n", anti_certificate_id="a",
                anti_certificate_digest="d", parser_version="p",
                renderer_version="r", provenance_digest="prov")
    reg = ob.AntiCertificateRegistry()
    reg.register("a", "d", lambda c: c.neighboring_gold != c.canonical_gold)
    kw = dict(registry=reg, family_id="F", parser_version="p",
              renderer_version="r")
    same_gold = ob.NegativeControl(canonical_gold=1, neighboring_gold=1,
                                   normalizer_status=ob.Status.OK,
                                   normalizer_output=1, **base)
    assert not same_gold.rejected(**kw)
    collapsed = ob.NegativeControl(canonical_gold=1, neighboring_gold=2,
                                   normalizer_status=ob.Status.OK,
                                   normalizer_output=1, **base)
    assert not collapsed.rejected(**kw)
    assert "collapsed" in collapsed.record_reasons()[0]
    ok = ob.NegativeControl(canonical_gold=1, neighboring_gold=2,
                            normalizer_status=ob.Status.OK, normalizer_output=2,
                            **base)
    assert ok.rejected(**kw) and ok.reasons(**kw) == []
    # replay is never assumed: without a registry the control does not pass
    assert not ok.rejected(family_id="F", parser_version="p", renderer_version="r")
    with pytest.raises(ob.ObservationError):
        ob.NegativeControl(canonical_gold=1, neighboring_gold=2,
                           normalizer_status=ob.Status.OK, normalizer_output=2,
                           **{**base, "provenance_digest": ""})


def test_r9_mixed_replicate_provenance_is_rejected():
    """R9-3: one replicate with a different apparatus must not be hidden."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    def build(**override):
        arrows = []
        for aid in ob.REQUIRED_ARROWS:
            for rep in range(ob.R_REPLICATES):
                kw = dict(certificate_digest="cert", judge_version="j",
                          parser_version="p", renderer_version="r")
                if aid == "T1" and rep == 0:
                    kw.update(override)
                arrows.append(ob.ArrowResponse(
                    "F", "A", aid, rep, kw["certificate_digest"],
                    ok("F:x", 1), ok(f"F:{aid}", 1), 1,
                    tau if kw["certificate_digest"] == "cert"
                    else ob.identity_transport("int", kw["certificate_digest"], (1, 2)),
                    kw["judge_version"], kw["parser_version"],
                    kw["renderer_version"]))
        return arrows
    ob.ObservedFamily("F", "A", tuple(build()))              # uniform: valid
    for override in ({"judge_version": "OTHER-JUDGE"},
                     {"parser_version": "OTHER-PARSER"},
                     {"renderer_version": "OTHER-RENDERER"},
                     {"certificate_digest": "OTHER-CERT"}):
        with pytest.raises(ob.ObservationError):
            ob.ObservedFamily("F", "A", tuple(build(**override)))


def test_r9_refusal_is_charged_in_A_G_and_A_orb():
    """R9-4: four refused T1 responses must not give A_G = 1.0, A_orb = None."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    arrows = []
    for aid in ob.REQUIRED_ARROWS:
        for rep in range(ob.R_REPLICATES):
            tr = (ob.SideResponse(f"F:{aid}", ob.Status.REFUSAL) if aid == "T1"
                  else ok(f"F:{aid}", 1))
            arrows.append(ob.ArrowResponse("F", "A", aid, rep, "cert",
                                           ok("F:x", 1), tr, 1, tau,
                                           "j", "p", "r"))
    fam = ob.ObservedFamily("F", "A", tuple(arrows))
    assert fam.arrow_transformed_correct("T1") is False      # charged, not None
    ms = ob.metric_suite([fam])
    assert ms["A_G_bounds"][1] < 1.0
    assert ms["A_orb_bounds"] == (0.0, 0.0)                                # not dropped


def test_r9_missing_replicates_are_voted_through_not_discarded():
    """R9-5: [0, None, None, None] is partially identified, not a success."""
    assert ob.majority_bounds([0.0, None, None, None]) == (0.0, 1.0)
    assert ob.majority_bounds([0.0, 0.0, 0.0, 0.0]) == (0.0, 0.0)
    assert ob.majority_bounds([1.0, 1.0, None, None]) == (1.0, 1.0)
    assert ob.majority_bounds([None] * 4) == (0.0, 1.0)
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    app = lambda pid: ob.SideResponse(pid, ob.Status.APPARATUS)
    arrows = []
    for aid in ob.REQUIRED_ARROWS:
        for rep in range(ob.R_REPLICATES):
            lost = (aid == "T1" and rep > 0)
            arrows.append(ob.ArrowResponse(
                "F", "A", aid, rep, "cert",
                app("F:x") if lost else ok("F:x", 1),
                app(f"F:{aid}") if lost else ok(f"F:{aid}", 1),
                1, tau, "j", "p", "r"))
    fam = ob.ObservedFamily("F", "A", tuple(arrows))
    lo, hi = fam.arm_defect_bounds("T1")
    assert (lo, hi) == (0.0, 1.0)          # not fixed at 0
    flo, fhi = fam.difference_bounds()
    assert flo < fhi                        # the family interval is not a point


def test_r9_permissive_and_helper_never_return_confirmatory_labels():
    """R9-6: no permissive path may return mode=confirmatory or bare admissible."""
    assert not hasattr(an, "run_primary_analysis")
    fams = _sim(n=24, modules=6)
    r = an.run_exploratory_analysis(
        fams, admission=an.Admission(permissive=True), require_manifest=False,
        family_defects_by_module={m: [0.0] * 94 for m in an.declared_modules(fams)},
        B_prim=100, B_wild=80, B_curve=80, B_sens=50)
    assert r["mode"] == "exploratory" and "admissible" not in r
    p, obs, recs = _syn_run()
    out = an._run_confirmatory_with_manifest(obs, recs, p, registry=an.simulation_registry(obs))
    assert out["mode"] == "test-helper" and "admissible" not in out
    assert out["manifest_provenance"] == "caller-supplied (test helper)"


def test_r9_judge_layer_is_explicit_in_the_simulator():
    """R9-7: p_judge acts on the judge's reading, not the model's answer."""
    import inspect
    src = inspect.getsource(an.simulate_observed_families)
    assert "judged_wrong" in src and "model_wrong" in src


# ---------------------------------------------------------------------------
# Round-10 regression tests: one per reproduced counterexample.
# ---------------------------------------------------------------------------
def test_r10_transport_image_must_equal_declared_target():
    """R10-1a: tau({1,2}) = {2,4} != declared target (2,6)."""
    with pytest.raises(ob.ObservationError):
        ob.Transport("bad", "1", "int", "other", "c",
                     lambda x: 2 * x, lambda y: y // 2,
                     source_domain=(1, 2), target_domain=(2, 6))
    good = ob.Transport("double", "1", "int", "even_int", "c",
                        lambda x: 2 * x, lambda y: y // 2,
                        source_domain=(1, 2), target_domain=(2, 4))
    assert good.apply(2) == 4


def test_r10_typed_transport_is_total_on_its_type():
    """Round-12: totality now belongs to REGISTRY-ISSUED typed transports."""
    t = cr.PRODUCTION_REGISTRY.resolve_transport(
        transport_id=cr.BuiltinTransportId.INT_NEGATION_V1.value, version="1",
        expected_transport_certificate_digest=cr.TRANSPORT_DIGESTS[
            cr.BuiltinTransportId.INT_NEGATION_V1.value],
        arrow_certificate_digest="arrow-1")
    assert t.domain_kind == "typed"
    assert t.apply(3) == -3 and t.apply(-7) == 7 and t.apply(10 ** 9) == -(10 ** 9)
    with pytest.raises(ob.ObservationError):
        t.apply("not-an-int")
    f = ob.Transport("perm", "1", "lbl", "lbl", "c",
                     lambda v: {"a": "b", "b": "a"}[v],
                     lambda v: {"a": "b", "b": "a"}[v],
                     source_domain=("a", "b"), domain_kind="finite",
                     arrow_certificate_digest="c")
    assert f.apply("a") == "b"
    with pytest.raises(ob.ObservationError):
        f.apply("z")


def test_r10_wrong_typed_answer_yields_a_defect_not_a_crash():
    """The point of totality: an unexpected integer must produce a defect."""
    tau = ob.negation_transport("int", "cert", (3, 99))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    a = ob.ArrowResponse("F", "A", "T1", 0, "cert", ok("x", 3), ok("Tx", 99),
                         1, tau, "j", "p", "r")
    assert a.transport_discrepancy() == 1.0        # -3 != 99
    b = ob.ArrowResponse("F", "A", "T1", 1, "cert", ok("x", 3), ok("Tx", -3),
                         1, tau, "j", "p", "r")
    assert b.transport_discrepancy() == 0.0


def test_r10_anti_certificate_must_resolve_and_replay():
    """R10-2: a foreign-family control with a fabricated digest must fail."""
    reg = ob.AntiCertificateRegistry()
    reg.register("real", "dig", lambda c: c.neighboring_gold != c.canonical_gold)
    fake = ob.NegativeControl(
        family_id="OTHER-FAMILY", presentation_id="p", canonical_gold=1,
        neighboring_gold=2, anti_certificate_id="NONEXISTENT",
        anti_certificate_digest="FAKE", normalizer_status=ob.Status.OK,
        normalizer_output=2, parser_version="x", renderer_version="y",
        provenance_digest="z")
    reasons = fake.reasons(reg, family_id="F", parser_version="p",
                           renderer_version="r")
    assert not fake.rejected(reg, family_id="F")
    assert any("not in the frozen registry" in r for r in reasons)
    assert any("belongs to family" in r for r in reasons)
    assert any("parser version" in r for r in reasons)
    wrong_digest = ob.NegativeControl(
        family_id="F", presentation_id="p", canonical_gold=1, neighboring_gold=2,
        anti_certificate_id="real", anti_certificate_digest="WRONG",
        normalizer_status=ob.Status.OK, normalizer_output=2, parser_version="p",
        renderer_version="r", provenance_digest="z")
    assert any("digest mismatch" in r
               for r in wrong_digest.reasons(reg, family_id="F"))
    assert "anti_certificate_replayed" not in ob.NegativeControl.__dataclass_fields__


def test_r10_control_is_bound_to_its_family_at_construction():
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    arrows = [ob.ArrowResponse("F", "A", aid, rep, "cert", ok("F:x", 1),
                               ok(f"F:{aid}", 1), 1, tau, "j", "p", "r")
              for aid in ob.REQUIRED_ARROWS for rep in range(ob.R_REPLICATES)]
    foreign = ob.NegativeControl(
        family_id="OTHER", presentation_id="p", canonical_gold=1,
        neighboring_gold=2, anti_certificate_id="a", anti_certificate_digest="d",
        normalizer_status=ob.Status.OK, normalizer_output=2, parser_version="p",
        renderer_version="r", provenance_digest="z")
    with pytest.raises(ob.ObservationError):
        ob.ObservedFamily("F", "A", tuple(arrows), negative_control=foreign)


def test_r10_yield_counts_administered_responses():
    """R10-3: 75% apparatus loss must NOT report a response rate of 1.0."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    app = lambda pid: ob.SideResponse(pid, ob.Status.APPARATUS)
    arrows = []
    for aid in ob.REQUIRED_ARROWS:
        for rep in range(ob.R_REPLICATES):
            lost = rep > 0
            arrows.append(ob.ArrowResponse(
                "F", "A", aid, rep, "cert",
                app("F:x") if lost else ok("F:x", 1),
                app(f"F:{aid}") if lost else ok(f"F:{aid}", 1),
                1, tau, "j", "p", "r"))
    fam = ob.ObservedFamily("F", "A", tuple(arrows))
    y = ob.yield_rates([fam])
    assert y["structural"][0] == 0.25 and y["surface"][0] == 0.25
    assert not yield_gate(y)["passes"]
    d = ob.yield_detail([fam])
    assert d["structural"]["apparatus_loss_rate"] == 0.75
    assert d["structural"]["administered"] == 16


def test_r10_co_metrics_carry_apparatus_uncertainty():
    """R10-4: the same uncertain arrow must not be a definite success here."""
    tau = ob.identity_transport("int", "cert", (1, 2))
    ok = lambda pid, v: ob.SideResponse(pid, ob.Status.OK, normalized=v)
    app = lambda pid: ob.SideResponse(pid, ob.Status.APPARATUS)
    arrows = []
    for aid in ob.REQUIRED_ARROWS:
        for rep in range(ob.R_REPLICATES):
            lost = rep > 0
            arrows.append(ob.ArrowResponse(
                "F", "A", aid, rep, "cert",
                app("F:x") if lost else ok("F:x", 1),
                app(f"F:{aid}") if lost else ok(f"F:{aid}", 1),
                1, tau, "j", "p", "r"))
    fam = ob.ObservedFamily("F", "A", tuple(arrows))
    ms = ob.metric_suite([fam])
    assert fam.arm_defect_bounds("T1") == (0.0, 1.0)
    assert ms["D_u_bounds"] == (0.0, 1.0)
    assert ms["A_G_bounds"] == (0.0, 1.0)
    assert ms["A_orb_bounds"] == (0.0, 1.0)
    assert ms["n_identified_arrows"] == 0
    assert ms["A_G_complete_case"] is None      # no identified arrow to average
    assert "complete-case" in ms["aggregation"]["point_values"]


# ---------------------------------------------------------------------------
# Round-11 adversarial acceptance suite (§7 of the patch plan).
# ---------------------------------------------------------------------------
import certificate_registry as cr


# --- 7.1 transport attacks --------------------------------------------------
def test_r11_typed_transport_cannot_be_certified_by_probes_only():
    """The x == 99 counterexample: probe checks pass, the global law fails."""
    def tau(x):
        return 0 if x == 99 else x

    def tau_inverse(y):
        return y

    probe_ok = ob.Transport("sneaky", "1", "int", "int", "c", tau, tau_inverse,
                            source_domain=(1, 2, -1),
                            source_predicate=lambda v: isinstance(v, int),
                            target_predicate=lambda v: isinstance(v, int),
                            domain_kind="typed")
    assert probe_ok is not None                      # probes alone still pass
    assert tau_inverse(tau(99)) != 99                # but the map is not a bijection
    # Round-12: the callable-registration path is GONE. The production API has
    # no parameter accepting tau or tau_inverse at all, so no sampling question
    # arises -- the registry owns the symbolic map and generates the code.
    import inspect
    params = inspect.signature(
        cr.CertificateRegistry.register_symbolic_transport).parameters
    assert "tau" not in params and "tau_inverse" not in params
    assert set(cr.BuiltinTransportId) and all(
        isinstance(s, cr.SymbolicTransportSpec) for s in cr.PRODUCTION_SPECS)


def test_r11_confirmatory_rejects_unregistered_typed_transport():
    p, obs, recs = _syn_run()
    rogue = ob.Transport("rogue", "1", "int", "int", "cert-x", lambda v: v,
                         lambda v: v, source_domain=(1, 2),
                         source_predicate=lambda v: isinstance(v, int),
                         target_predicate=lambda v: isinstance(v, int),
                         domain_kind="typed", arrow_certificate_digest="cert-x")
    assert not cr.PRODUCTION_REGISTRY.is_certified_transport(rogue)
    f0 = obs[0]
    swapped = tuple(
        ob.ArrowResponse(a.family_id, a.module, a.arrow_id, a.replicate,
                         "cert-x", a.canonical, a.transformed, a.canonical_gold,
                         rogue, a.judge_version, a.parser_version,
                         a.renderer_version) if a.arrow_id == "T1" else a
        for a in f0.arrows)
    tampered = [ob.ObservedFamily(f0.family_id, f0.module, swapped,
                                  negative_control=f0.negative_control)] + list(obs[1:])
    out = an._run_confirmatory_with_manifest(tampered, recs, p,
                                             registry=an.simulation_registry(obs))
    assert not out["admissible_test"]
    assert "package-pinned production registry" in out["verdict"]


def test_r11_registered_typed_transport_is_total_outside_probe_set():
    tid = cr.BuiltinTransportId.INT_NEGATION_V1.value
    t = cr.PRODUCTION_REGISTRY.resolve_transport(
        transport_id=tid, version="1",
        expected_transport_certificate_digest=cr.TRANSPORT_DIGESTS[tid],
        arrow_certificate_digest="arrow-1")
    assert t.apply(99) == -99 and t.apply(10 ** 9) == -(10 ** 9)
    assert cr.PRODUCTION_REGISTRY.is_certified_transport(t)


def test_r11_transport_registry_digest_mismatch_fails():
    tid = cr.BuiltinTransportId.INT_NEGATION_V1.value
    with pytest.raises(ob.ObservationError):
        cr.PRODUCTION_REGISTRY.resolve_transport(
            transport_id=tid, version="1",
            expected_transport_certificate_digest="WRONG",
            arrow_certificate_digest="a")
    with pytest.raises(ob.ObservationError):
        cr.PRODUCTION_REGISTRY.resolve_transport(
            transport_id="nonexistent", version="1",
            expected_transport_certificate_digest="x",
            arrow_certificate_digest="a")


def test_r11_finite_transport_image_equals_declared_target():
    with pytest.raises(ob.ObservationError):
        ob.Transport("bad", "1", "int", "other", "c", lambda x: 2 * x,
                     lambda y: y // 2, source_domain=(1, 2),
                     target_domain=(2, 6), domain_kind="finite",
                     arrow_certificate_digest="c")


# --- 7.2 registry attacks ---------------------------------------------------
def test_r11_confirmatory_has_no_registry_override():
    import inspect
    sig = inspect.signature(an.run_confirmatory_analysis).parameters
    assert "anti_certificate_registry" not in sig
    assert "registry" not in sig


def test_r11_production_registry_rejects_duplicate_ids():
    r = cr.CertificateRegistry()
    e = cr.AntiCertificateEntry("x", "d", ("F",), "N-i", lambda c: True, "1")
    r.register_anti(e)
    with pytest.raises(ob.ObservationError):
        r.register_anti(cr.AntiCertificateEntry("x", "d2", ("F",), "N-i",
                                                lambda c: True, "1"))
    spec = cr.SymbolicTransportSpec("dup", "1", "int", "int", "x", "x", "d")
    r.register_symbolic_transport(spec)
    with pytest.raises(ob.ObservationError):
        r.register_symbolic_transport(spec)


def test_r11_production_registry_is_sealed():
    assert cr.PRODUCTION_REGISTRY.sealed is True
    with pytest.raises(ob.ObservationError):
        cr.PRODUCTION_REGISTRY.register_anti(
            cr.AntiCertificateEntry("evil", "d", ("F",), "N-i",
                                    lambda c: True, "1"))
    with pytest.raises(ob.ObservationError):
        cr.PRODUCTION_REGISTRY.register_symbolic_transport(
            cr.SymbolicTransportSpec("evil", "1", "int", "int", "x", "x", "d"))


def test_r11_fabricated_anti_certificate_cannot_pass():
    """A verifier that always returns True is useless without registration."""
    fake = ob.NegativeControl(
        family_id="F", presentation_id="p", canonical_gold=1, neighboring_gold=2,
        anti_certificate_id="FABRICATED", anti_certificate_digest="FAKE",
        normalizer_status=ob.Status.OK, normalizer_output=2, parser_version="p",
        renderer_version="r", provenance_digest="z")
    ok, why = cr.PRODUCTION_REGISTRY.replay_anti(fake)
    assert ok is False and "not in the frozen registry" in why


def test_r11_anti_certificate_is_bound_to_family():
    r = cr.CertificateRegistry()
    r.register_anti(cr.AntiCertificateEntry("a", "d", ("FAM-A",), "N-i",
                                            lambda c: True, "1"))
    r.seal()
    other = ob.NegativeControl(
        family_id="FAM-B", presentation_id="p", canonical_gold=1,
        neighboring_gold=2, anti_certificate_id="a", anti_certificate_digest="d",
        normalizer_status=ob.Status.OK, normalizer_output=2, parser_version="p",
        renderer_version="r", provenance_digest="z")
    ok, why = r.replay_anti(other)
    assert ok is False and "not registered for family" in why


def test_r11_test_registry_never_returns_confirmatory_schema():
    p, obs, recs = _syn_run()
    out = an._run_confirmatory_with_manifest(obs, recs, p,
                                             registry=an.simulation_registry(obs))
    assert out["mode"] == "test-helper" and "admissible" not in out
    assert "admissible_test" in out


# --- 7.3 provenance attacks -------------------------------------------------
def test_r11_observed_response_requires_finish_reason():
    with pytest.raises(ob.ObservationError):
        ob.SideResponse("F:x", ob.Status.OK, normalized=1,
                        record_kind="observed", raw_digest="a" * 64)


def test_r11_observed_response_requires_raw_digest():
    with pytest.raises(ob.ObservationError):
        ob.SideResponse("F:x", ob.Status.OK, normalized=1,
                        record_kind="observed", provider_finish_reason="stop")


def test_r11_raw_digest_must_be_sha256():
    for bad in ("deadbeef", "A" * 64, "z" * 64, ""):
        with pytest.raises(ob.ObservationError):
            ob.SideResponse("F:x", ob.Status.OK, normalized=1,
                            record_kind="observed",
                            provider_finish_reason="stop", raw_digest=bad)
    good = ob.SideResponse("F:x", ob.Status.OK, normalized=1,
                           record_kind="observed",
                           provider_finish_reason="stop", raw_digest="a" * 64)
    assert good.provider_finish_reason is ob.FinishReason.STOP


def test_r11_synthetic_response_rejected_by_confirmatory_route():
    p, obs, recs = _syn_run()
    f0 = obs[0]
    a0 = f0.arrows[0]
    synth = ob.SideResponse(a0.canonical.presentation_id, ob.Status.OK,
                            normalized=a0.canonical.normalized)   # synthetic
    tampered_arrows = (ob.ArrowResponse(
        a0.family_id, a0.module, a0.arrow_id, a0.replicate, a0.certificate_digest,
        synth, a0.transformed, a0.canonical_gold, a0.transport, a0.judge_version,
        a0.parser_version, a0.renderer_version),) + f0.arrows[1:]
    tampered = [ob.ObservedFamily(f0.family_id, f0.module, tampered_arrows,
                                  negative_control=f0.negative_control)] + list(obs[1:])
    out = an._run_confirmatory_with_manifest(tampered, recs, p,
                                             registry=an.simulation_registry(obs))
    assert not out["admissible_test"] and "synthetic" in out["verdict"]


def test_r11_finish_reason_controls_truncation_classification():
    assert ob.FinishReason.LENGTH.is_budget_truncation
    assert ob.FinishReason.TRANSPORT_ERROR.is_apparatus
    assert not ob.FinishReason.STOP.is_apparatus
    with pytest.raises(ob.ObservationError):      # length must not be OK
        ob.SideResponse("F:x", ob.Status.OK, normalized=1,
                        record_kind="observed", provider_finish_reason="length",
                        raw_digest="a" * 64)
    with pytest.raises(ob.ObservationError):      # transport_error must be APPARATUS
        ob.SideResponse("F:x", ob.Status.REFUSAL, record_kind="observed",
                        provider_finish_reason="transport_error",
                        raw_digest="a" * 64)
    ok = ob.SideResponse("F:x", ob.Status.PARSE_FAIL, record_kind="observed",
                         provider_finish_reason="length", raw_digest="a" * 64)
    assert ok.status is ob.Status.PARSE_FAIL


# --- 7.4 manifest attacks ---------------------------------------------------
def test_r11_confirmatory_rejects_modified_admission_json():
    """Editing admission.json by one byte must fail confirmatory startup."""
    import shutil, tempfile, json
    src = os.path.join(_HERE, "admission.json")
    backup = shutil.copy(src, tempfile.mktemp())
    try:
        doc = json.load(open(src, encoding="utf-8"))
        doc["policy"]["note"] = doc["policy"]["note"] + " "     # one byte
        open(src, "w", encoding="utf-8").write(json.dumps(doc, indent=2,
                                                          sort_keys=True) + "\n")
        with pytest.raises(an.ProtocolError):
            an._load_pinned()
    finally:
        shutil.copy(backup, src)
    an._load_pinned()                                   # restored, passes again


def test_r11_confirmatory_rejects_missing_or_duplicate_manifest_entry():
    import shutil, tempfile
    src = os.path.join(_HERE, "MANIFEST.sha256")
    backup = shutil.copy(src, tempfile.mktemp())
    lines = open(src, encoding="utf-8").read().splitlines()
    try:
        kept = [l for l in lines if not l.endswith("  admission.json")]
        open(src, "w", encoding="utf-8").write("\n".join(kept) + "\n")
        with pytest.raises(an.ProtocolError):
            an._load_pinned()
        dup = [l for l in lines if l.endswith("  admission.json")]
        open(src, "w", encoding="utf-8").write("\n".join(lines + dup) + "\n")
        with pytest.raises(an.ProtocolError):
            an._load_pinned()
    finally:
        shutil.copy(backup, src)
    an._load_pinned()


def test_r11_optional_expected_digest_can_only_be_stricter():
    adm = an._load_pinned()
    assert an._load_pinned(adm.digest).digest == adm.digest    # agreeing: fine
    with pytest.raises(an.ProtocolError):                      # disagreeing: fails
        an._load_pinned("0" * 64)
    assert an.PINNED_ADMISSION_SHA256 == adm.digest


# ---------------------------------------------------------------------------
# Round-12 regression tests: registry authenticity (§9 of the patch plan).
# ---------------------------------------------------------------------------
def _prod(tid=None, arrow="family-arrow-cert"):
    tid = tid or cr.BuiltinTransportId.INT_IDENTITY_V1.value
    return cr.PRODUCTION_REGISTRY.resolve_transport(
        transport_id=tid, version="1",
        expected_transport_certificate_digest=cr.TRANSPORT_DIGESTS[tid],
        arrow_certificate_digest=arrow)


def test_r12_branch_outside_faithfulness_sample_is_rejected():
    """§9.1. The BAD = 123456789 branch is symbolically invisible and outside
    any bounded sample. The preferred fix applies: the production API has NO
    parameter accepting an executable callable, so the attack has no surface."""
    import inspect
    params = inspect.signature(
        cr.CertificateRegistry.register_symbolic_transport).parameters
    assert "tau" not in params and "tau_inverse" not in params
    rp = inspect.signature(cr.CertificateRegistry.resolve_transport).parameters
    assert "tau" not in rp and "tau_inverse" not in rp
    # the only production definitions are package-owned symbolic specs
    assert all(isinstance(s, cr.SymbolicTransportSpec) for s in cr.PRODUCTION_SPECS)
    assert {s.transport_id for s in cr.PRODUCTION_SPECS} == {
        m.value for m in cr.BuiltinTransportId}
    # and the generated implementation is correct at the adversarial point
    BAD = 123456789
    t = _prod(cr.BuiltinTransportId.INT_NEGATION_V1.value)
    assert t.apply(BAD) == -BAD and t.tau_inverse(t.apply(BAD)) == BAD


def test_r12_forged_transport_subclass_is_not_certified():
    """§9.2."""
    valid = _prod()

    class ForgedTransport(ob.Transport):
        pass

    forged = object.__new__(ForgedTransport)
    for k, v in valid.__dict__.items():
        object.__setattr__(forged, k, v)
    assert not cr.PRODUCTION_REGISTRY.is_certified_transport(forged)
    # a genuine Transport with copied PUBLIC metadata but no token also fails
    copied = ob.Transport(valid.transport_id, valid.transport_version,
                          valid.source_answer_type, valid.target_answer_type,
                          valid.transport_certificate_digest,
                          valid.tau, valid.tau_inverse,
                          source_domain=valid.source_domain,
                          source_predicate=valid.source_predicate,
                          target_predicate=valid.target_predicate,
                          domain_kind="typed",
                          arrow_certificate_digest=valid.arrow_certificate_digest)
    assert not cr.PRODUCTION_REGISTRY.is_certified_transport(copied)


def test_r12_registered_metadata_with_replaced_callable_is_rejected():
    """§9.3."""
    valid = _prod()
    forged = object.__new__(ob.Transport)
    for k, v in valid.__dict__.items():
        object.__setattr__(forged, k, v)
    assert cr.PRODUCTION_REGISTRY.is_certified_transport(forged)   # exact copy
    object.__setattr__(forged, "tau", lambda x: 0 if x == 999999 else x)
    assert not cr.PRODUCTION_REGISTRY.is_certified_transport(forged)


def test_r12_registered_metadata_with_replaced_inverse_is_rejected():
    """§9.4."""
    valid = _prod()
    forged = object.__new__(ob.Transport)
    for k, v in valid.__dict__.items():
        object.__setattr__(forged, k, v)
    object.__setattr__(forged, "tau_inverse", lambda y: y)
    assert not cr.PRODUCTION_REGISTRY.is_certified_transport(forged)


def test_r12_transport_digest_cannot_be_overridden():
    """§9.5."""
    import inspect
    params = inspect.signature(cr.CertificateRegistry.resolve_transport).parameters
    assert "certificate_digest" not in params
    assert "expected_transport_certificate_digest" in params
    with pytest.raises(ob.ObservationError):
        cr.PRODUCTION_REGISTRY.resolve_transport(
            transport_id=cr.BuiltinTransportId.INT_IDENTITY_V1.value,
            version="1", expected_transport_certificate_digest="wrong",
            arrow_certificate_digest="family-arrow-cert")
    tid = cr.BuiltinTransportId.INT_IDENTITY_V1.value
    assert _prod().transport_certificate_digest == cr.TRANSPORT_DIGESTS[tid]


def test_r12_transport_and_arrow_digests_are_distinct():
    """§9.6."""
    tid = cr.BuiltinTransportId.INT_IDENTITY_V1.value
    t = _prod(tid, arrow="family-arrow-cert")
    assert t.transport_certificate_digest == cr.TRANSPORT_DIGESTS[tid]
    assert t.arrow_certificate_digest == "family-arrow-cert"
    assert t.transport_certificate_digest != t.arrow_certificate_digest


def test_r12_sealed_registry_mappings_are_immutable():
    """§9.7."""
    with pytest.raises(TypeError):
        cr.PRODUCTION_REGISTRY._transports[("evil", "1")] = object()
    with pytest.raises(TypeError):
        cr.PRODUCTION_REGISTRY._anti["evil"] = object()
    with pytest.raises(TypeError):
        del cr.PRODUCTION_REGISTRY._anti["anything"]


def test_r12_sealed_registry_attributes_cannot_be_reassigned():
    """§9.8."""
    with pytest.raises(ob.ObservationError):
        cr.PRODUCTION_REGISTRY._transports = {}
    with pytest.raises(ob.ObservationError):
        cr.PRODUCTION_REGISTRY._anti = {}
    with pytest.raises(ob.ObservationError):
        cr.PRODUCTION_REGISTRY._sealed = False


def test_r12_serialized_registry_marker_does_not_grant_certification():
    """§9.9: a Boolean marker or tuple key carries no authority."""
    t = ob.Transport("int_identity_v1", "1", "int", "int",
                     cr.TRANSPORT_DIGESTS[cr.BuiltinTransportId.INT_IDENTITY_V1.value],
                     lambda v: v, lambda v: v, source_domain=(1, 2),
                     source_predicate=lambda v: isinstance(v, int),
                     target_predicate=lambda v: isinstance(v, int),
                     domain_kind="typed", arrow_certificate_digest="a")
    object.__setattr__(t, "registry_certified", True)      # forged marker
    object.__setattr__(t, "registry_key", ("int_identity_v1", "1"))
    assert not cr.PRODUCTION_REGISTRY.is_certified_transport(t)


def test_r12_confirmatory_re_resolves_transport_from_registry():
    """§9.10: simulated confirmatory families carry registry-issued transports."""
    p, obs, recs = _syn_run()
    for f in obs:
        for a in f.arrows:
            assert cr.PRODUCTION_REGISTRY.is_certified_transport(a.transport)
            assert a.transport.arrow_certificate_digest == a.certificate_digest
            assert (a.transport.transport_certificate_digest
                    != a.transport.arrow_certificate_digest)
