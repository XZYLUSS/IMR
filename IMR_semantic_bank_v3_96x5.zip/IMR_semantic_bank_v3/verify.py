from pathlib import Path
import hashlib,json,sys
from core import *
from catalog import folder
from materialize_families import artifact_data,ARMS,presentations,prompt,sha
ROOT=Path(__file__).resolve().parent

def replay_one(fid,problem_hash=None,transform_hash=None,quiet=False):
    f=next(v for v in families() if v['id']==fid);prefix=folder(f);d=ROOT/'families_repo'/prefix
    p=d/(prefix+'-problem.json');t=d/(prefix+'-transform.json')
    if problem_hash:assert sha(p.read_bytes())==problem_hash
    if transform_hash:assert sha(t.read_bytes())==transform_hash
    pp,tt,rr,_,_=artifact_data(f)
    assert json.loads(p.read_text())==json.loads(dumps(pp)),fid+' problem mismatch'
    assert json.loads(t.read_text())==json.loads(dumps(tt)),fid+' transform mismatch'
    for path in d.iterdir():assert path.read_bytes()==(ROOT/'families_repo'/'all_files'/path.name).read_bytes()
    if not quiet:print(fid,'certificate replay PASS')
    return rr

def verify_manifest(root):
    path=root/'MANIFEST.sha256';count=0
    for line in path.read_text().splitlines():
        expected,rel=line.split('  ',1);p=root/rel
        assert p.is_file() and not p.is_symlink(),rel
        assert sha(p.read_bytes())==expected,rel+' hash mismatch';count+=1
    return count

def verify_sources():
    provenance=json.loads((ROOT/'PROVENANCE.json').read_text());results=[]
    for v in provenance['sources']:
        p=Path(v['path'])
        if not p.exists():results.append({'path':str(p),'available':False});continue
        assert sha(p.read_bytes())==v['sha256'],str(p)
        result={'path':str(p),'available':True,'hash_match':True}
        if p.name=='MANIFEST.sha256':result['verified_members']=verify_manifest(p.parent)
        results.append(result)
    return results

def verify(check_manifest=True):
    pub=json.loads((ROOT/'model_prompts.json').read_text());pri=json.loads((ROOT/'presentations.json').read_text());stored=json.loads((ROOT/'CERTIFICATE_RESULTS.json').read_text())
    assert len(pub)==len(pri)==480
    assert all(set(v)=={'prompt_id','prompt'} for v in pub)
    assert len({v['prompt_id'] for v in pub})==480
    replays=[];i=0;distinct=[]
    for f in families():
        replays.append(replay_one(f['id'],quiet=True))
        for arm,ff in zip(ARMS,presentations(f)):
            ans=solve(ff);pid=f['id']+'/'+arm
            assert pub[i]=={'prompt_id':pid,'prompt':prompt(ff,ans,arm=='paraphrase')}
            assert pri[i]['prompt_id']==pid and pri[i]['gold']==pack(ans)
            assert pri[i]['input']==pack(ff)
            assert pri[i]['prompt_sha256']==sha(pub[i]['prompt'].encode())
            if arm!='paraphrase':distinct.append(sha(dumps({'kind':ff['kind'],'X':ff['X'],'context':ff['context']}).encode()))
            i+=1
    assert pack(replays)==stored
    assert len(set(distinct))==384
    repo=ROOT/'families_repo';dirs=[p for p in repo.iterdir() if p.is_dir() and p.name!='all_files']
    assert len(dirs)==96
    assert sum(len(list(p.iterdir())) for p in dirs)==288
    assert len(list((repo/'all_files').iterdir()))==288
    result={'status':'PASS','families':96,'prompts':480,'distinct_inputs':384,'certificate_replays':96,'flat_byte_comparisons':288,'source_checks':verify_sources()}
    if check_manifest:result['manifest_entries']=verify_manifest(ROOT)
    return result
if __name__=='__main__':print(json.dumps(verify('--skip-manifest' not in sys.argv),indent=2))
