"""Trusted exact construction engine. Never parse model output with sympify."""
from __future__ import annotations
import itertools, json, math
from functools import lru_cache
import sympy as s
VERSION='3.0.0'
x,y,z,t,h,g=s.symbols('x y z t h g', real=True)
q0,q1,v0,v1,a0,a1,j0,j1,k0,k1=s.symbols('q0 q1 v0 v1 a0 a1 j0 j1 k0 k1', real=True)
JETS=(q0,q1,v0,v1,a0,a1,j0,j1,k0,k1)
SYMS={str(v):v for v in (x,y,z,t,h,g)+JETS}
M=s.Matrix
R=s.Rational

def cl(v):
    if isinstance(v,s.MatrixBase): return v.applyfunc(s.cancel)
    if isinstance(v,dict): return {k:cl(a) for k,a in v.items()}
    if isinstance(v,(list,tuple)): return [cl(a) for a in v]
    return s.cancel(v)
def pack(v):
    if isinstance(v,s.MatrixBase): return [[str(s.cancel(a)) for a in row] for row in v.tolist()]
    if isinstance(v,s.Basic): return str(s.cancel(v))
    if isinstance(v,dict): return {k:pack(a) for k,a in v.items()}
    if isinstance(v,(list,tuple)): return [pack(a) for a in v]
    return v
def dumps(v): return json.dumps(pack(v),indent=2,sort_keys=True)+'\n'
def same(a,b):
    if isinstance(a,dict): return isinstance(b,dict) and a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)): return isinstance(b,(list,tuple)) and len(a)==len(b) and all(same(u,v) for u,v in zip(a,b))
    if isinstance(a,s.MatrixBase): return isinstance(b,s.MatrixBase) and a.shape==b.shape and all(s.cancel(u-v)==0 for u,v in zip(a,b))
    return s.cancel(a-b)==0

def add(a,b):
    if isinstance(a,dict): return {k:add(a[k],b[k]) for k in a}
    if isinstance(a,(list,tuple)): return [add(u,v) for u,v in zip(a,b)]
    return cl(a+b)
def mul(c,a):
    if isinstance(a,dict): return {k:mul(c,v) for k,v in a.items()}
    if isinstance(a,(list,tuple)): return [mul(c,v) for v in a]
    return cl(c*a)
def affine(a,X,b,V): return add(mul(a,X),mul(b,V))
def tr(A): return s.trace(A)
def comm(A,B): return A*B-B*A
def anti(A,B): return A*B+B*A
def J(n):
    m=n//2
    return s.zeros(m).row_join(s.eye(m)).col_join((-s.eye(m)).row_join(s.zeros(m)))
def cp(A): return M(A.charpoly().all_coeffs()[1:])
def pf(A):
    n=A.rows
    if n==0:return s.Integer(1)
    return sum((-1)**(j+1)*A[0,j]*pf(A.extract([k for k in range(n) if k not in (0,j)],[k for k in range(n) if k not in (0,j)])) for j in range(1,n))
def D(f): return s.expand(sum(v*s.diff(f,u) for u,v in zip(JETS[:8],JETS[2:])))
def variation(L):
    rr=M([s.diff(L,a0),s.diff(L,a1)])
    pp=M([s.diff(L,v0),s.diff(L,v1)])-rr.applyfunc(D)
    ee=M([s.diff(L,q0),s.diff(L,q1)])-pp.applyfunc(D)
    return cl({'euler':ee,'momentum':pp,'acceleration_momentum':rr})
def coefficients(f,var,n): return [s.expand(f).coeff(var,i) for i in range(n)]
def trunc(f,var,n): return s.series(f,var,0,n).removeO().expand()
def ric(v,c0,n=5):
    c=[c0]
    for k in range(n):c.append(s.cancel((v[k]-sum(c[i]*c[k-i] for i in range(k+1)))/(k+1)))
    return M(c[1:])
def ric_inverse(c,c0):
    cc=[c0]+list(c)
    return [(k+1)*cc[k+1]+sum(cc[i]*cc[k-i] for i in range(k+1)) for k in range(len(c))]
def dyson(aa,n=4):
    uu=[s.eye(2)]
    for k in range(n):uu.append(cl(sum((aa[i]*uu[k-i] for i in range(k+1)),s.zeros(2))/(k+1)))
    return uu[1:]
def dyson_inverse(uu):
    U=[s.eye(2)]+uu; aa=[]
    for k in range(len(uu)):aa.append(cl((k+1)*U[k+1]-sum((aa[i]*U[k-i] for i in range(k)),s.zeros(2))))
    return aa
def revert(cc):
    # Formal f(t)=t+sum cc[k-2]t^k modulo t^(N+1), unique inverse.
    n=len(cc)+1; out=t
    for k in range(2,n+1):
        fk=out+sum(cc[j-2]*out**j for j in range(2,k+1))
        out-=s.expand(fk).coeff(t,k)*t**k
    return M([s.expand(out).coeff(t,k) for k in range(2,n+1)])
def moments(P):
    return M([sum(co*s.factorial(m[0]+k) for m,co in s.Poly(P,t).terms())/s.factorial(k) for k in range(6)])
def anomaly(fields):
    return M([sum(chi*dim*q1**(3-i)*q2**i*s.binomial(3,i)/6 for chi,dim,q1,q2 in fields) for i in range(4)]+[-sum(chi*dim*row[j] for row in fields for chi,dim in [row[:2]])/24 for j in (2,3)])
def moyal(f,b):
    out=0
    for n in (1,3,5):
        bracket=sum((-1)**k*s.binomial(n,k)*s.diff(f,x,n-k,y,k)*s.diff(b,x,k,y,n-k) for k in range(n+1))
        out+=(-1)**((n-1)//2)*h**(n-1)*bracket/(2**(n-1)*s.factorial(n))
    return s.expand(out)
def hodge(F,eta,orientation):
    inv=eta.inv(); up=inv*F*inv; out=s.zeros(4)
    for i in range(4):
        for j in range(4):out[i,j]=orientation*sum(s.LeviCivita(i,j,k,l)*up[k,l] for k in range(4) for l in range(4))/2
    return out
def partial_trace(rho,which):
    return M(2,2,lambda i,j:sum(rho[2*i+k,2*j+k] if which==0 else rho[2*k+i,2*k+j] for k in range(2)))
def pt(rho):return M(4,4,lambda i,j:rho[2*(i//2)+j%2,2*(j//2)+i%2])
PAULI=[M([[0,1],[1,0]]),M([[0,-s.I],[s.I,0]]),M([[1,0],[0,-1]])]
def dissipator(rho,H,jumps):
    out=-s.I*comm(H,rho)
    for rate,L in jumps:out+=rate*(L*rho*L.H-anti(L.H*L,rho)/2)
    return cl(out)
def bloch(H,jumps):
    A=M(3,3,lambda i,j:tr(PAULI[i]*dissipator(PAULI[j]/2,H,jumps)))
    c=M([tr(PAULI[i]*dissipator(s.eye(2)/2,H,jumps)) for i in range(3)])
    return cl(A),cl(c)
def lyapunov(A,N):
    n=A.rows; vv=s.symbols('u:'+str(n*n)); S=M(n,n,vv)
    mat,rhs=s.linear_eq_to_matrix(list(A*S+S*A.T+N),vv)
    return cl(M(n,n,list(mat.inv()*rhs)))
def narain(G,B):
    Gi=G.inv()
    return cl(Gi.row_join(-Gi*B).col_join((B*Gi).row_join(G-B*Gi*B)))
def narain_decode(H):
    G=H[:2,:2].inv(); B=-G*H[:2,2:]
    return cl(G),cl(B)
def Q(Dd,A,odd):return Dd*A-(-1 if odd else 1)*A*Dd

def solve_state(f):
    k=f['kind']; X=f['X']; c=f['context']
    if k in ('RBG','LAT','GBS','PFQ','KCS','LDB'):return cl(X.inv())
    if k=='DRC':
        C=c['C']; JJ=J(4); JD=JJ-JJ*C.T*(C*JJ*C.T).inv()*C*JJ
        return cl({'bracket':JD,'flow':JD*X})
    if k=='HDV':return variation(X)
    if k=='RIC':return ric(X,c['initial'])
    if k=='DYS':return dyson(X)
    if k=='IMP':return revert(X)
    if k=='DST':return moments(X)
    if k=='RGJ':return s.expand(X*s.diff(X,g)/2)
    if k=='ANM':return anomaly(X)
    if k=='MOY':return moyal(X,c['right_symbol'])
    if k=='CON':return {'gradient':M([s.diff(X,u) for u in (x,y,z)]),'hessian':s.hessian(X,(x,y,z))}
    if k=='ADM':
        Gi=c['metric'].inv(); return cl(X-tr(Gi*X)*c['metric'])
    if k=='HOD':return hodge(X,c['metric'],c['orientation'])
    if k=='YMC':return comm(X[0],X[1])
    if k=='QIN':return cl(X*X.T)
    if k=='OUC':return lyapunov(c['drift'],X)
    if k=='ISM':return M([sum(w*s.prod(spin[i] for i in range(3) if mask>>i&1) for spin,w in zip(c['spins'],X)) for mask in range(8)])
    if k=='NAR':return narain(X['metric'],X['B'])
    if k=='SFT':return Q(c['D'],X,True)+X*X
    raise KeyError(k)

def observe(f,A):
    k=f['kind']; X=f['X']; c=f['context']
    if k in ('RBG','LAT'):return {'response':A*c['source'],'operator_determinant':1/A.det()}
    if k=='GBS':
        K=A.inv(); mode=c['mode']; j=c['source']
        if mode=='marginal':return {'effective_precision':A[:2,:2].inv(),'mean':(A*j)[:2,:],'hidden_determinant':K[2:,2:].det()}
        if mode=='conditional':return {'effective_precision':K[:2,:2],'mean':K[:2,:2].inv()*(j[:2,:]-K[:2,2:]*c['fixed_hidden'])}
        P=c['map']
        if mode=='pushforward':return {'effective_precision':(P*A*P.T).inv(),'mean':P*A*j}
        S=P.T*K*P
        return {'effective_precision':S,'mean':S.inv()*P.T*j,'induced_measure_factor_squared':(P.T*P).det()}
    if k=='PFQ':return {'pfaffian':pf(A.inv()),'partition_squared':1/A.det()}
    if k=='KCS':return {'hall':(c['charge'].T*A*c['charge'])[0],'spin_times_two':(c['anyon'].T*A*c['anyon'])[0],'torus_degeneracy':abs(1/A.det())}
    if k=='DRC':return {'flow_characteristic':cp(A['flow']),'constraint_annihilation':c['C']*A['bracket']}
    if k=='HDV':return {'ostrogradsky_energy':(A['momentum'].T*M([v0,v1]))[0]+(A['acceleration_momentum'].T*M([a0,a1]))[0]-X}
    if k=='RIC':return {'residual_coefficients':M(ric_inverse(A,c['initial']))-M(X)}
    if k=='DYS':return {'determinant_jet':M(coefficients(trunc((s.eye(2)+sum((A[i]*t**(i+1) for i in range(4)),s.zeros(2))).det(),t,5),t,5))}
    if k=='IMP':return {'susceptibility_jet':M([(i+2)*A[i] for i in range(5)])}
    if k=='DST':return {'delta_derivative_coefficients':M([(-1)**i*A[i] for i in range(6)])}
    if k=='RGJ':return {'time_order_three':s.expand(X*s.diff(A,g)/3)}
    if k=='ANM':return {'cubic_at_1_2':sum(A[i]*2**i for i in range(4)),'mixed_at_1_2':A[4]+2*A[5]}
    if k=='MOY':return {'classical':A.subs(h,0),'quantum_at_h1':A.subs(h,1)-A.subs(h,0)}
    if k=='CON':
        eta=c['metric']; inv=eta.inv(); v=A['gradient']; H=A['hessian']; d=3
        ricci=-(d-2)*H-eta*tr(inv*H)+(d-2)*(v*v.T-eta*(v.T*inv*v)[0])
        return {'ricci':ricci,'scalar_times_exp_2phi':tr(inv*ricci)}
    if k=='ADM':
        gam=c['metric']; Gi=gam.inv(); K=A-tr(Gi*A)*gam/2
        return {'hamiltonian_constraint':tr(Gi*K)**2-tr(Gi*K*Gi*K),'momentum_constraint':M([sum(Gi[j,l]*s.diff(A[l,i],(x,y,z)[j]) for j in range(3) for l in range(3)) for i in range(3)])}
    if k=='HOD':
        eta=c['metric']; inv=eta.inv(); sigma=eta.det(); F=sigma*hodge(A,eta,c['orientation']); up=inv*F*inv
        ff=sum(F[i,j]*up[i,j] for i in range(4) for j in range(4)); dual=sum(F[i,j]*(inv*A*inv)[i,j] for i in range(4) for j in range(4))
        return {'F_contraction':ff,'dual_contraction':dual,'stress':F*inv*F.T-eta*ff/4}
    if k=='YMC':return {'covariant_derivative_0':comm(X[0],A),'covariant_derivative_1':comm(X[1],A),'curvature_trace_squared':tr(A*A)}
    if k=='QIN':
        Z=tr(A); red=partial_trace(A,0)
        return {'weight':Z,'purity':tr(A*A)/Z**2,'reduced_purity':tr(red*red)/Z**2,'partial_transpose_determinant':pt(A).det()/Z**4}
    if k=='LDB':
        r=-A*c['forcing'];return {'steady_bloch':r,'purity':(1+(r.T*r)[0])/2,'generator_determinant':1/A.det()}
    if k=='OUC':
        B=c['drift']; N=X; V=B+N*A.inv()/2
        return {'stationary_current':B*A-A*B.T,'entropy_production':tr(V.T*(N/2).inv()*V*A)}
    if k=='ISM':return {'mean_0':A[1]/A[0],'connected_01':A[3]/A[0]-A[1]*A[2]/A[0]**2,'connected_012':A[7]/A[0]-(A[3]*A[4]+A[5]*A[2]+A[6]*A[1])/A[0]**2+2*A[1]*A[2]*A[4]/A[0]**3}
    if k=='NAR':return {'charge_energy':(c['charge'].T*A*c['charge'])[0],'level_pairing':(c['charge'][:2,:].T*c['charge'][2:,:])[0]}
    if k=='SFT':return {'linearized_curvature':Q(c['D'],f['V'],True)+anti(X,f['V']),'bianchi':Q(c['D'],A,False)+comm(X,A)}
    raise KeyError(k)

def solve(f):
    A=cl(solve_state(f)); return {'state':A,'observables':cl(observe(f,A))}

def parameters(k):
    if k=='QIN':return [M([[1,1],[0,1]])/3,s.diag(R(1,2),1)]
    if k=='ISM':return ['field_bias','spin_flip']
    return [(s.Integer(1),s.Integer(1)),(s.Integer(2),s.Integer(0))]

def transform(f,p):
    k=f['kind']; out={**f,'context':dict(f['context'])}; X=f['X'];V=f['V']
    if k=='ISM' and isinstance(p,list):
        for step in p:out=transform(out,step)
        return out
    if k=='QIN':out['X']=s.kronecker_product(p,s.eye(2))*X;return out
    if k=='ISM':
        spins=f['context']['spins']; d={tuple(sp):w for sp,w in zip(spins,X)}
        if p=='field_bias':out['X']=[w*(2 if sp[0]==1 else 1) for sp,w in zip(spins,X)]
        elif p=='field_unbias':out['X']=[w/(2 if sp[0]==1 else 1) for sp,w in zip(spins,X)]
        else:out['X']=[d[(-sp[0],sp[1],sp[2])] for sp in spins]
        return out
    a,b=p
    if k=='ANM':out['X']=[(a*ch,dim,q1,q2) for ch,dim,q1,q2 in X]+[(b*ch,dim,q1,q2) for ch,dim,q1,q2 in V]
    elif k=='NAR':out['X']={'metric':a*X['metric'],'B':a*X['B']+b*V}
    else:out['X']=affine(a,X,b,V)
    if k=='LDB':
        out['context']['forcing']=a*f['context']['forcing']+b*f['context']['driver_forcing']
        out['context']['H']=a*f['context']['H']+b*f['context']['driver_H']
        out['context']['jumps']=[(a*rate,L) for rate,L in f['context']['jumps']]+[(b*rate,L) for rate,L in f['context']['driver_jumps']]
    return out

def inverse(k,p):
    if k=='QIN':return p.inv()
    if k=='ISM' and isinstance(p,list):return [inverse(k,step) for step in reversed(p)]
    if k=='ISM':return {'field_bias':'field_unbias','field_unbias':'field_bias','spin_flip':'spin_flip'}[p]
    a,b=p;return (1/a,-b/a)

def transport_state(f,A,p):
    """Uses submitted state, physical driver and known context; never solve(f)."""
    k=f['kind']; X=f['X']; V=f['V']; c=f['context']
    if k=='ISM' and isinstance(p,list):
        for step in p:A=transport_state(f,A,step)
        return A
    if k=='QIN':P=s.kronecker_product(p,s.eye(2));return P*A*P.T
    if k=='ISM':
        if p=='spin_flip':return M([(-1 if mask&1 else 1)*A[mask] for mask in range(8)])
        alpha,beta=(R(3,2),R(1,2)) if p=='field_bias' else (R(3,4),-R(1,4))
        return M([alpha*A[mask]+beta*A[mask^1] for mask in range(8)])
    a,b=p
    if k in ('RBG','LAT','GBS','PFQ','KCS','LDB'):return (a*s.eye(A.rows)+b*A*V).inv()*A
    if k=='DRC':return {'bracket':A['bracket'],'flow':a*A['flow']+b*A['bracket']*V}
    if k=='HDV':return affine(a,A,b,variation(V))
    if k=='RIC':return ric(affine(a,ric_inverse(A,c['initial']),b,V),c['initial'])
    if k=='DYS':return dyson(affine(a,dyson_inverse(A),b,V))
    if k=='IMP':return revert(affine(a,revert(list(A)),b,V))
    if k=='DST':return a*A+b*moments(V)
    if k=='RGJ':return a*a*A+a*b*(X*s.diff(V,g)+V*s.diff(X,g))/2+b*b*V*s.diff(V,g)/2
    if k=='ANM':return a*A+b*anomaly(V)
    if k=='MOY':return a*A+b*moyal(V,c['right_symbol'])
    if k=='CON':return {'gradient':a*A['gradient']+b*M([s.diff(V,u) for u in (x,y,z)]),'hessian':a*A['hessian']+b*s.hessian(V,(x,y,z))}
    if k=='ADM':return a*A+b*(V-tr(c['metric'].inv()*V)*c['metric'])
    if k=='HOD':return a*A+b*hodge(V,c['metric'],c['orientation'])
    if k=='YMC':return a*a*A+a*b*(comm(X[0],V[1])+comm(V[0],X[1]))+b*b*comm(V[0],V[1])
    if k=='OUC':return a*A+b*s.eye(A.rows)
    if k=='NAR':
        G,B=narain_decode(A);return narain(a*G,a*B+b*V)
    if k=='SFT':return a*A+(a*a-a)*X*X+b*Q(c['D'],V,True)+a*b*anti(X,V)+b*b*V*V
    raise KeyError(k)

def scalar_entries(v):
    if isinstance(v,s.MatrixBase):yield from v
    elif isinstance(v,dict):
        for a in v.values():yield from scalar_entries(a)
    elif isinstance(v,(list,tuple)):
        for a in v:yield from scalar_entries(a)
    else:yield s.sympify(v)  # trusted already-parsed algebraic objects only

def require_transport_domain(f,answer):
    k=f['kind'];A=answer['state']
    allowed={'HDV':set(JETS),'CON':{x,y,z},'ADM':{x,y,z},'MOY':{x,y,h},'RGJ':{g}}.get(k,set())
    if any(not v.free_symbols<=allowed for v in scalar_entries(answer)):
        raise ValueError('Answer outside the declared symbol domain')
    if not allowed and any(not v.is_Rational for v in scalar_entries(answer)):
        raise ValueError('Rational answer domain required')
    if k=='QIN':
        if not same(A,A.T) or tr(A)<=0:raise ValueError('Invalid positive-state domain')
        for n in range(1,5):
            for ix in itertools.combinations(range(4),n):
                if A.extract(ix,ix).det()<0:raise ValueError('State is not positive semidefinite')
    if k=='NAR':
        G,B=narain_decode(A)
        if not same(B,-B.T) or not same(G,G.T) or not same(narain(G,B),A):
            raise ValueError('State is not a generalized metric')
        if any(G[:i,:i].det()<=0 for i in range(1,3)):raise ValueError('Target metric is not positive')

def transport(f,answer,p):
    require_transport_domain(f,answer)
    old=answer['state']; new=cl(transport_state(f,old,p)); ff=transform(f,p)
    # The defect lift is an explicit extension to wrong answers, not gold repair.
    defect=add(answer['observables'],mul(-1,observe(f,old)))
    return {'state':new,'observables':cl(add(observe(ff,new),defect))}

KINDS=('RBG','GBS','PFQ','DRC','HDV','RIC','DYS','IMP','DST','RGJ','ANM','MOY','CON','ADM','HOD','KCS','LAT','YMC','QIN','LDB','OUC','ISM','NAR','SFT')

def fixture(kind,r):
    """r=0..3 selects a structural regime, not a random seed."""
    c={}; X=V=None
    if kind in ('RBG','LAT'):
        X=M([[3,-1,0,0],[-1,3,-1,0],[0,-1,3,-1],[0,0,-1,3]])
        if r==1:X[0,0]=2;X[3,3]=4
        if r==2:X[0,3]=X[3,0]=-1
        if r==3:X[0,3]=X[3,0]=1
        if kind=='RBG':V=s.diag(1,0,0,2)
        else:V=M([1,0,-1,1])*M([[1,0,-1,1]])
        c={'source':M([1,-2,3,1])}
        if kind=='RBG':
            X=M([[3,-1,0,0],[-1,3,-1,0],[0,-1,3,-1],[0,0,-1,3]])
            if r==1:X[0,0]=2;X[3,3]=4
            if r==2:X[0,3]=X[3,0]=R(1,2);X[0,0]=4
            if r==3:X[0,3]=X[3,0]=-R(1,2);X[3,3]=5
        else:
            X=X+s.diag(0,1,2,0);c['source']=M([2,1,-1,3])
    if kind=='GBS':
        B=[M([[2,1,0,1],[0,2,1,0],[1,0,2,1],[0,1,0,2]]),M([[2,1,1,0],[0,1,2,0],[1,0,2,1],[1,1,0,2]]),M([[2,0,1,1],[1,2,0,1],[0,1,3,0],[1,0,1,2]]),M([[3,1,0,0],[1,2,1,0],[0,1,2,1],[0,0,1,2]])][r]
        X=B.T*B+s.eye(4); V=M([1,1,0,-1])*M([[1,1,0,-1]]); c={'source':M([1,2,-1,3]),'mode':['marginal','conditional','pushforward','restriction'][r]}
        if r==1:c['fixed_hidden']=M([1,-1])
        if r==2:c['map']=M([[1,0,1,0],[0,1,1,-1]])
        if r==3:c['map']=M([[1,0],[0,1],[1,1],[1,-1]])
    if kind=='PFQ':
        B=s.eye(6); B[0,2]=1;B[1,4]=-1;B[3,5]=r+1
        E=s.diag(1,2,3); X=B*(s.zeros(3).row_join(E).col_join((-E).row_join(s.zeros(3))))*B.T
        if r==1:X[0,1]+=2;X[1,0]-=2
        if r==2:X[0,5]+=1;X[5,0]-=1
        if r==3:X=-X
        V=J(6)
    if kind=='DRC':
        C=[M([[1,0,0,0],[0,0,1,0]]),M([[1,1,0,0],[0,0,1,2]]),M([[1,0,0,1],[0,1,1,0]]),M([[1,1,1,0],[0,1,0,2]])][r]
        if (C*J(4)*C.T).det()==0:C[1,2]+=1
        B=M([[2,1,0,1],[0,2,1,0],[1,0,2,1],[0,1,0,2]])
        X=B.T*B+s.eye(4);V=s.diag(1,2,3,4);c={'C':C}
    if kind=='HDV':
        X=[(a0*a0+2*a0*a1+3*a1*a1)/2+q0*q1*v0+v0*v1-q0**4/4-q1**4/3,
           (a0+a1)**2/2+(q0*v1-q1*v0)*a0+v0**2/2-q0*q1**3,
           (1+q0*q1)*a0*a1+v0**2*v1-q0**2*q1**2,
           (a0**2+2*a1**2)/2+D(q0*v1**2+q1*v0)-q0**3*q1][r]
        V=q0*q1*a0+q1*v0*v1+q0**2*q1**2
    if kind=='RIC':
        X=[[2,1,0,3,1],[1,0,-2,0,3],[0,2,1,-1,2],[-1,3,-2,1,0]][r];X=list(map(s.Integer,X)); V=list(map(s.Integer,[1,-1,2,0,1]));c={'initial':[R(1,2),1,-1,R(2,3)][r]}
    if kind=='DYS':
        A=M([[0,1],[-2,1]]);B=M([[1,1],[0,-1]]); C=M([[0,2],[1,0]])
        X=[[A,B,C,s.zeros(2)],[A,s.zeros(2),B,C],[B,A,-B,C],[A,B,comm(A,B),C]][r]
        V=[C,A,s.zeros(2),B]
    if kind=='IMP':
        X=[M([1,2,0,1,-1]),M([0,2,0,1,0]),M([-1,0,2,-1,1]),M([2,-1,1,0,2])][r]
        V=M([1,1,-1,2,0])
    if kind=='DST':
        X=[1+t+t**2/2,1-t,(t**2-4*t+2),t**3-3*t**2+t-1][r];V=1+2*t+t**3/6
    if kind=='RGJ':
        X=[-g+g**2-g**3/2,g**2-g**3,2*g-3*g**3,-g+2*g**2+g**3][r];V=g+g**3/3
    if kind=='ANM':
        X=[[(1,1,1,2),(1,1,2,-1),(-1,1,1,0)],[(1,2,1,1),(-1,2,-1,1),(1,1,2,0)],[(1,1,1,0),(-1,1,1,0),(1,3,1,-2)],[(1,3,2,1),(-1,2,1,2),(-1,1,-2,1)]][r]
        X=[tuple(map(s.Integer,row)) for row in X];V=[tuple(map(s.Integer,(1,1,1,2)))]
    if kind=='MOY':
        X=[x**3*y**2+x*y**3,x**4+y**4+x*x*y*y,x**5+y**5+x*y,x*x*y**3+x**3*y][r]
        V=x**3*y**2+2*x*y**3+x*x; c={'right_symbol':x**2*y**3+x**3-y**4}
    if kind=='CON':
        X=[x*x+x*y+y*z,x*x-y*y+z*z+x*z,x*y*z+x*x,x**3+y*y+z*x][r]
        V=x*y+z*z+x; c={'metric':s.diag(-1,1,1) if r in (1,3) else s.eye(3)}
    if kind=='ADM':
        X=[M([[x+y,x*z,0],[x*z,z+y,y],[0,y,x*z]]),M([[x*x,0,y],[0,z*z,x],[y,x,y*y]]),M([[x,y,z],[y,x+y,x*z],[z,x*z,z*z]]),M([[x*y,z,x],[z,y*z,y],[x,y,z*x]])][r]
        V=M([[1+x,y,0],[y,1+z,x],[0,x,2+y]]);c={'metric':[s.eye(3),s.diag(1,2,3),M([[2,1,0],[1,2,0],[0,0,1]]),s.diag(2,3,1)][r]}
    if kind=='HOD':
        X=M([[0,1,2,3],[-1,0,2,-1],[-2,-2,0,1],[-3,1,-1,0]])
        if r==1:X[0,1]=0;X[1,0]=0
        if r==2:X[2,3]=2;X[3,2]=-2
        if r==3:X[0,2]=-2;X[2,0]=2
        V=M([[0,2,0,1],[-2,0,1,0],[0,-1,0,2],[-1,0,-2,0]])
        c={'metric':s.diag(-1,1,1,1) if r<2 else s.eye(4),'orientation':1 if r%2==0 else -1}
    if kind=='KCS':
        X=[M([[4,1],[1,2]]),M([[3,1],[1,5]]),M([[2,1],[1,-4]]),M([[3,2],[2,-3]])][r];V=s.diag(2,4)
        c={'charge':M([1,2]),'anyon':M([2,-1])}
    if kind=='YMC':
        A=M([[1,1],[0,-1]]); B=M([[0,1],[-1,0]]); C=M([[0,2],[1,0]])
        X=[[A,B],[A+C,B],[A,B+C],[C,A+B]][r];V=[B+C,A-C]
    if kind=='QIN':
        X=[M([[1,0,1],[0,1,0],[1,1,0],[0,1,2]]),M([[1,1,0],[0,0,1],[0,1,1],[2,0,1]]),M([[1,0],[1,1],[0,1],[1,-1]]),M([[1],[1],[0],[2]])][r]/4;V=None
    if kind=='LDB':
        H=[PAULI[0]+PAULI[2]/2,PAULI[1]/2+PAULI[2],PAULI[0]-PAULI[1]/2,PAULI[0]+PAULI[1]+PAULI[2]][r]
        down=M([[0,1],[0,0]]); up=down.T
        jumps=[(s.Integer(2),down),(s.Integer(1 if r!=2 else 3),up),(R(1,2) if r!=1 else R(3,2),PAULI[2])]
        X,force=bloch(H,jumps);V,df=bloch(PAULI[2]/2,[(s.Integer(1),down),(s.Integer(1),PAULI[0])]);c={'forcing':force,'driver_forcing':df,'H':H,'jumps':jumps,'driver_H':PAULI[2]/2,'driver_jumps':[(s.Integer(1),down),(s.Integer(1),PAULI[0])]}
    if kind=='OUC':
        A=[M([[-3,1,0],[-1,-2,1],[0,-1,-4]]),M([[-3,1,1],[0,-3,1],[0,0,-3]]),M([[-4,2,0],[-1,-4,1],[0,-2,-3]]),M([[-3,1,-1],[-1,-4,1],[1,-1,-3]])][r]
        B=M([[2,1,0],[0,2,1],[1,0,2]]);X=B*B.T+s.eye(3);V=-(A+A.T);c={'drift':A}
    if kind=='ISM':
        spins=list(itertools.product((-1,1),repeat=3));edges=[[(0,1,2),(1,2,3)],[(0,1,2),(1,2,3),(2,0,5)],[(0,1,2),(1,2,3),(2,0,R(1,5))],[(0,1,R(1,2)),(1,2,R(1,3)),(2,0,R(1,5))]][r]
        X=[s.prod(weight if sp[i]==sp[j] else 1 for i,j,weight in edges)*s.prod(s.Integer(i+2) if sp[i]==1 else 1 for i in range(3)) for sp in spins];V=None;c={'spins':spins,'edges':edges}
    if kind=='NAR':
        G=[s.diag(2,3),M([[2,1],[1,3]]),M([[3,-1],[-1,2]]),s.diag(R(3,2),R(5,2))][r]
        B=M([[0,[0,R(1,3),-R(1,2),R(2,3)][r]],[-[0,R(1,3),-R(1,2),R(2,3)][r],0]])
        X={'metric':G,'B':B};V=M([[0,R(1,2)],[-R(1,2),0]]);c={'charge':M([1,2,-1,1])}
    if kind=='SFT':
        Z=s.zeros(2);B=[s.eye(2),M([[1,1],[0,1]]),M([[0,1],[-1,0]]),M([[2,1],[1,1]])][r];C=[M([[1,0],[0,2]]),M([[1,0],[1,2]]),M([[1,1],[0,1]]),M([[0,1],[2,0]])][r]
        X=Z.row_join(B).col_join(C.row_join(Z)); V=Z.row_join(M([[1,1],[0,2]])).col_join(M([[0,1],[1,1]]).row_join(Z));c={'D':Z.row_join(s.eye(2)).col_join(Z.row_join(Z))}
    assert X is not None,kind
    return {'id':f'IMR-S3-{kind}-{r+1:02d}','kind':kind,'regime':r,'X':X,'V':V,'context':c,'confirmatory_eligible':False}

@lru_cache(None)
def families():return tuple(fixture(k,r) for k in KINDS for r in range(4))

def compose(kind,p1,p2):
    """T1 first, T2 second. ISM uses a word; others have a closed parameter law."""
    if kind=='QIN':return p2*p1
    if kind=='ISM':return [p1,p2]
    a1,b1=p1;a2,b2=p2;return (a2*a1,a2*b1+b2)
