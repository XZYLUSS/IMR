# Calibration and admission

This package has **no new empirical model evaluation**. All `confirmatory_eligible` flags are false. The earlier 720-session study belongs to the original/v2 comparison, not this expansion. In that study Sol retained 94/96 hard canonical answers; therefore arithmetic growth alone was not sufficient. This motivated broader semantic coverage, but is not evidence of v3 performance.

## What is measured

There are 96 canonical instances in 24 named construction clusters, four data configurations per cluster. Each has five presentations, of which four specify different mathematical inputs. A paraphrase repeats canonical content. Some clusters share algorithms, especially the inverse-response group RBG/GBS/PFQ/KCS/LAT/LDB. Neither 96 nor 24 should automatically be used as a count of independent draws.

Canonical accuracy, changed-problem accuracy, paraphrase agreement and transport consistency are distinct. The three counterfactual arms are not meaning-preserving paraphrases. A copied canonical answer should fail them. Report consistency conditional on complete pairs together with missing-pair counts; never silently fill missing states from gold.

The answer transports are defined on algebraic domains. A singular submitted inverse state can prevent transport evaluation even when its entries parse. Mark that pair undefined; this is not evidence of consistency. Redundant fields use the documented defect-preserving extension, whose consistency score is a design choice, not a unique physical law on wrong answers.

## Prospective evaluation

1. Freeze protocol, prompt hashes, grader, recovery rules and independent mathematical review before evaluation. Keep entire construction and shared-mechanism groups held out during further design; splitting presentations or numeric configurations alone is not an untouched construction holdout.
2. Match requested model version, reasoning settings, tool access, response budget, sampling controls and execution environment across old and new banks. Record unavailable provider controls. Prior authorization for a completed calibration is not a new measurement result.
3. Use fresh isolated sessions, one public prompt per session, with no filesystem access to evaluator material. Randomize presentation order and record requests, responses, token counts, completion status and hashes.
4. Score canonical full answers separately from per-field outcomes and changed arms. Preserve native parser results. Predefine bounded equivalent-notation recovery and keep unresolved outcomes as intervals, not automatic failures or successes.
5. Report a ceiling, a floor and a minimum desired accuracy drop prospectively; examine both model-specific ceilings and local floors. Do not optimize these thresholds after seeing results. A higher error rate caused by longer answers is not by itself deeper conceptual difficulty.
6. Require independent proof review for proof-level claims. The current model-facing contract asks for exact typed outputs, while the accompanying mathematical proofs and certificates belong to the evaluator. Correct final answers do not certify a model's derivation.

## Selection rationale and limits

The selection is based on explicit mathematical sensitivity: noncommutativity; signs from chirality, orientation and grading; incompatible measure operations; boundary versus bulk data; initial branches; nonlinear inversion; fixed-label moduli; closure sectors; and stationary currents. The bank deliberately avoids unverifiable answers to open research problems. That decision makes rigorous golds possible but does not justify calling every finite problem exceptionally hard.

Four-family clusters include both semantic regime changes and different coupling/state configurations within a common regime. They are explicitly labelled in the catalogue rather than represented as independent theories. Additional difficult areas—multiloop scattering, full BRST cohomology, analytic continuation/Stokes phenomena, infinite-dimensional determinant anomalies, nonperturbative dualities, global PDE existence and higher homotopy string products—are not certified by this package.
