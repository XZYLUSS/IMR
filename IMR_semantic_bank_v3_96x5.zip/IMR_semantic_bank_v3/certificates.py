"""Exact defining-equation checks. Shared SymPy is not an independent proof assistant."""
from core import *
import copy

def zero(a):return same(a,mul(0,a))
def spd(A):return same(A,A.T) and all(A[:i,:i].det()>0 for i in range(1,A.rows+1))
def psd(A):
    return same(A,A.T) and all(A.extract(ix,ix).det()>=0 for n in range(1,A.rows+1) for ix in itertools.combinations(range(A.rows),n))

def defining_checks(f,answer):
    k=f['kind'];X=f['X'];c=f['context'];A=answer['state'];O=answer['observables'];checks={}
    def ck(name,condition):checks[name]=bool(condition)
    ck('observable_definitions',same(O,cl(observe(f,A))))
    if k in ('RBG','LAT','GBS','PFQ','KCS','LDB'):
        ck('inverse_right',same(X*A,s.eye(X.rows)));ck('inverse_left',same(A*X,s.eye(X.rows)))
        ck('nondegenerate',X.det()!=0)
    if k in ('RBG','LAT','GBS'):ck('positive_quadratic_form',spd(X))
    if k=='GBS':
        if c['mode']=='marginal':
            S=O['effective_precision'];B=X[:2,2:];H=X[2:,2:]
            ck('block_square_completion',same(X[:2,:2],S+B*H.inv()*B.T));ck('schur_determinant',s.cancel(X.det()-H.det()*S.det())==0)
        if c['mode']=='conditional':ck('conditional_stationarity',zero(X[:2,:2]*O['mean']+X[:2,2:]*c['fixed_hidden']-c['source'][:2,:]))
        if c['mode']=='pushforward':ck('observed_covariance',same(O['effective_precision']*c['map']*A*c['map'].T,s.eye(2)))
        if c['mode']=='restriction':ck('restricted_stationarity',zero(c['map'].T*(X*c['map']*O['mean']-c['source'])))
    if k=='PFQ':
        ck('antisymmetry',same(X,-X.T));ck('pfaffian_determinant',s.cancel(O['pfaffian']**2-X.det())==0)
        # Exterior-algebra multiplication, independent of recursive Pfaffian.
        e={0:s.Integer(1)}; quadratic={ (1<<i)|(1<<j):X[i,j] for i in range(6) for j in range(i+1,6)}
        def wedge(a,b):
            d={}
            for ma,va in a.items():
                for mb,vb in b.items():
                    if ma&mb:continue
                    swaps=sum(1 for i in range(6) for j in range(6) if (ma>>i)&1 and (mb>>j)&1 and i>j)
                    d[ma|mb]=d.get(ma|mb,0)+(-1)**swaps*va*vb
            return d
        for _ in range(3):e=wedge(e,quadratic)
        ck('oriented_grassmann_coefficient',e.get(63,0)/6==O['pfaffian'])
    if k=='DRC':
        B=A['bracket'];C=c['C'];JJ=J(4)
        ck('second_class',(C*JJ*C.T).det()!=0);ck('constraints_casimirs',zero(C*B));ck('bracket_skew',same(B,-B.T))
        ck('correction_constraint_range',(JJ*C.T).row_join(B-JJ).rank()==C.rows)
        ck('hamiltonian_vector_field',same(A['flow'],B*X))
    if k=='HDV':
        dq,dv,da=s.symbols('dq0:2'),s.symbols('dv0:2'),s.symbols('da0:2')
        boundary=(A['momentum'].T*M(dq))[0]+(A['acceleration_momentum'].T*M(dv))[0]
        db=D(boundary)+sum(s.diff(boundary,u)*v for u,v in zip(dq+dv,dv+da))
        direct=sum(s.diff(X,u)*v for u,v in zip((q0,q1,v0,v1,a0,a1),dq+dv+da))
        ck('off_shell_variation',zero(direct-(A['euler'].T*M(dq))[0]-db))
        ck('energy_balance',zero(D(O['ostrogradsky_energy'])+(A['euler'].T*M([v0,v1]))[0]))
    if k=='RIC':
        u=c['initial']+sum(A[i]*t**(i+1) for i in range(5));pot=sum(X[i]*t**i for i in range(5))
        ck('riccati_residual',all(s.expand(s.diff(u,t)+u*u-pot).coeff(t,i)==0 for i in range(5)))
    if k=='DYS':
        U=s.eye(2)+sum((A[i]*t**(i+1) for i in range(4)),s.zeros(2));gen=sum((X[i]*t**i for i in range(4)),s.zeros(2))
        res=s.diff(U,t)-gen*U
        ck('ordered_evolution',all(s.expand(e).coeff(t,i)==0 for e in res for i in range(4)))
        delta=U.det().expand(); log_derivative=s.diff(delta,t)-tr(gen)*delta
        ck('liouville_determinant',all(s.expand(log_derivative).coeff(t,i)==0 for i in range(4)))
    if k=='IMP':
        inv=t+sum(A[i]*t**(i+2) for i in range(5));phi=inv+sum(X[i]*inv**(i+2) for i in range(5))
        ck('inverse_equation',all(s.expand(phi-t).coeff(t,i)==0 for i in range(7)))
        ck('noncritical_branch_derivative',True) # phi'(0)=1 by input contract.
    if k=='DST':
        for k1 in range(6):
            P=s.Poly(X*t**k1,t); ant=0
            for (degree,),co in P.terms():ant-=co*sum(s.factorial(degree)/s.factorial(jj)*t**jj for jj in range(degree+1))
            ck('moment_'+str(k1),zero(s.diff(ant,t)-ant-P.as_expr()) and s.cancel(-ant.subs(t,0)/s.factorial(k1)-A[k1])==0)
        bound=sum(abs(co)*s.factorial(m[0]+6) for m,co in s.Poly(X,t).terms())/s.factorial(6)
        ck('finite_taylor_remainder_bound',bound.is_Rational and bound>=0)
    if k=='RGJ':
        ans=g+X*t+A*t*t+O['time_order_three']*t**3
        res=s.diff(ans,t)-X.subs(g,ans)
        ck('autonomous_flow',all(s.expand(res).coeff(t,i)==0 for i in range(3)))
    if k=='ANM':
        u,v,p=s.symbols('u v p'); poly=0
        for chi,dim,qq,rr in X:poly+=chi*dim*((qq*u+rr*v)**3/6-p*(qq*u+rr*v)/24)
        assembled=sum(A[i]*u**(3-i)*v**i for i in range(4))+p*(A[4]*u+A[5]*v)
        ck('characteristic_class_degree_six',zero(poly-assembled));ck('integral_multiplicities',all(all(a.is_Integer for a in row) for row in X))
    if k=='MOY':
        # Bidifferential product computed separately before antisymmetrization.
        def star(f,b):
            return sum((s.I*h/2)**n/s.factorial(n)*sum((-1)**j*s.binomial(n,j)*s.diff(f,x,n-j,y,j)*s.diff(b,x,j,y,n-j) for j in range(n+1)) for n in range(6))
        ck('ordered_star_commutator',zero((star(X,c['right_symbol'])-star(c['right_symbol'],X))/(s.I*h)-A))
    if k=='CON':
        coords=(x,y,z);eta=c['metric'];ei=eta.inv();vv=M([s.diff(X,u) for u in coords]);H=s.hessian(X,coords)
        ck('conformal_jets',same(A,{'gradient':vv,'hessian':H}))
        G=[[[sum((int(i==j)*int(l==k1)+int(i==k1)*int(l==j)-eta[j,k1]*ei[i,l])*vv[l] for l in range(3)) for k1 in range(3)] for j in range(3)] for i in range(3)]
        Ric=M(3,3,lambda j,k1:sum(s.diff(G[i][j][k1],coords[i])-s.diff(G[i][j][i],coords[k1])+sum(G[i][i][l]*G[l][j][k1]-G[i][k1][l]*G[l][j][i] for l in range(3)) for i in range(3)))
        ck('connection_definition_of_ricci',same(cl(Ric),O['ricci']))
    if k=='ADM':
        gam=c['metric'];gi=gam.inv();K=gi*X
        ck('trace_reversal',same(A,X-tr(K)*gam))
        wedge=sum(K[i,i]*K[j,j]-K[i,j]*K[j,i] for i in range(3) for j in range(3) if i!=j)
        ck('gauss_pair_contraction',zero(wedge-O['hamiltonian_constraint']))
    if k=='HOD':
        eta=c['metric'];ei=eta.inv();sg=eta.det()
        ck('dual_definition',same(A,hodge(X,eta,c['orientation'])))
        ck('double_dual_signature',same(hodge(A,eta,c['orientation']),sg*X))
        ck('stress_traceless',zero(tr(ei*O['stress'])));ck('stress_symmetric',same(O['stress'],O['stress'].T))
    if k=='KCS':
        ck('integral_symmetric_level',same(X,X.T) and all(v.is_Integer for v in X));ck('finite_torus_sectors',O['torus_degeneracy'].is_Integer and O['torus_degeneracy']>0)
    if k=='YMC':
        ck('connection_traceless',all(tr(m)==0 for m in X));ck('ordered_curvature',same(A,X[0]*X[1]-X[1]*X[0]));ck('curvature_traceless',tr(A)==0)
    if k=='QIN':
        ck('incoherent_preparation',same(A,M(4,4,lambda i,j:sum(X[i,k1]*X[j,k1] for k1 in range(X.cols)))))
        ck('positive_state',psd(A));ck('positive_weight',tr(A)>0);ck('purity_range',0<O['purity']<=1)
    if k=='LDB':
        AA,cc=bloch(c['H'],c['jumps']);ck('master_equation_bloch',same(AA,X) and same(cc,c['forcing']))
        rr=O['steady_bloch'];rho=(s.eye(2)+sum((rr[i]*PAULI[i] for i in range(3)),s.zeros(2)))/2
        ck('density_stationarity',zero(dissipator(rho,c['H'],c['jumps'])));ck('physical_bloch_ball',(rr.T*rr)[0]<=1)
    if k=='OUC':
        B=c['drift'];ck('strict_drift_dissipation',spd(-(B+B.T)));ck('positive_noise',spd(X));ck('positive_covariance',spd(A));ck('stationary_lyapunov',zero(B*A+A*B.T+X));ck('nonnegative_entropy_production',O['entropy_production']>=0)
    if k=='ISM':
        reconstructed=M([sum(A[mask]*s.prod(sp[i] for i in range(3) if mask>>i&1) for mask in range(8))/8 for sp in c['spins']])
        ck('inverse_walsh_recovers_weights',same(reconstructed,M(X)));ck('positive_weights',all(w>0 for w in X))
    if k=='NAR':
        eta=s.zeros(2).row_join(s.eye(2)).col_join(s.eye(2).row_join(s.zeros(2)))
        ck('positive_target_metric',spd(X['metric']));ck('antisymmetric_B',same(X['B'],-X['B'].T));ck('generalized_metric_identity',same(A*eta*A,eta));ck('positive_generalized_metric',spd(A))
        n=c['charge'][:2,:];w=c['charge'][2:,:];u=n-X['B']*w
        ck('independent_charge_energy',zero(O['charge_energy']-(u.T*X['metric'].inv()*u+w.T*X['metric']*w)[0]))
        ck('inverse_metric_block',same(A[:2,:2]*X['metric'],s.eye(2)));ck('B_block',same(X['metric']*A[:2,2:],-X['B']))
    if k=='SFT':
        DD=c['D'];P=s.diag(1,1,-1,-1)
        ck('nilpotent_differential',zero(DD*DD));ck('odd_input',same(P*X*P,-X));ck('curvature_definition',same(A,DD*X+X*DD+X*X));ck('even_curvature',same(P*A*P,A));ck('off_shell_bianchi',zero(O['bianchi']))
    return checks

def flat(v,path=''):
    if isinstance(v,dict):
        for k,a in v.items():yield from flat(a,path+'/'+k)
    elif isinstance(v,s.MatrixBase):
        for i in range(v.rows):
            for j in range(v.cols):yield path+f'/{i}/{j}',v[i,j]
    elif isinstance(v,(list,tuple)):
        for i,a in enumerate(v):yield from flat(a,path+f'/{i}')
    else:yield path,v

def difference(a,b):
    aa=dict(flat({'observables':a['observables'],'state':a['state']}));bb=dict(flat({'observables':b['observables'],'state':b['state']}))
    for p,v in aa.items():
        d=s.cancel(bb[p]-v)
        if d!=0:return {'path':p,'before':str(v),'after':str(bb[p]),'difference':str(d)}
    return None

def wrong_answer(f,a):
    b=copy.deepcopy(a);k=f['kind'];A=b['state'];O=b['observables'];X=f['X'];c=f['context'];label=''
    if k in ('RBG','LAT'):b['state']=s.diag(*[1/X[i,i] for i in range(X.rows)]);label='drop off-diagonal couplings'
    elif k=='GBS':O['effective_precision']=X[:2,:2] if c['mode']!='conditional' else (X.inv()[:2,:2]).inv();label='confuse integration with conditioning'
    elif k=='PFQ':O['pfaffian']=-O['pfaffian'];label='reverse Grassmann sign'
    elif k=='DRC':A['bracket']=J(4);label='use unreduced Poisson tensor'
    elif k=='HDV':A['momentum']=M([s.diff(X,v0),s.diff(X,v1)]);label='omit derivative of acceleration momentum'
    elif k=='RIC':b['state']=M([X[i]/(i+1) for i in range(5)]);label='omit nonlinear Riccati square'
    elif k=='DYS':
        Z=sum((X[i]*t**(i+1)/(i+1) for i in range(4)),s.zeros(2));U=sum((Z**i/s.factorial(i) for i in range(5)),s.zeros(2))
        b['state']=[U.applyfunc(lambda v:s.expand(v).coeff(t,i)) for i in range(1,5)];label='commute the time-ordered generator'
    elif k=='IMP':b['state']=-X;label='use only first inverse iteration'
    elif k=='DST':O['delta_derivative_coefficients']=M(A);label='omit distributional derivative sign'
    elif k=='RGJ':b['state']=X*X/2;label='omit beta derivative in time jet'
    elif k=='ANM':b['state']=anomaly([(abs(ch),dim,qq,rr) for ch,dim,qq,rr in X]);label='erase chirality signs'
    elif k=='MOY':b['state']=A.subs(h,0);label='replace star commutator by Poisson bracket'
    elif k=='CON':O['ricci']=-A['hessian']-c['metric']*tr(c['metric'].inv()*A['hessian']);label='drop quadratic conformal-gradient terms'
    elif k=='ADM':O['hamiltonian_constraint']=-O['hamiltonian_constraint'];label='reverse Gauss-constraint sign'
    elif k=='HOD':b['state']=-A;label='reverse orientation without changing data'
    elif k=='KCS':O['spin_times_two']=(c['anyon'].T*X*c['anyon'])[0];label='use K instead of inverse level'
    elif k=='YMC':b['state']=s.zeros(2);label='treat constant connection as flat'
    elif k=='QIN':O['purity']=tr(A*A);label='omit selective-state normalization'
    elif k=='LDB':O['steady_bloch']=-O['steady_bloch'];label='wrong affine forcing sign'
    elif k=='OUC':b['state']=-c['drift'].inv()*X/2;label='replace Lyapunov equation by commuting approximation'
    elif k=='ISM':O['connected_01']=A[3]/A[0];label='use raw instead of connected correlation'
    elif k=='NAR':b['state'][:2,:2]=X['metric'];label='use target metric instead of inverse in momentum sector'
    elif k=='SFT':b['state']=Q(c['D'],X,True);label='omit odd field square'
    return b,label

def certify(f):
    p1,p2=parameters(f['kind']);f1=transform(f,p1);f2=transform(f,p2);fc=transform(f1,p2);fr=transform(f2,p1)
    states=[f,f1,f2,fc];answers=[solve(v) for v in states];base=answers[0]
    result={'family_id':f['id'],'defining_equations':{},'semantic_witnesses':{},'negative_controls':{}}
    for arm,ff,aa in zip(('canonical','T1','T2','T2_after_T1'),states,answers):
        ch=defining_checks(ff,aa)
        if not all(ch.values()):raise AssertionError((f['id'],arm,[k for k,v in ch.items() if not v]))
        result['defining_equations'][arm]=ch
    for arm,ff,aa,p in zip(('T1','T2'),states[1:3],answers[1:3],(p1,p2)):
        assert same(transport(f,base,p),aa)
        assert same(transport(ff,aa,inverse(f['kind'],p)),base)
        w=difference(base,aa);assert w is not None
        result['semantic_witnesses'][arm]=w
    compound=transport(f1,transport(f,base,p1),p2)
    assert same(compound,answers[3]);assert same(transport(f1,transport(fc,compound,inverse(f['kind'],p2)),inverse(f['kind'],p1)),base)
    result['semantic_witnesses']['T2_after_T1']=difference(base,answers[3]);assert result['semantic_witnesses']['T2_after_T1']
    reverse=solve(fr);reverse_checks=defining_checks(fr,reverse);assert all(reverse_checks.values());result['reversed_control_defining_equations']=reverse_checks;assert not same(reverse,answers[3]);result['negative_controls']['reversed_order']=difference(reverse,answers[3])
    bad,label=wrong_answer(f,base);assert not same(bad,base),(f['id'],label)
    assert not all(defining_checks(f,bad).values()),(f['id'],'bad certificate accepted')
    result['negative_controls']['semantic_error']={'rule':label,'witness':difference(base,bad)}
    result['negative_controls']['copied_canonical_rejected']=3
    # A wrong observable defect must survive transport and round trips.
    wrong=copy.deepcopy(base);first=next(iter(wrong['observables']));wrong['observables'][first]=add(wrong['observables'][first],mul(0,wrong['observables'][first]))
    def bump(v):
        if isinstance(v,s.MatrixBase):vv=M(v);vv[0,0]+=1;return vv
        return v+1
    wrong['observables'][first]=bump(wrong['observables'][first])
    moved=transport(f,wrong,p1)
    assert not same(moved,answers[1]);assert same(transport(f1,moved,inverse(f['kind'],p1)),wrong)
    result['wrong_answer_defect_preserved']=True
    return result
