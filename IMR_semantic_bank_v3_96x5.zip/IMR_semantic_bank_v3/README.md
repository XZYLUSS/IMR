# IMR semantic-deformation bank v3

**96 named families × 5 presentations = 480 problems**, organized into **24 construction clusters**, with 384 distinct mathematical inputs. This is a separate expansion; the original bank, hard v2, and completed calibration are preserved.

The five slots are canonical, T1, T2, T2-after-T1, and paraphrase. Canonical and paraphrase have identical mathematical content. **T1 and T2 deliberately change physical or mathematical data at fixed conventions.** They are counterfactual problems with certified answer transports, not claims that all five slots describe the same physical system.

The bank covers constrained mechanics, boundary response, fermionic and bosonic measures, singular limits, ordered evolution, renormalization flow, anomalies, deformation quantization, gravity, Hodge theory, topological phases, lattice and gauge theory, quantum information, open systems, stochastic physics, spin ensembles, torus compactification and graded string-field algebra. Every problem states its conventions and finite or formal scope.

## Start here

- [CATALOGUE.md](CATALOGUE.md): all 96 carefully named families, domains and answer sizes.
- [DESIGN_AND_PROOFS.md](DESIGN_AND_PROOFS.md): domains, uniqueness, transports, inverse/composition laws, physical meaning and certificate limitations.
- [REFERENCES.md](REFERENCES.md): checked real sources and their role.
- [CALIBRATION_PLAN.md](CALIBRATION_PLAN.md): admission status, measurement protocol and dependence cautions.
- [STRUCTURAL_AUDIT.json](STRUCTURAL_AUDIT.json), [CERTIFICATE_RESULTS.json](CERTIFICATE_RESULTS.json), [TEST_RESULTS.txt](TEST_RESULTS.txt), [VALIDATION.json](VALIDATION.json): executed evidence.

**Hardness is not yet empirically established.** The selection targets known semantic fault lines; it does not prove these are the hardest problems in physics or that saturation is reduced. Several exact finite tasks may remain easy for strong models. The 24 clusters share some algebraic mechanisms, and the 96 families are not 96 independent research constructions. This is broad coverage, not exhaustive coverage of theoretical physics. In particular, these are not solutions of nonperturbative QFT, full string field theory, global Einstein evolution, or unresolved conjectures.

## Structure and model safety

Give a test model **only an individual `prompt` string from `model_prompts.json`**. This public export contains exactly `prompt_id` and `prompt` per record. Keep the evaluator folder inaccessible to test models.

Each folder is named `IMR-S3-<construction>-<01..04>-<descriptive-regime>/` and contains three files prefixed by that entire folder name:

- `*-problem.json`: canonical data, answer contract, exact gold and provenance identifiers.
- `*-transform.json`: the three changed problems, exact golds, transports and semantic witnesses.
- `*-certificate.sympy`: hash-bound executable certificate entrypoint.

`families_repo/all_files/` contains 288 byte-identical flat copies. The certificates require the shared engine in this package. `presentations.json`, the catalogue's linked per-family JSONs, certificates, tests, proof document and source code are evaluator material, not blind model inputs.

A transport never calls the gold solver. It maps a submitted sufficient state by an explicit resolvent, linear, triangular-jet, graded, filter or geometric law. Redundant observable errors are retained by a documented defect lift rather than replaced by correct values. Correctness and consistency are therefore separate scores.

## Replay

Tested with Python 3.13.7 and SymPy 1.14.0. The requirements file pins direct dependencies. From this directory:

```sh
python -m pytest -q
python verify.py
python families_repo/IMR-S3-KCS-01-bosonic-positive/IMR-S3-KCS-01-bosonic-positive-certificate.sympy
```

`verify.py` replays all 96 certificates, recomputes all 480 exports, checks 288 flat copies, verifies the frozen manifest, and checks pinned historical sources when those absolute paths are available. Absence of old sources on another machine is reported explicitly, without preventing replay of the self-contained new bank.

For development in a separately versioned, unfrozen copy, run materialization before tests and manifest freezing:

```sh
python materialize_families.py
python -m pytest -q --junitxml=TEST_RESULTS.xml > TEST_RESULTS.txt 2>&1
python verify.py --skip-manifest > VALIDATION.json
python freeze_manifest.py
python verify.py
```

The materializer and freezer refuse to regenerate an already frozen release. No model calls or network requests are made by reproduction scripts. The exact grader separates malformed/unresolved formats from explicit mathematical errors and does not evaluate response text as Python.
