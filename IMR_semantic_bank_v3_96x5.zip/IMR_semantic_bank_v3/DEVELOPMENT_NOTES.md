# Development findings retained

Before sealing, structural validation found two exact prompt collisions: KCS-03/T1 equalled KCS-01/canonical, and their doubled versions also coincided. The indefinite bosonic canonical level was changed from [[2,1],[1,-2]] to [[2,1],[1,-4]]. The final exports are required to have 384 distinct mathematical inputs and 480 distinct prompt strings; IDs alone do not satisfy that check.

A deliberately wrong PFQ-04 inverse state, twice the canonical inverse, lies on the singular denominator of T1. This is a valid counterexample to a total transport on all invertible matrices. The mathematical contract has always required both endpoint operators to be invertible; the final tests explicitly retain this undefined case and check other wrong states inside the domain. No claim of a globally defined resolvent transport is made. The grader records such consistency pairs as undefined.

These were internal development findings, not model failures. No empirical difficulty estimate is produced. The frozen original, v2 and calibration files were not modified.
