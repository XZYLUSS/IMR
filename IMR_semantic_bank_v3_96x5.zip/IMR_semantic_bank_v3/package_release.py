from pathlib import Path
import argparse,hashlib,json,zipfile
from freeze_manifest import eligible
from verify import verify_manifest
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args();out=Path(args.output).resolve()
    if out.is_relative_to(ROOT):raise ValueError('Archive must be outside the frozen folder')
    n=verify_manifest(ROOT);files=eligible()+[ROOT/'MANIFEST.sha256']
    if out.exists() or Path(str(out)+'.sha256').exists() or Path(str(out)+'.verification.json').exists():raise FileExistsError('Refusing to overwrite release artifacts')
    with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(files)
        for p in files:assert z.read(ROOT.name+'/'+p.relative_to(ROOT).as_posix())==p.read_bytes()
    digest=hashlib.sha256(out.read_bytes()).hexdigest()
    Path(str(out)+'.sha256').write_text(digest+'  '+out.name+'\n')
    result={'archive':str(out),'sha256':digest,'bytes':out.stat().st_size,'members':len(files),'manifest_entries':n,'all_members_byte_compared':True,'crc_verified':True}
    Path(str(out)+'.verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
