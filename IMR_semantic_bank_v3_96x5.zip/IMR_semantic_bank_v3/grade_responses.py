"""Offline, single-response-per-presentation scoring. JSONL: prompt_id, response."""
import argparse,json
from pathlib import Path
from core import *
from materialize_families import presentations,ARMS
from grading import grade

def main():
    p=argparse.ArgumentParser();p.add_argument('responses');p.add_argument('--output',required=True);args=p.parse_args()
    fixtures={f['id']:f for f in families()};lookup={f['id']+'/'+arm:(ff,solve(ff)) for f in families() for arm,ff in zip(ARMS,presentations(f))}
    records={};out=[];pairs=[]
    for line in Path(args.responses).read_text().splitlines():
        if not line.strip():continue
        row=json.loads(line);pid=row['prompt_id']
        if pid in records:raise ValueError('Duplicate prompt_id: evaluate repetitions in separate files')
        if pid not in lookup:raise ValueError('Unknown prompt_id')
        result=grade(row['response'],lookup[pid][1]);records[pid]=result
        out.append({'prompt_id':pid,**{k:v for k,v in result.items() if k!='parsed'}})
    for fid,f in fixtures.items():
        p1,p2=parameters(f['kind'])
        for arm in ARMS[1:]:
            base=records.get(fid+'/canonical',{}).get('parsed');target=records.get(fid+'/'+arm,{}).get('parsed')
            status='missing_or_unparsed'
            if base is not None and target is not None:
                try:
                    if arm=='paraphrase':expected=base
                    elif arm=='T1':expected=transport(f,base,p1)
                    elif arm=='T2':expected=transport(f,base,p2)
                    else:expected=transport(transform(f,p1),transport(f,base,p1),p2)
                    status='consistent' if same(expected,target) else 'inconsistent'
                except (ValueError,ZeroDivisionError,TypeError,KeyError,NotImplementedError):status='undefined_transport_domain'
            pairs.append({'family_id':fid,'arm':arm,'status':status})
    Path(args.output).write_text(json.dumps({'scores':out,'consistency':pairs,'note':'No empirical claims without supplied responses; missing pairs are not imputed.'},indent=2)+'\n')
if __name__=='__main__':main()
