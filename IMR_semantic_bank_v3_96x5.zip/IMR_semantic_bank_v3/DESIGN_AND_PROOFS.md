# Mathematical contract, transports and certificates

Version 3.0.0, 17 October 2026. All arithmetic is exact over rational numbers and polynomial rings unless a real positivity domain is explicitly stated. Indices are zero-based. Matrices act on columns. Source identifiers link to [REFERENCES.md](REFERENCES.md); the finite proofs below supply the actual benchmark guarantees.

## 1. Instrument and scope

The bank contains 24 construction clusters with four named configurations each. A family is one canonical mathematical input, two specified data deformations, their ordered composition, and a meaning-preserving paraphrase of the canonical input. Thus there are 96 families, 480 administered presentations, and 384 distinct inputs. Configuration names identify structure, signatures, modes, supports or coupling patterns; four configurations do not imply four independent theories.

For an input X, let S(X) be its sufficient answer state, and let O_X(S) denote the requested additional observables. The gold is (S(X),O_X(S(X))). All equations, measures, branches, orderings, signatures and output normalizations are stated in each prompt. No unspecified regulator, continuum limit, boundary condition or sign convention is inferred from a name.

The central condition is

\[
 S(TX)=\rho_{T,X}S(X),\qquad
 \operatorname{Sol}(TX)=\tau_{T,X}\operatorname{Sol}(X).
\]

Here T generally changes physical content **at fixed labels and conventions**. It need not be a gauge transformation, coordinate equivalence or symmetry. A changed fixed-label observable proves that the administered question changed; it does not prove inequivalence under every conceivable duality or field redefinition. In KCS a changed determinant supplies the stronger topological-degeneracy witness. The preserved v2 equivalence bank and this counterfactual bank should not be conflated statistically.

### The observable-defect extension

For a submitted answer (s,o), define its defect d=o-O_X(s). We set

\[
 \tau_{T,X}(s,o)=\left(\rho_{T,X}s,
 O_{TX}(\rho_{T,X}s)+d\right).
\]

The state transports below use submitted states and known input data, never a call to the gold solver. Observable defects are carried unchanged; a wrong redundant observable is not repaired. If state transports satisfy inverse and composition identities, so does this lift: in coordinates (s,d), the map is simply (s,d)↦(ρs,d). This is an explicit benchmark extension to wrong answers, not a unique physical interpretation of an inconsistent tuple. It can require substantial algebra to evaluate and is not intended as a shortcut offered to test models.

The state spaces are the displayed rational matrices, vectors or polynomials with the following restrictions where necessary: inverse states must be invertible and their transport denominators nonzero; QIN states are positive semidefinite with positive trace; NAR states lie on the positive generalized-metric manifold; rational observable denominators must exist. Polynomial candidate states may violate the defining equations. A transport outside its domain is **undefined**, not consistent. Physical input domains can be smaller than these algebraic domains.

### Common deformation law

Except QIN and ISM, T1 adds a specified driver V and T2 doubles X:

\[T_{a,b}X=aX+bV,\quad T_1=T_{1,1},\quad T_2=T_{2,0}.\]

NAR uses G↦aG and B↦aB+bV; LDB also sends forcing c↦ac+bd; ANM scales signed multiplicities and adds the specified spectator species. Hence

\[
 T_{a_2,b_2}T_{a_1,b_1}=T_{a_2a_1,a_2b_1+b_2},\quad
 T_{a,b}^{-1}=T_{1/a,-b/a}.
\]

The composite is 2X+2V, while reversal is 2X+V. The inverse is asserted on the image of the stated admissible problem, not as a globally positive physical operation. In particular, integer matter content, integral Chern-Simons levels and positive dissipation are not preserved by arbitrary rational inverse parameters. Every forward endpoint and reversed-order control used here is checked for the relevant mathematical conditions. A continuous interpolation between endpoints need not remain nonsingular.

## 2. RBG and LAT: finite Green response

X is a real symmetric positive definite four-site operator; f is fixed. The action X_ij u_i u_j/2-f_i u_i has a unique stationary point r satisfying Xr=f, and its Green operator is G=X^{-1}. The observables are r=Gf and det X. Positivity follows from exact leading principal minors. The endpoint and lattice matrices are authoritative finite problems, with distinct configurations and different deformation drivers. They share an inverse-response mechanism; neither is a continuum self-adjoint-extension theorem. Background: [DYN, GAUGE].

For every invertible submitted G such that aI+bGV is invertible,

\[
 G'=(aI+bGV)^{-1}G=(aG^{-1}+bV)^{-1}.
\]

Multiplication by aG^{-1}+bV gives the identity. Applying the inverse affine map to G'^{-1} recovers G^{-1}, proving a two-sided inverse and composition on the stated domain. A fixed-site response can change when endpoint couplings, closure signs or pinning change; retaining the canonical answer is not an invariance principle. Certificates check both inverse equations, positivity and the driven observable.

## 3. GBS: four inequivalent Gaussian operations

Let K=X>0 and j be the source. Completing the square gives mean μ=K^{-1}j and covariance C=K^{-1}. Partition coordinates into observed o and hidden h. The four modes are:

- Marginalization: precision S=K_oo-K_oh K_hh^{-1}K_ho=(C_oo)^{-1}, mean μ_o, and hidden determinant det K_hh.
- Conditioning at h=η: precision K_oo and mean K_oo^{-1}(j_o-K_oh η).
- Linear observation z=P u: covariance P C P^T, precision its inverse, and mean Pμ. Full row rank is checked through the resulting positive covariance.
- Restriction u=Pz: precision P^T K P, mean (P^T K P)^{-1}P^T j, and induced measure sqrt(det P^T P) dz. This is an intrinsic subspace measure, not a conditioning delta function with an unstated normalization.

These expressions follow respectively from completing the hidden square, substituting fixed hidden coordinates, pushing first and second moments through a linear map, and pulling the quadratic form and Euclidean Gram volume onto the subspace. All required blocks are nonsingular because K>0 and P has full rank. The inverse-state transport is that of §2, and the defect lift preserves all observable errors. Certificates separately check block completion, determinant factorization or stationarity in the selected mode. Physical point: operations that sound like “remove hidden variables” need not define the same state. Background: [STAT].

## 4. PFQ: oriented fermionic Gaussian

An invertible antisymmetric six-matrix A defines the exterior polynomial Q=Σ_{i<j}A_ij θ_iθ_j. The coefficient of θ_0⋯θ_5 in Q^3/3! is Pf(A), fixing the sign by definition. Expansion by the partner of θ_0 yields

\[\operatorname{Pf}(A)=\sum_{j=1}^{5}(-1)^{j+1}A_{0j}\operatorname{Pf}(A_{\widehat{0j}}).\]

The state is the algebraic inverse A^{-1}. Pf(A)^2=det A is checked, but is not used to choose a square-root sign. An independent bitmask exterior-algebra multiplication verifies the oriented coefficient. Inverse transport follows §2 with an antisymmetric driver; antisymmetry and invertibility are checked at all endpoints. Pairing changes modify the fermionic quadratic form, not just its notation. No infinite-dimensional Pfaffian line, regularization or global anomaly is certified. Background: [QFT, FERMION].

## 5. DRC: second-class reduction

With canonical J and full-row-rank C, let Δ=CJC^T, assumed invertible. The reduced bracket is

\[J_D=J-JC^T\Delta^{-1}CJ.\]

It is antisymmetric and CJ_D=0. It is uniquely determined by these Casimir conditions and requiring each column of J_D-J to belong to im(JC^T): write J_D-J=JC^T L and solve ΔL=-CJ. For H=u^T Xu/2, the flow matrix is A=J_D X. Deforming H sends (J_D,A) to (J_D,aA+bJ_D V), including for wrong bracket/flow tuples. This linear law has the affine inverse and composition of §1. Characteristic coefficients and C J_D are observables. The certificate tests the correction's column-space rank, the constraints and the Hamiltonian vector field. The constraints themselves remain fixed within a family and differ across its configurations. Background: [HENNEAUX, DYN].

## 6. HDV: bulk and boundary variation

For L(q,v,a), total differentiation D is the jet chain rule. Define

\[R=L_a,\qquad P=L_v-DR,\qquad E=L_q-DP.\]

Twice applying the product rule gives δL=E^Tδq+D(P^Tδq+R^Tδv). Comparing independent variation jets proves uniqueness. For autonomous L, H=P^Tv+R^Ta-L obeys DH=-E^Tv. A driver V changes the state linearly: (E,P,R)'=a(E,P,R)+b(E_V,P_V,R_V). This follows from linearity of variation and differentiation; inverse and composition hold on all polynomial tuples. Unlike a pure boundary term, the chosen driver has nonzero bulk Euler variation. Degenerate acceleration Hessians do not obstruct this off-shell calculation; no Legendre invertibility is claimed. Certificates check the full variation polynomial and energy identity. Background: [DYN].

## 7. RIC: branch-sensitive local Riccati jet

Writing u=ψ'/ψ in ψ''=Vψ gives u'+u²=V. Because ψ(0)=1, the logarithmic derivative exists locally. With u=c0+Σ_{k=1}^5 c_k t^k and V=Σ_{k=0}^4 v_k t^k, coefficient matching gives

\[(k+1)c_{k+1}=v_k-\sum_{i=0}^k c_i c_{k-i}.\]

This determines a unique jet given c0. Conversely, every candidate c1,…,c5 determines v_k=(k+1)c_{k+1}+Σ c_i c_{k-i}. These are mutually inverse triangular polynomial maps. Transport decodes this inferred potential jet, applies v↦av+bV_driver, and re-encodes it with the same c0. It therefore acts on wrong jets without using the correct potential as an oracle; inverse and composition follow by conjugation. Residual coefficients are redundant observables carried by the defect lift. This is a local response problem, not a WKB or global spectral theorem. Background: [DLMF27].

## 8. DYS: ordered matrix evolution

For U'=A(t)U, U0=I and A(t)=Σ_{i=0}^3 A_i t^i,

\[(k+1)U_{k+1}=\sum_{i=0}^k A_i U_{k-i}.\]

This recurrence uniquely determines four matrix jets. Its inverse is A_k=(k+1)U_{k+1}-Σ_{i<k}A_i U_{k-i}; multiplication by U0 needs no inversion. Conjugating the affine driver action through these triangular maps gives the transport on arbitrary four-tuples. Noncommuting order is essential. The determinant jet also satisfies (det U)'=tr(A)det U to the certified order, providing an additional check. The model is general linear evolution, without an unitarity assumption. Background: [QFT, DLMF27].

## 9. IMP: inverse equation of state

Work in Q[t]/(t^7). Every φ(t)=t+Σ_{k=2}^6 a_k t^k has a unique inverse ψ(t)=t+Σ c_k t^k under composition: at degree k the unknown c_k occurs once, with coefficient 1, and all other terms depend on earlier coefficients. Finite recursive cancellation constructs it. Formal inversion is an involution. Therefore the answer transport is ψ↦inverse(t+a*(inverse(ψ)-t)+b*V(t)), where V has no constant or linear term. This is an invertible polynomial map on the five coefficients, even for wrong answers. A critical branch with φ'(0)=0 is excluded, so no Puiseux or branch-selection ambiguity is hidden. Susceptibility follows by differentiation. The certificate substitutes the inverse into the equation through degree six. Background: [SFTSTAT]; the finite-ring proof above is sufficient.

## 10. DST: signed endpoint distributions

For f_n(x)=n exp(-nx)P(nx), substitute u=nx. Taylor's formula for a smooth compactly supported φ gives

\[c_k=\frac1{k!}\int_0^\infty e^{-u}P(u)u^kdu.\]

For P(u)=Σ p_j u^j, c_k=Σ p_j(j+k)!/k!. Integration by parts proves the factorial moments and exponential decay eliminates the endpoint at infinity. The remainder through k=5 is bounded by

\[n^{-6}\|\phi^{(6)}\|_\infty\sum_j |p_j|(j+6)!/6!.\]

Thus the asymptotic claim is rigorous for signed profiles as well as positive ones. The coefficient of δ^(k) is (-1)^k c_k. Linearity gives c' = a c+b c_driver, an invertible affine transport for a≠0. Addition changes the physical profile and possibly its mass; it is not a coordinate transformation. Certificates differentiate explicit exponential-polynomial antiderivatives and compute a finite rational remainder bound. Background: [DLMF23].

## 11. RGJ: nonlinear flow coefficients

For dg/dt=β(g), Taylor expansion along the vector field gives A=ββ'/2 and B=β(β'^2+ββ'')/6=β A'/3. These are polynomial identities for the supplied cubic beta functions. Under β'=aβ+bV (prime here denoting a changed function only), the second time coefficient transports as

\[A_{new}=a^2 A+\tfrac12 ab(\beta V_g+V\beta_g)+\tfrac12 b^2 V V_g.\]

Subtracting the true coefficient shows that an arbitrary state error scales by a². Hence inversion and composition follow from the affine data law, independently of correctness. The third-order coefficient is an observable with defect lift. Direct substitution verifies the O(t³) differential equation coefficients. This is a formal fixed-coordinate flow example, not an actual multiloop computation or scheme change. Background: [SFTSTAT, GAUGE].

## 12. ANM: chirality-sensitive degree-six polynomial

In the declared dimensionless convention, expand exp(q1F1+q2F2)(1-p1/24) and retain total form degree six. A species contributes (q1F1+q2F2)^3/6-p1(q1F1+q2F2)/24, multiplied by signed multiplicity and spectator dimension. Two-forms commute, so the mixed cubic coefficients include binomial factors. Summing species gives six rational coefficients uniquely. Adding a species and multiplying all multiplicities act linearly on this coefficient column; inverse statements are algebraic and only physical on valid matter-content images. The certificate independently assembles the degree-six polynomial. This does not test anomaly cancellation of an unspecified non-Abelian gauge group or a global anomaly. Background: [HARVEY].

## 13. MOY: exact Weyl ordering

Let Λ=left_∂x right_∂y-left_∂y right_∂x. Antisymmetrizing the exponential star product gives

\[\frac{f\star b-b\star f}{ih}=\Lambda(f,b)-\frac{h^2}{24}\Lambda^3(f,b)+\frac{h^4}{1920}\Lambda^5(f,b).\]

For the degree-five-or-less symbols here all higher derivatives vanish. The finite bidifferential expansion is unambiguous; the sign follows from (i)^(2r). Holding b fixed, f↦af+b_parameter V transports the entire symbol linearly by adding the bracket of V with the fixed right symbol. The software expands both ordered star products independently of this odd-term formula. Classical and quantum pieces are derived observables. The physical deformation changes the operator symbol at fixed canonical commutator. Background: [MOYAL].

## 14. CON: conformal geometry

For g=e^{2φ}η in d=3, differentiation of the metric and the torsion-free metric-compatibility equation gives

\[\Gamma^i_{jk}=\delta^i_j\phi_k+\delta^i_k\phi_j-\eta_{jk}\eta^{il}\phi_l.\]

Substitution into the prompt's curvature convention yields

\[R_{ij}=-(d-2)\phi_{ij}-\eta_{ij}\Box_\eta\phi+(d-2)(\phi_i\phi_j-\eta_{ij}|d\phi|_\eta^2).\]

The sufficient state is (dφ,Hess φ), so its transport under φ↦aφ+bV is linear. Ricci and e^{2φ}R=η^{ij}R_ij are observables. The certificate computes Ricci directly from the connection, not just from the displayed contracted formula. Constant and nonconstant conformal changes need not have the same physical effects; the chosen drivers have nontrivial curvature witnesses. No Einstein equation is imposed. Background: [GR].

## 15. ADM: extrinsic constraints

With constant positive γ, the spatial connection and scalar curvature vanish. Trace reversal P=K-γ tr_γ K has inverse K=P-γ tr_γ P/2 in three dimensions. Thus the state transport is P↦aP+b(V-γ tr_γ V). The Hamiltonian expression is (tr_γ K)^2-tr((γ^{-1}K)^2), and M_i=γ^{jl}∂_j P_li. Expanding the first expression gives the sum over i≠j of K^i_i K^j_j-K^i_j K^j_i, checked independently. The driver changes extrinsic data and constraint sources. This does not construct vacuum initial data or solve the nonlinear Einstein evolution equations. Background: [GR].

## 16. HOD: orientation, signature and stress

For the unit-volume diagonal metrics here, the epsilon contraction gives *²=det(η) on two-forms: +1 in Euclidean signature and -1 with one timelike direction. Therefore F=det(η)*(*F), so the dual state is sufficient. Hodge duality is linear, giving (*F)'=a(*F)+b(*V). The two scalar contractions and stress follow from metric index raising. Antisymmetry implies T_ij=T_ji, while in four dimensions the trace cancels exactly. Reversing orientation changes *F but not the ordinary stress; changing signature changes contractions. The certificate checks both operations explicitly. Background: [GR].

## 17. KCS: topological level changes

For nonsingular integral symmetric K, the declared Abelian Chern-Simons normalization gives ν=t^T K^{-1}t and representative twice-spin l^T K^{-1}l. Integer charges are fixed. The finite lattice quotient Z^2/KZ^2 has order |det K|, the stated torus degeneracy. Odd diagonal K is treated as a spin theory; no bosonic claim is made for those configurations. The inverse-state transport follows §2. Since level addition and doubling can change |det K|, they need not be unimodular basis changes or topological equivalences. Integrality and nondegeneracy are checked at every administered endpoint. Background: [WEN].

## 18. YMC: non-Abelian curvature

For constant matrices, [∂0+A0,∂1+A1]=[A0,A1]. The adjoint derivative is [A_i,F]. Under A_i↦aA_i+bV_i,

\[F'=a^2F+ab([A_0,V_1]+[V_0,A_1])+b^2[V_0,V_1].\]

This follows by bilinear expansion and transports an arbitrary curvature error by a². Hence it has the affine inverse/composition law when input context is transformed along with the answer. The covariant derivatives and tr(F²) use the defect lift. The matrices are real traceless connections, not anti-Hermitian compact-gauge fields. Constant coefficients alone do not imply flatness. Background: [GAUGE].

## 19. QIN: selective filtering

The preparation state is R=WW^T, with positive weight Z=tr R. Positivity follows from v^T Rv=||W^T v||². The normalized state is ρ=R/Z; partial trace is a component sum and partial transpose swaps only the second subsystem's indices. Purities and det ρ^{T_B} are exact rational observables.

T1 uses M1=[[1,1],[0,1]]/3 and T2 uses M2=diag(1/2,1) on the first qubit. W↦(M⊗I)W induces R↦(M⊗I)R(M^T⊗I). Both filters obey M^T M≤I and are invertible, so they describe valid selected outcomes; the inverse is an algebraic recovery on the image and need not itself be a contractive physical filter. Composition is M2 M1 and is noncommuting. Normalization changes are retained in observables. Background: [PRESKILL].

## 20. LDB: Lindblad steady response

Using the Pauli basis and tr(σ_iσ_j)=2δ_ij, expansion of the supplied master equation gives A_ij=tr(σ_i L(σ_j/2)) and c_i=tr(σ_i L(I/2)). The stationary Bloch vector is r=-A^{-1}c and purity is (1+r^T r)/2. Each forward deformation multiplies the existing Hamiltonian/rates and adds a specified positive-rate generator, so A↦aA+bV and c↦ac+bd. The inverse-state map follows §2; observables use the transformed forcing.

The certificate recomputes A,c from the master equation, substitutes the reconstructed density into L(ρ)=0, and checks the Bloch ball. This is an exact driven-qubit steady state, not a proof about a general many-body dissipative gap. Background: [LINDBLAD].

## 21. OUC: Lyapunov covariance and current

All diffusion coordinates are even under time reversal and the declared entropy convention has Boltzmann constant 1. For drift B and covariance N>0, Itô differentiation of XX^T gives dΣ/dt=BΣ+ΣB^T+N. The supplied B has B+B^T<0, so every eigenvalue has negative real part: for a complex eigenvector v, 2 Re(λ)||v||²=v†(B+B^T)v<0. Therefore

\[\Sigma=\int_0^\infty e^{Bt}N e^{B^Tt}\,dt\]

converges, is positive, and solves the Lyapunov equation. If two solutions differ by Z, e^{Bt}Ze^{B^Tt} is constant and tends to zero, so Z=0. The driver is V=-(B+B^T), whose covariance is I. Thus N↦aN+bV induces Σ↦aΣ+bI.

With D=N/2 and F=B+DΣ^{-1}, J=Fxρ. Gaussian second moments give the prompt's entropy integral as tr(F^T D^{-1}FΣ)≥0. Q=BΣ-ΣB^T detects circulation; it need not vanish in a stationary state. Certificates check positivity, Lyapunov stationarity and nonnegative entropy production. Background for the linear diffusion: [OU]; the multidimensional covariance and entropy identities are derived here.

## 22. ISM: finite ensemble and cumulants

For eight spin configurations, characters χ_A(s)=∏_{i∈A}s_i satisfy Σ_s χ_Aχ_B=8δ_AB. Thus the Walsh moments M_A uniquely determine weights w(s)=Σ_A M_Aχ_A(s)/8. Dividing by M_empty gives expectations. Expanding third central moments yields the connected third cumulant μ012-μ01μ2-μ02μ1-μ12μ0+2μ0μ1μ2.

T1 multiplies weights with s0=+1 by two. Since this factor is 3/2+s0/2, moments transform as M_A↦3M_A/2+M_{A△{0}}/2. T2 reverses the physical site0 spin distribution at fixed reported spin labels: M_A↦(-1)^{1_{0∈A}}M_A. Both are invertible and preserve positive weights; the inverse bias has coefficients 3/4,-1/4. They do not commute. T2 is related to a spin relabeling if observables are also relabeled; this bank explicitly fixes observables. There is no thermodynamic-limit phase-transition claim. Background: [STAT].

## 23. NAR: fixed-charge torus moduli

For G>0 and B^T=-B, completing the charge square gives

\[\mathcal H=\begin{pmatrix}G^{-1}&-G^{-1}B\\BG^{-1}&G-BG^{-1}B\end{pmatrix}.\]

It is positive and satisfies HηH=η, η=[[0,I],[I,0]]. Conversely its top blocks recover G=(H_nn)^{-1} and B=-G H_nw. This bijective parametrization defines the answer domain. Transport decodes candidate moduli, applies G↦aG and B↦aB+bV, and re-encodes. For a>0 this stays in the positive generalized-metric manifold; the affine inverse and composition laws follow directly. Charge energy is q^THq and level pairing is n^Tw. A fractional B shift at fixed integer charges is not being declared a large-gauge symmetry or T-duality. The certificate verifies both the generalized-metric equation and the independently completed charge square. Background: [KIRITSIS].

## 24. SFT: finite graded curvature

Let D be odd and D²=0. For homogeneous A, Q(A)=DA-(-1)^|A|AD is an odd derivation and Q²(A)=D²A-AD²=0. For odd Ψ,

\[F=Q\Psi+\Psi^2,\quad R_V=QV+\Psi V+V\Psi.\]

Using Q(Ψ²)=(QΨ)Ψ-Ψ(QΨ) gives QF+ΨF-FΨ=0 off shell. This proves the Bianchi identity without assuming F=0. Under Ψ↦aΨ+bV,

\[F'=aF+(a^2-a)\Psi^2+bQV+ab(\Psi V+V\Psi)+b^2V^2.\]

An arbitrary curvature error scales by a, so the context-dependent affine inverse and composition follow. The remaining fields use the defect lift. Certificates check parity, D²=0, curvature and Bianchi equations. This realizes a differential graded algebra mechanism relevant to cubic open string field theory; it does not implement string vertices, a cyclic action, BRST cohomology, the BV master equation or a closed-string homotopy algebra. Background: [WITTEN].

## 25. Executed evidence and limitations

Each of 96 certificates checks the four distinct inputs, all three nonidentity answer changes, inverse transports, the ordered composition, rejection of a reversed-order answer, and one construction-specific semantic mistake. The canonical answer copied to each changed arm is rejected. Wrong observable defects survive transport. Tests also use wrong sufficient states within the algebraic domain, symbolic parameter identities and a retained singular inverse-state counterexample.

The stored difference witnesses are exact nonzero rationals or polynomials. No floating tolerance is used. Analytic statements (Gaussian integration, local solution existence, Taylor remainders, stable covariance integrals) are justified by the arguments above; SymPy certifies their finite hypotheses and algebraic consequences, not analytic theorems in a proof assistant. Some checks intentionally share utilities with the solver. The separate equation checks are additional verification, not an independent implementation or external peer review.

The generated `.sympy` entrypoints bind both per-family JSONs by SHA-256 and replay shared code. The final manifest binds that code, this proof document and the artifacts. Hashes establish integrity, not mathematical truth. Full response correctness, answer-transport consistency, proof correctness, empirical difficulty and population-level generalization remain separate notions.
