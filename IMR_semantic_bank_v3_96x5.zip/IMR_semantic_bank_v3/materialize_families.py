from pathlib import Path
import hashlib,json
from core import *
from catalog import META,title,folder,prompt,schema,public_data
from certificates import certify,flat,difference
ROOT=Path(__file__).resolve().parent
ARMS=('canonical','T1','T2','T2_after_T1','paraphrase')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,value):p.write_text(dumps(value))
def presentations(f):
    p1,p2=parameters(f['kind']);ff1=transform(f,p1)
    return [f,ff1,transform(f,p2),transform(ff1,p2),f]
def artifact_data(f):
    fs=presentations(f);answers=[solve(v) for v in fs];report=certify(f)
    problem={'version':VERSION,'family_id':f['id'],'title':title(f),'construction_cluster':f['kind'],'regime':META[f['kind']][2].split()[f['regime']],'domain':META[f['kind']][1],'semantic_fault_line':META[f['kind']][3],'reference_ids':[META[f['kind']][4]],'confirmatory_eligible':False,'input':f,'answer_schema':schema(answers[0]),'gold':answers[0]}
    trans={'family_id':f['id'],'kind':'physical_data_deformation_at_fixed_conventions','T1':parameters(f['kind'])[0],'T2':parameters(f['kind'])[1],'composition_order':'T1 then T2','inverse_scope':'algebraic answer map on its stated domain; physical inverse only on admissible images','transport_implementation':'core.transport; proof in DESIGN_AND_PROOFS.md','arms':{arm:{'input':ff,'gold':aa} for arm,ff,aa in zip(ARMS[1:4],fs[1:4],answers[1:4])},'semantic_witnesses':report['semantic_witnesses'],'negative_controls':report['negative_controls']}
    return problem,trans,report,fs,answers

def build():
    if (ROOT/'MANIFEST.sha256').exists():raise RuntimeError('Frozen release: create a new version before regenerating.')
    repo=ROOT/'families_repo';repo.mkdir(exist_ok=True);flatdir=repo/'all_files';flatdir.mkdir(exist_ok=True)
    public=[];private=[];reports=[];index=[];expected=set();canon=[]
    for f in families():
        problem,trans,report,fs,answers=artifact_data(f);d=repo/folder(f);d.mkdir(exist_ok=True);prefix=folder(f)
        pb=d/(prefix+'-problem.json');tb=d/(prefix+'-transform.json');write(pb,problem);write(tb,trans)
        cert=d/(prefix+'-certificate.sympy')
        cert.write_text("#!/usr/bin/env python3\nfrom pathlib import Path\nimport sys\nroot=next(p for p in Path(__file__).resolve().parents if (p/'core.py').is_file() and (p/'verify.py').is_file())\nsys.path.insert(0,str(root))\nfrom verify import replay_one\nreplay_one("+repr(f['id'])+", "+repr(sha(pb.read_bytes()))+", "+repr(sha(tb.read_bytes()))+")\n")
        for path in (pb,tb,cert):(flatdir/path.name).write_bytes(path.read_bytes());expected.add(path.name)
        for arm,ff,answer in zip(ARMS,fs,answers):
            pid=f['id']+'/'+arm;text=prompt(ff,answer,arm=='paraphrase')
            public.append({'prompt_id':pid,'prompt':text})
            private.append({'prompt_id':pid,'family_id':f['id'],'construction_cluster':f['kind'],'arm':arm,'input':ff,'gold':answer,'prompt_sha256':sha(text.encode())})
        canon.append(sha(dumps(public_data(f)).encode()))
        index.append({'family_id':f['id'],'folder':folder(f),'title':title(f),'cluster':f['kind'],'domain':META[f['kind']][1],'reference_ids':[META[f['kind']][4]],'problems':5,'confirmatory_eligible':False,'canonical_answer_entries':len(list(flat(answers[0])))})
        reports.append(report);print(f['id'],'certified',flush=True)
    assert len(set(canon))==96,'duplicate canonical mathematical input'
    assert {p.name for p in flatdir.iterdir()}==expected
    assert len(public)==480 and len({r['prompt_id'] for r in public})==480
    assert len({r['prompt'] for r in public})==480
    write(ROOT/'model_prompts.json',public);write(ROOT/'presentations.json',private);write(ROOT/'FAMILY_INDEX.json',index);write(ROOT/'CERTIFICATE_RESULTS.json',reports)
    summary={'families':96,'construction_clusters':24,'presentations_per_family':5,'public_problems':480,'distinct_mathematical_inputs':384,'canonical_input_hashes_distinct':96,'nonidentity_deformed_answers':288,'reversed_order_controls_rejected':96,'construction_specific_wrong_answers_rejected':96,'copied_canonical_answers_rejected':288,'flat_artifacts':len(expected),'empirical_accuracy':None,'difficulty_status':'uncalibrated candidate','independent_mathematical_review':False,'canonical_entries_min':min(v['canonical_answer_entries'] for v in index),'canonical_entries_max':max(v['canonical_answer_entries'] for v in index)}
    write(ROOT/'STRUCTURAL_AUDIT.json',summary)
    lines=['# Family catalogue','', '96 families in 24 dependent construction clusters; five problems per family. These labels do not assert 96 independent mechanisms or measured difficulty.','', '| ID | Family | Domain | Entries in canonical answer |','|---|---|---|---:|']
    lines += [f"| [{v['family_id']}](families_repo/{v['folder']}/{v['folder']}-problem.json) | {v['title']} | {v['domain']} | {v['canonical_answer_entries']} |" for v in index]
    (ROOT/'CATALOGUE.md').write_text('\n'.join(lines)+'\n')
    print(dumps(summary))
if __name__=='__main__':build()
