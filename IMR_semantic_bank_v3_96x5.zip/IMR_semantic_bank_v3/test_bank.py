import copy,json,pytest
from core import *
from certificates import certify,defining_checks,wrong_answer
from grading import exact,Invalid,grade,parse
from materialize_families import presentations,ARMS

@pytest.mark.parametrize('f',families(),ids=lambda f:f['id'])
def test_certificates(f):assert certify(f)['wrong_answer_defect_preserved']

@pytest.mark.parametrize('f',families(),ids=lambda f:f['id'])
@pytest.mark.parametrize('arm',range(5))
def test_gold_export_parser_and_grade(f,arm):
    gold=solve(presentations(f)[arm]);assert grade(dumps(gold),gold)['status']=='correct'

@pytest.mark.parametrize('f',families(),ids=lambda f:f['id'])
def test_wrong_state_inverse_and_composition(f):
    a=solve(f);b=copy.deepcopy(a)
    if f['kind']=='NAR':
        G,B=narain_decode(b['state']);b['state']=narain(2*G,B)
    else:
        for factor in (s.Integer(2),s.Rational(3,2),s.Rational(4,3)):
            b['state']=mul(factor,a['state'])
            if f['kind'] in ('RBG','LAT','GBS','PFQ','KCS','LDB'):
                if (s.eye(b['state'].rows)+b['state']*f['V']).det()==0:continue
            break
        else:raise AssertionError('No admissible wrong state chosen')
    p1,p2=parameters(f['kind']);f1=transform(f,p1);m=transport(f,b,p1)
    assert same(transport(f1,m,inverse(f['kind'],p1)),b)
    if True:
        combined=compose(f['kind'],p1,p2)
        assert same(transport(f1,m,p2),transport(f,b,combined))
        assert same(solve(transform(f1,p2)),solve(transform(f,combined)))
    assert not same(b,a)

@pytest.mark.parametrize('payload',["__import__('os').system('id')",'x.__class__','1.0','True','1/0','x/y','2**10000','(x+y+z)**12','[1,2]','lambda:1','sqrt(2)','nan','inf','1e100','2**-1'])
def test_unsafe_or_out_of_contract_expression_rejected(payload):
    with pytest.raises(Invalid):exact(payload)

def test_duplicate_json_and_schema():
    a={'state':s.Integer(1)}
    for text in ['{"state":"1","state":"2"}','{"state":"1","gold":"1"}','{"state":1}']:
        with pytest.raises(Invalid):parse(text,a)

def test_noncommuting_affine_parameter_law_symbolic():
    aa,bb,cc,dd,xx,vv=s.symbols('aa bb cc dd xx vv',nonzero=True)
    assert s.expand(cc*(aa*xx+bb*vv)+dd*vv-(cc*aa*xx+(cc*bb+dd)*vv))==0
    assert s.cancel(((aa*xx+bb*vv)-bb*vv)/aa-xx)==0

def test_inverse_response_symbolic_two_dimensional():
    aa,bb,u,v,w,z,p,q=s.symbols('aa bb u v w z p q',nonzero=True)
    G=M([[u,v],[w,z]]);V=s.diag(p,q)
    new=(aa*s.eye(2)+bb*G*V).inv()*G
    assert same((aa*G.inv()+bb*V)*new,s.eye(2))

def test_export_shape_contract():
    from pathlib import Path
    rows=json.loads((Path(__file__).parent/'model_prompts.json').read_text())
    assert len(rows)==480 and all(set(r)=={'prompt_id','prompt'} for r in rows)
    assert len({r['prompt'] for r in rows})==480


def test_singular_wrong_answer_transport_is_undefined():
    from sympy.matrices.exceptions import NonInvertibleMatrixError
    f=fixture('PFQ',3);a=solve(f);a['state']=2*a['state']
    assert (s.eye(6)+a['state']*f['V']).det()==0
    with pytest.raises(NonInvertibleMatrixError):transport(f,a,parameters('PFQ')[0])


def test_invalid_generalized_metric_not_projected_to_gold():
    f=fixture('NAR',0);a=solve(f);a['state'][3,3]+=1
    with pytest.raises(ValueError):transport(f,a,parameters('NAR')[0])

def test_nonpositive_quantum_candidate_undefined():
    f=fixture('QIN',0);a=solve(f);a['state']=-a['state']
    with pytest.raises(ValueError):transport(f,a,parameters('QIN')[0])

@pytest.mark.parametrize('f',families(),ids=lambda f:f['id'])
def test_semantic_wrong_answer_rejected_by_grader(f):
    gold=solve(f);bad,label=wrong_answer(f,gold)
    assert grade(dumps(bad),gold)['status']=='incorrect',label
