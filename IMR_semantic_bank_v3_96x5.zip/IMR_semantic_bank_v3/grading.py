"""Bounded exact parser. No eval, sympify or model-authored code execution."""
import ast,json
import sympy as s
from core import SYMS,same,cl
MAX_TEXT=600000
class Invalid(ValueError):pass

def exact(text):
    if not isinstance(text,str) or len(text)>30000:raise Invalid('entry must be a bounded expression string')
    try:tree=ast.parse(text,mode='eval')
    except (SyntaxError,ValueError,RecursionError) as e:raise Invalid('invalid expression syntax') from e
    if sum(1 for _ in ast.walk(tree))>2500:raise Invalid('expression too large')
    def bound(v):
        v=s.expand(v)
        if v.is_number:
            if not v.is_Rational or max(abs(int(v.p)).bit_length(),int(v.q).bit_length())>4096:raise Invalid('rational bound')
        else:
            p=s.Poly(v,*sorted(v.free_symbols,key=str))
            if p.total_degree()>24 or len(p.terms())>2048:raise Invalid('polynomial bound')
        return v
    def rec(n,depth=0):
        if depth>64:raise Invalid('expression depth')
        if isinstance(n,ast.Constant) and type(n.value) is int:
            if abs(n.value).bit_length()>4096:raise Invalid('integer bound')
            return s.Integer(n.value)
        if isinstance(n,ast.Name) and n.id in SYMS:return SYMS[n.id]
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):
            v=rec(n.operand,depth+1);return v if isinstance(n.op,ast.UAdd) else -v
        if isinstance(n,ast.BinOp):
            a=rec(n.left,depth+1);b=rec(n.right,depth+1)
            if isinstance(n.op,ast.Add):return bound(a+b)
            if isinstance(n.op,ast.Sub):return bound(a-b)
            if isinstance(n.op,ast.Mult):
                if len(s.Add.make_args(a))*len(s.Add.make_args(b))>4096:raise Invalid('expansion budget')
                return bound(a*b)
            if isinstance(n.op,ast.Div):
                if b.free_symbols or not b.is_Rational or b==0:raise Invalid('constant nonzero denominator required')
                return bound(a/b)
            if isinstance(n.op,ast.Pow):
                if not b.is_Integer or not 0<=b<=12:raise Invalid('power bound')
                if len(s.Add.make_args(a))**int(b)>4096:raise Invalid('power expansion budget')
                return bound(a**b)
        raise Invalid('unsupported expression')
    return rec(tree.body)

def no_duplicates(pairs):
    d={}
    for k,v in pairs:
        if k in d:raise Invalid('duplicate JSON key')
        d[k]=v
    return d

def decode_like(raw,template):
    if isinstance(template,s.MatrixBase):
        if not isinstance(raw,list) or len(raw)!=template.rows or any(not isinstance(row,list) or len(row)!=template.cols for row in raw):raise Invalid('matrix shape')
        return s.Matrix([[exact(v) for v in row] for row in raw])
    if isinstance(template,dict):
        if not isinstance(raw,dict) or raw.keys()!=template.keys():raise Invalid('object keys')
        return {k:decode_like(raw[k],v) for k,v in template.items()}
    if isinstance(template,(list,tuple)):
        if not isinstance(raw,list) or len(raw)!=len(template):raise Invalid('list length')
        return [decode_like(v,t) for v,t in zip(raw,template)]
    return exact(raw)

def parse(text,template):
    if not isinstance(text,str) or len(text)>MAX_TEXT:raise Invalid('response size')
    try:raw=json.loads(text,object_pairs_hook=no_duplicates,parse_constant=lambda _:(_ for _ in ()).throw(Invalid('nonfinite JSON')))
    except (ValueError,RecursionError) as e:raise Invalid(str(e)) from e
    return decode_like(raw,template)

def grade(text,gold):
    try:a=parse(text,gold)
    except Invalid as e:return {'status':'format_unresolved','reason':str(e)}
    return {'status':'correct' if same(a,gold) else 'incorrect','parsed':a}
