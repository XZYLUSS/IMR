# Release summary

**96 families, 24 construction clusters, five presentations each, 480 prompts.** This separately named expansion retains the old releases and their original IDs in their frozen folders. The new catalogue is a redesigned broader bank, not a claim that its 96 entries are independent theories.

## Verified structure

- 384 distinct mathematical inputs; 96 canonical paraphrases.
- 288 nonidentity answer transports; every family has an order-sensitive composite.
- 96 construction-specific semantic-error controls, 96 reversed-order controls, and 288 canonical-copy controls rejected.
- 96 hash-bound certificate entrypoints and 288 synchronized flat files.
- 790 automated tests passed. The grader additionally accepted 480 synthetic gold responses and found 384 complete synthetic pairs consistent. These are software checks, not model evaluations.
- All 185 original-bank, 173 v2 and 4,425 calibration manifest-listed files retain their pinned bytes. Historical archive hashes also match.

## Coverage

| Area | Construction codes | Families |
|---|---|---:|
| Mechanics and boundary response | RBG, DRC, HDV | 12 |
| Local analysis and singular response | RIC, DYS, IMP, DST | 16 |
| Measures, field theory and quantization | GBS, PFQ, RGJ, ANM, MOY | 20 |
| Gravity and differential geometry | CON, ADM, HOD | 12 |
| Gauge, lattice and topological theory | KCS, LAT, YMC | 12 |
| Quantum states and open dynamics | QIN, LDB | 8 |
| Stochastic and statistical systems | OUC, ISM | 8 |
| String compactification and graded algebra | NAR, SFT | 8 |

## Concrete data changes

The following values are recomputed from the canonical and T1 inputs; all coordinates and conventions stay fixed.

### IMR-S3-KCS-03: torus_degeneracy

Canonical: `9`. T1: `1`.

### IMR-S3-GBS-02: mean[0,0]

Canonical: `-3/19`. T1: `-5/24`.

### IMR-S3-MOY-03: quantum_at_h1

Canonical: `-15*x**4 + 60*x**2*y + 15*y**2`. T1: `-15*x**4 + 12*x**2*y**2 + 60*x**2*y + 3*x - 3*y**3 + 15*y**2 + 3/4`.

### IMR-S3-NAR-02: charge_energy

Canonical: `59/15`. T1: `209/60`.

### IMR-S3-QIN-03: purity

Canonical: `1/2`. T1: `5/9`.

### IMR-S3-LDB-02: steady_bloch[0,0]

Canonical: `6/103`. T1: `14/271`.

### IMR-S3-ISM-03: connected_01

Canonical: `1080/24649`. T1: `19440/508369`.

### IMR-S3-SFT-02: linearized_curvature[0,0]

Canonical: `3`. T1: `5`.

## Interpretation

The changed arms deliberately alter the specified problem. For example, changing an integral Chern-Simons level can change torus degeneracy, and conditioning a Gaussian is a different operation from integrating hidden coordinates. Exact differences are evidence of changed content under the fixed problem contract, not universal proofs against all possible equivalences.

No new model sessions were run. The bank is an uncalibrated candidate: neither a global hardest-problem ranking nor reduced difficulty saturation is established. Several finite calculations may remain easy for strong models. Full field theories, arbitrary topology, all physics subfields and proof-level model competence are not certified. See the precise scopes and references in DESIGN_AND_PROOFS.md and REFERENCES.md.

Every family has confirmatory_eligible=false.
