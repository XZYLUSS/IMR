# Family catalogue

96 families in 24 dependent construction clusters; five problems per family. These labels do not assert 96 independent mechanisms or measured difficulty.

| ID | Family | Domain | Entries in canonical answer |
|---|---|---|---:|
| [IMR-S3-RBG-01](families_repo/IMR-S3-RBG-01-separated-endpoints/IMR-S3-RBG-01-separated-endpoints-problem.json) | Coupled endpoint Green response / separated endpoints | boundary spectral theory | 21 |
| [IMR-S3-RBG-02](families_repo/IMR-S3-RBG-02-asymmetric-robin/IMR-S3-RBG-02-asymmetric-robin-problem.json) | Coupled endpoint Green response / asymmetric robin | boundary spectral theory | 21 |
| [IMR-S3-RBG-03](families_repo/IMR-S3-RBG-03-positive-endpoint-coupling/IMR-S3-RBG-03-positive-endpoint-coupling-problem.json) | Coupled endpoint Green response / positive endpoint coupling | boundary spectral theory | 21 |
| [IMR-S3-RBG-04](families_repo/IMR-S3-RBG-04-negative-endpoint-coupling/IMR-S3-RBG-04-negative-endpoint-coupling-problem.json) | Coupled endpoint Green response / negative endpoint coupling | boundary spectral theory | 21 |
| [IMR-S3-GBS-01](families_repo/IMR-S3-GBS-01-marginalization/IMR-S3-GBS-01-marginalization-problem.json) | Gaussian observation semantics / marginalization | statistical field theory | 23 |
| [IMR-S3-GBS-02](families_repo/IMR-S3-GBS-02-conditioning/IMR-S3-GBS-02-conditioning-problem.json) | Gaussian observation semantics / conditioning | statistical field theory | 22 |
| [IMR-S3-GBS-03](families_repo/IMR-S3-GBS-03-linear-pushforward/IMR-S3-GBS-03-linear-pushforward-problem.json) | Gaussian observation semantics / linear pushforward | statistical field theory | 22 |
| [IMR-S3-GBS-04](families_repo/IMR-S3-GBS-04-subspace-restriction/IMR-S3-GBS-04-subspace-restriction-problem.json) | Gaussian observation semantics / subspace restriction | statistical field theory | 23 |
| [IMR-S3-PFQ-01](families_repo/IMR-S3-PFQ-01-paired-majorana/IMR-S3-PFQ-01-paired-majorana-problem.json) | Oriented fermionic Gaussian / paired majorana | fermionic field theory | 38 |
| [IMR-S3-PFQ-02](families_repo/IMR-S3-PFQ-02-cross-sector-pairing/IMR-S3-PFQ-02-cross-sector-pairing-problem.json) | Oriented fermionic Gaussian / cross sector pairing | fermionic field theory | 38 |
| [IMR-S3-PFQ-03](families_repo/IMR-S3-PFQ-03-long-range-pairing/IMR-S3-PFQ-03-long-range-pairing-problem.json) | Oriented fermionic Gaussian / long range pairing | fermionic field theory | 38 |
| [IMR-S3-PFQ-04](families_repo/IMR-S3-PFQ-04-reversed-form/IMR-S3-PFQ-04-reversed-form-problem.json) | Oriented fermionic Gaussian / reversed form | fermionic field theory | 38 |
| [IMR-S3-DRC-01](families_repo/IMR-S3-DRC-01-canonical-pair/IMR-S3-DRC-01-canonical-pair-problem.json) | Second-class Hamiltonian reduction / canonical pair | constrained mechanics | 44 |
| [IMR-S3-DRC-02](families_repo/IMR-S3-DRC-02-mixed-position/IMR-S3-DRC-02-mixed-position-problem.json) | Second-class Hamiltonian reduction / mixed position | constrained mechanics | 44 |
| [IMR-S3-DRC-03](families_repo/IMR-S3-DRC-03-magnetic-mixed/IMR-S3-DRC-03-magnetic-mixed-problem.json) | Second-class Hamiltonian reduction / magnetic mixed | constrained mechanics | 44 |
| [IMR-S3-DRC-04](families_repo/IMR-S3-DRC-04-oblique-phase/IMR-S3-DRC-04-oblique-phase-problem.json) | Second-class Hamiltonian reduction / oblique phase | constrained mechanics | 44 |
| [IMR-S3-HDV-01](families_repo/IMR-S3-HDV-01-nondegenerate-acceleration/IMR-S3-HDV-01-nondegenerate-acceleration-problem.json) | Higher-derivative endpoint variation / nondegenerate acceleration | variational field theory | 7 |
| [IMR-S3-HDV-02](families_repo/IMR-S3-HDV-02-degenerate-acceleration/IMR-S3-HDV-02-degenerate-acceleration-problem.json) | Higher-derivative endpoint variation / degenerate acceleration | variational field theory | 7 |
| [IMR-S3-HDV-03](families_repo/IMR-S3-HDV-03-field-dependent-kinetic/IMR-S3-HDV-03-field-dependent-kinetic-problem.json) | Higher-derivative endpoint variation / field dependent kinetic | variational field theory | 7 |
| [IMR-S3-HDV-04](families_repo/IMR-S3-HDV-04-boundary-functional/IMR-S3-HDV-04-boundary-functional-problem.json) | Higher-derivative endpoint variation / boundary functional | variational field theory | 7 |
| [IMR-S3-RIC-01](families_repo/IMR-S3-RIC-01-positive-initial/IMR-S3-RIC-01-positive-initial-problem.json) | Riccati branch and response jet / positive initial | spectral analysis | 10 |
| [IMR-S3-RIC-02](families_repo/IMR-S3-RIC-02-even-potential/IMR-S3-RIC-02-even-potential-problem.json) | Riccati branch and response jet / even potential | spectral analysis | 10 |
| [IMR-S3-RIC-03](families_repo/IMR-S3-RIC-03-zero-leading-potential/IMR-S3-RIC-03-zero-leading-potential-problem.json) | Riccati branch and response jet / zero leading potential | spectral analysis | 10 |
| [IMR-S3-RIC-04](families_repo/IMR-S3-RIC-04-negative-leading-potential/IMR-S3-RIC-04-negative-leading-potential-problem.json) | Riccati branch and response jet / negative leading potential | spectral analysis | 10 |
| [IMR-S3-DYS-01](families_repo/IMR-S3-DYS-01-linear-drive/IMR-S3-DYS-01-linear-drive-problem.json) | Ordered evolution jet / linear drive | non-Abelian dynamics | 21 |
| [IMR-S3-DYS-02](families_repo/IMR-S3-DYS-02-delayed-drive/IMR-S3-DYS-02-delayed-drive-problem.json) | Ordered evolution jet / delayed drive | non-Abelian dynamics | 21 |
| [IMR-S3-DYS-03](families_repo/IMR-S3-DYS-03-sign-reversing-drive/IMR-S3-DYS-03-sign-reversing-drive-problem.json) | Ordered evolution jet / sign reversing drive | non-Abelian dynamics | 21 |
| [IMR-S3-DYS-04](families_repo/IMR-S3-DYS-04-commutator-feedback/IMR-S3-DYS-04-commutator-feedback-problem.json) | Ordered evolution jet / commutator feedback | non-Abelian dynamics | 21 |
| [IMR-S3-IMP-01](families_repo/IMR-S3-IMP-01-mixed-nonlinearity/IMR-S3-IMP-01-mixed-nonlinearity-problem.json) | Inverse equation of state / mixed nonlinearity | critical phenomena | 10 |
| [IMR-S3-IMP-02](families_repo/IMR-S3-IMP-02-odd-symmetry/IMR-S3-IMP-02-odd-symmetry-problem.json) | Inverse equation of state / odd symmetry | critical phenomena | 10 |
| [IMR-S3-IMP-03](families_repo/IMR-S3-IMP-03-competing-signs/IMR-S3-IMP-03-competing-signs-problem.json) | Inverse equation of state / competing signs | critical phenomena | 10 |
| [IMR-S3-IMP-04](families_repo/IMR-S3-IMP-04-quintic-response/IMR-S3-IMP-04-quintic-response-problem.json) | Inverse equation of state / quintic response | critical phenomena | 10 |
| [IMR-S3-DST-01](families_repo/IMR-S3-DST-01-positive-mass/IMR-S3-DST-01-positive-mass-problem.json) | Signed distributional boundary layer / positive mass | singular limits | 12 |
| [IMR-S3-DST-02](families_repo/IMR-S3-DST-02-zero-mass/IMR-S3-DST-02-zero-mass-problem.json) | Signed distributional boundary layer / zero mass | singular limits | 12 |
| [IMR-S3-DST-03](families_repo/IMR-S3-DST-03-two-cancelled-moments/IMR-S3-DST-03-two-cancelled-moments-problem.json) | Signed distributional boundary layer / two cancelled moments | singular limits | 12 |
| [IMR-S3-DST-04](families_repo/IMR-S3-DST-04-signed-cubic/IMR-S3-DST-04-signed-cubic-problem.json) | Signed distributional boundary layer / signed cubic | singular limits | 12 |
| [IMR-S3-RGJ-01](families_repo/IMR-S3-RGJ-01-linear-cubic/IMR-S3-RGJ-01-linear-cubic-problem.json) | Renormalization flow jet / linear cubic | renormalization group | 2 |
| [IMR-S3-RGJ-02](families_repo/IMR-S3-RGJ-02-marginal-quadratic/IMR-S3-RGJ-02-marginal-quadratic-problem.json) | Renormalization flow jet / marginal quadratic | renormalization group | 2 |
| [IMR-S3-RGJ-03](families_repo/IMR-S3-RGJ-03-odd-cubic/IMR-S3-RGJ-03-odd-cubic-problem.json) | Renormalization flow jet / odd cubic | renormalization group | 2 |
| [IMR-S3-RGJ-04](families_repo/IMR-S3-RGJ-04-competing-fixed-points/IMR-S3-RGJ-04-competing-fixed-points-problem.json) | Renormalization flow jet / competing fixed points | renormalization group | 2 |
| [IMR-S3-ANM-01](families_repo/IMR-S3-ANM-01-mixed-chirality/IMR-S3-ANM-01-mixed-chirality-problem.json) | Two-factor anomaly polynomial / mixed chirality | quantum anomalies | 8 |
| [IMR-S3-ANM-02](families_repo/IMR-S3-ANM-02-charged-multiplets/IMR-S3-ANM-02-charged-multiplets-problem.json) | Two-factor anomaly polynomial / charged multiplets | quantum anomalies | 8 |
| [IMR-S3-ANM-03](families_repo/IMR-S3-ANM-03-vectorlike-plus-chiral/IMR-S3-ANM-03-vectorlike-plus-chiral-problem.json) | Two-factor anomaly polynomial / vectorlike plus chiral | quantum anomalies | 8 |
| [IMR-S3-ANM-04](families_repo/IMR-S3-ANM-04-mixed-multiplicity/IMR-S3-ANM-04-mixed-multiplicity-problem.json) | Two-factor anomaly polynomial / mixed multiplicity | quantum anomalies | 8 |
| [IMR-S3-MOY-01](families_repo/IMR-S3-MOY-01-mixed-quintic/IMR-S3-MOY-01-mixed-quintic-problem.json) | Weyl commutator and Moyal corrections / mixed quintic | quantum phase space | 3 |
| [IMR-S3-MOY-02](families_repo/IMR-S3-MOY-02-quartic-even/IMR-S3-MOY-02-quartic-even-problem.json) | Weyl commutator and Moyal corrections / quartic even | quantum phase space | 3 |
| [IMR-S3-MOY-03](families_repo/IMR-S3-MOY-03-pure-quintic/IMR-S3-MOY-03-pure-quintic-problem.json) | Weyl commutator and Moyal corrections / pure quintic | quantum phase space | 3 |
| [IMR-S3-MOY-04](families_repo/IMR-S3-MOY-04-asymmetric-mixed/IMR-S3-MOY-04-asymmetric-mixed-problem.json) | Weyl commutator and Moyal corrections / asymmetric mixed | quantum phase space | 3 |
| [IMR-S3-CON-01](families_repo/IMR-S3-CON-01-euclidean-quadratic/IMR-S3-CON-01-euclidean-quadratic-problem.json) | Conformal Ricci curvature / euclidean quadratic | general relativity | 22 |
| [IMR-S3-CON-02](families_repo/IMR-S3-CON-02-lorentzian-quadratic/IMR-S3-CON-02-lorentzian-quadratic-problem.json) | Conformal Ricci curvature / lorentzian quadratic | general relativity | 22 |
| [IMR-S3-CON-03](families_repo/IMR-S3-CON-03-euclidean-cubic/IMR-S3-CON-03-euclidean-cubic-problem.json) | Conformal Ricci curvature / euclidean cubic | general relativity | 22 |
| [IMR-S3-CON-04](families_repo/IMR-S3-CON-04-lorentzian-cubic/IMR-S3-CON-04-lorentzian-cubic-problem.json) | Conformal Ricci curvature / lorentzian cubic | general relativity | 22 |
| [IMR-S3-ADM-01](families_repo/IMR-S3-ADM-01-orthonormal-slice/IMR-S3-ADM-01-orthonormal-slice-problem.json) | Extrinsic Einstein constraints / orthonormal slice | general relativity | 13 |
| [IMR-S3-ADM-02](families_repo/IMR-S3-ADM-02-anisotropic-slice/IMR-S3-ADM-02-anisotropic-slice-problem.json) | Extrinsic Einstein constraints / anisotropic slice | general relativity | 13 |
| [IMR-S3-ADM-03](families_repo/IMR-S3-ADM-03-oblique-slice/IMR-S3-ADM-03-oblique-slice-problem.json) | Extrinsic Einstein constraints / oblique slice | general relativity | 13 |
| [IMR-S3-ADM-04](families_repo/IMR-S3-ADM-04-mixed-shear/IMR-S3-ADM-04-mixed-shear-problem.json) | Extrinsic Einstein constraints / mixed shear | general relativity | 13 |
| [IMR-S3-HOD-01](families_repo/IMR-S3-HOD-01-lorentz-positive/IMR-S3-HOD-01-lorentz-positive-problem.json) | Hodge dual and electromagnetic stress / lorentz positive | differential geometry | 34 |
| [IMR-S3-HOD-02](families_repo/IMR-S3-HOD-02-lorentz-negative/IMR-S3-HOD-02-lorentz-negative-problem.json) | Hodge dual and electromagnetic stress / lorentz negative | differential geometry | 34 |
| [IMR-S3-HOD-03](families_repo/IMR-S3-HOD-03-euclid-positive/IMR-S3-HOD-03-euclid-positive-problem.json) | Hodge dual and electromagnetic stress / euclid positive | differential geometry | 34 |
| [IMR-S3-HOD-04](families_repo/IMR-S3-HOD-04-euclid-negative/IMR-S3-HOD-04-euclid-negative-problem.json) | Hodge dual and electromagnetic stress / euclid negative | differential geometry | 34 |
| [IMR-S3-KCS-01](families_repo/IMR-S3-KCS-01-bosonic-positive/IMR-S3-KCS-01-bosonic-positive-problem.json) | Chern-Simons response and spin / bosonic positive | topological phases | 7 |
| [IMR-S3-KCS-02](families_repo/IMR-S3-KCS-02-fermionic-positive/IMR-S3-KCS-02-fermionic-positive-problem.json) | Chern-Simons response and spin / fermionic positive | topological phases | 7 |
| [IMR-S3-KCS-03](families_repo/IMR-S3-KCS-03-bosonic-indefinite/IMR-S3-KCS-03-bosonic-indefinite-problem.json) | Chern-Simons response and spin / bosonic indefinite | topological phases | 7 |
| [IMR-S3-KCS-04](families_repo/IMR-S3-KCS-04-fermionic-indefinite/IMR-S3-KCS-04-fermionic-indefinite-problem.json) | Chern-Simons response and spin / fermionic indefinite | topological phases | 7 |
| [IMR-S3-LAT-01](families_repo/IMR-S3-LAT-01-open-chain/IMR-S3-LAT-01-open-chain-problem.json) | Lattice closure and Green response / open chain | lattice field theory | 21 |
| [IMR-S3-LAT-02](families_repo/IMR-S3-LAT-02-endpoint-defect/IMR-S3-LAT-02-endpoint-defect-problem.json) | Lattice closure and Green response / endpoint defect | lattice field theory | 21 |
| [IMR-S3-LAT-03](families_repo/IMR-S3-LAT-03-periodic-closure/IMR-S3-LAT-03-periodic-closure-problem.json) | Lattice closure and Green response / periodic closure | lattice field theory | 21 |
| [IMR-S3-LAT-04](families_repo/IMR-S3-LAT-04-antiperiodic-closure/IMR-S3-LAT-04-antiperiodic-closure-problem.json) | Lattice closure and Green response / antiperiodic closure | lattice field theory | 21 |
| [IMR-S3-YMC-01](families_repo/IMR-S3-YMC-01-triangular/IMR-S3-YMC-01-triangular-problem.json) | Constant non-Abelian curvature / triangular | gauge geometry | 13 |
| [IMR-S3-YMC-02](families_repo/IMR-S3-YMC-02-first-deformed/IMR-S3-YMC-02-first-deformed-problem.json) | Constant non-Abelian curvature / first deformed | gauge geometry | 13 |
| [IMR-S3-YMC-03](families_repo/IMR-S3-YMC-03-second-deformed/IMR-S3-YMC-03-second-deformed-problem.json) | Constant non-Abelian curvature / second deformed | gauge geometry | 13 |
| [IMR-S3-YMC-04](families_repo/IMR-S3-YMC-04-mixed-real/IMR-S3-YMC-04-mixed-real-problem.json) | Constant non-Abelian curvature / mixed real | gauge geometry | 13 |
| [IMR-S3-QIN-01](families_repo/IMR-S3-QIN-01-rank-three-a/IMR-S3-QIN-01-rank-three-a-problem.json) | Selective bipartite filtering / rank three a | quantum information | 20 |
| [IMR-S3-QIN-02](families_repo/IMR-S3-QIN-02-rank-three-b/IMR-S3-QIN-02-rank-three-b-problem.json) | Selective bipartite filtering / rank three b | quantum information | 20 |
| [IMR-S3-QIN-03](families_repo/IMR-S3-QIN-03-rank-two/IMR-S3-QIN-03-rank-two-problem.json) | Selective bipartite filtering / rank two | quantum information | 20 |
| [IMR-S3-QIN-04](families_repo/IMR-S3-QIN-04-pure-entangled/IMR-S3-QIN-04-pure-entangled-problem.json) | Selective bipartite filtering / pure entangled | quantum information | 20 |
| [IMR-S3-LDB-01](families_repo/IMR-S3-LDB-01-transverse-drive/IMR-S3-LDB-01-transverse-drive-problem.json) | Dissipative qubit response / transverse drive | open quantum systems | 14 |
| [IMR-S3-LDB-02](families_repo/IMR-S3-LDB-02-strong-dephasing/IMR-S3-LDB-02-strong-dephasing-problem.json) | Dissipative qubit response / strong dephasing | open quantum systems | 14 |
| [IMR-S3-LDB-03](families_repo/IMR-S3-LDB-03-inverted-bias/IMR-S3-LDB-03-inverted-bias-problem.json) | Dissipative qubit response / inverted bias | open quantum systems | 14 |
| [IMR-S3-LDB-04](families_repo/IMR-S3-LDB-04-three-axis-drive/IMR-S3-LDB-04-three-axis-drive-problem.json) | Dissipative qubit response / three axis drive | open quantum systems | 14 |
| [IMR-S3-OUC-01](families_repo/IMR-S3-OUC-01-rotating-drift/IMR-S3-OUC-01-rotating-drift-problem.json) | Nonequilibrium Gaussian current / rotating drift | stochastic physics | 19 |
| [IMR-S3-OUC-02](families_repo/IMR-S3-OUC-02-jordan-drift/IMR-S3-OUC-02-jordan-drift-problem.json) | Nonequilibrium Gaussian current / jordan drift | stochastic physics | 19 |
| [IMR-S3-OUC-03](families_repo/IMR-S3-OUC-03-asymmetric-circulation/IMR-S3-OUC-03-asymmetric-circulation-problem.json) | Nonequilibrium Gaussian current / asymmetric circulation | stochastic physics | 19 |
| [IMR-S3-OUC-04](families_repo/IMR-S3-OUC-04-three-axis-circulation/IMR-S3-OUC-04-three-axis-circulation-problem.json) | Nonequilibrium Gaussian current / three axis circulation | stochastic physics | 19 |
| [IMR-S3-ISM-01](families_repo/IMR-S3-ISM-01-open-ferromagnet/IMR-S3-ISM-01-open-ferromagnet-problem.json) | Connected spin cumulants / open ferromagnet | statistical mechanics | 11 |
| [IMR-S3-ISM-02](families_repo/IMR-S3-ISM-02-closed-ferromagnet/IMR-S3-ISM-02-closed-ferromagnet-problem.json) | Connected spin cumulants / closed ferromagnet | statistical mechanics | 11 |
| [IMR-S3-ISM-03](families_repo/IMR-S3-ISM-03-single-frustrated-bond/IMR-S3-ISM-03-single-frustrated-bond-problem.json) | Connected spin cumulants / single frustrated bond | statistical mechanics | 11 |
| [IMR-S3-ISM-04](families_repo/IMR-S3-ISM-04-frustrated-triangle/IMR-S3-ISM-04-frustrated-triangle-problem.json) | Connected spin cumulants / frustrated triangle | statistical mechanics | 11 |
| [IMR-S3-NAR-01](families_repo/IMR-S3-NAR-01-rectangular-zero-b/IMR-S3-NAR-01-rectangular-zero-b-problem.json) | Fixed-charge torus energy / rectangular zero b | string compactification | 18 |
| [IMR-S3-NAR-02](families_repo/IMR-S3-NAR-02-oblique-positive-b/IMR-S3-NAR-02-oblique-positive-b-problem.json) | Fixed-charge torus energy / oblique positive b | string compactification | 18 |
| [IMR-S3-NAR-03](families_repo/IMR-S3-NAR-03-oblique-negative-b/IMR-S3-NAR-03-oblique-negative-b-problem.json) | Fixed-charge torus energy / oblique negative b | string compactification | 18 |
| [IMR-S3-NAR-04](families_repo/IMR-S3-NAR-04-rational-radii/IMR-S3-NAR-04-rational-radii-problem.json) | Fixed-charge torus energy / rational radii | string compactification | 18 |
| [IMR-S3-SFT-01](families_repo/IMR-S3-SFT-01-diagonal-lower/IMR-S3-SFT-01-diagonal-lower-problem.json) | Graded Maurer-Cartan curvature / diagonal lower | string field algebra | 48 |
| [IMR-S3-SFT-02](families_repo/IMR-S3-SFT-02-triangular-blocks/IMR-S3-SFT-02-triangular-blocks-problem.json) | Graded Maurer-Cartan curvature / triangular blocks | string field algebra | 48 |
| [IMR-S3-SFT-03](families_repo/IMR-S3-SFT-03-rotating-upper/IMR-S3-SFT-03-rotating-upper-problem.json) | Graded Maurer-Cartan curvature / rotating upper | string field algebra | 48 |
| [IMR-S3-SFT-04](families_repo/IMR-S3-SFT-04-mixed-blocks/IMR-S3-SFT-04-mixed-blocks-problem.json) | Graded Maurer-Cartan curvature / mixed blocks | string field algebra | 48 |
