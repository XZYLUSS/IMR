from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parent
EXCLUDE={'__pycache__','.pytest_cache','.DS_Store','MANIFEST.sha256'}
def eligible():return sorted(p for p in ROOT.rglob('*') if p.is_file() and not any(v in EXCLUDE for v in p.relative_to(ROOT).parts))
if __name__=='__main__':
    if (ROOT/'MANIFEST.sha256').exists():raise RuntimeError('Already frozen; create a new version.')
    files=eligible();(ROOT/'MANIFEST.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files));print('FROZEN',len(files))
