"""Human-readable statements, transcribed from the frozen public prompt contracts.

Each pair is (setup, requested quantities). No solver or answer data is imported.
"""
STATEMENTS = {
'RBG': (r'''Consider four labelled real coordinates $u=(u_0,u_1,u_2,u_3)^{\mathsf T}$ and the finite quadratic action
\[
 S(u)=\tfrac12 u^{\mathsf T}Xu-j^{\mathsf T}u.
\]
The stiffness matrix $X$ includes every endpoint coupling; $j$ is the source. The displayed finite matrix specifies the entire problem. No continuum limit is assumed.''',
r'''Determine the Green matrix $G$, the response column $Gj$, and the operator determinant $\det X$.'''),
'LAT': (r'''Consider four labelled lattice sites. The displayed matrix $X$ is the complete finite Euclidean lattice operator, including its masses and all closure or endpoint terms. The column $j$ is the source. Distinct closure sectors must remain distinct.''',
r'''Determine the Green matrix $G$ of $X$, the response column $Gj$, and the operator determinant $\det X$.'''),
'GBS': (r'''Let $u=(u_0,u_1,u_2,u_3)^{\mathsf T}\in\mathbb R^4$ have Gaussian density proportional to
\[
 \exp\!\left(-\tfrac12u^{\mathsf T}Xu+j^{\mathsf T}u\right).
\]
Use the observation operation specified below. Marginalization, conditioning, linear observation and restriction to a subspace are different operations.''',
r'''Determine the full $4\times4$ covariance of $u$ before observation, together with all the quantities requested for the specified observation operation below.'''),
'PFQ': (r'''Let $X$ be the displayed invertible antisymmetric $6\times6$ fermionic form. Fix the Grassmann orientation by defining
\[
 Z=[\theta_0\theta_1\cdots\theta_5]\,
 \exp\!\left(\sum_{0\leq i<j\leq5}X_{ij}\theta_i\theta_j\right),
\]
where the bracket extracts the coefficient in the displayed order of the Grassmann generators.''',
r'''Determine the algebraic inverse $X^{-1}$, the oriented Pfaffian $Z$, and $Z^2$. The inverse is an algebraic matrix inverse: no additional two-point-function sign convention is to be introduced. Retain the specified Grassmann ordering.'''),
'DRC': (r'''In phase-space coordinates $u=(q_0,q_1,p_0,p_1)^{\mathsf T}$, use the canonical Poisson matrix
\[
 J=\begin{pmatrix}0&I_2\\-I_2&0\end{pmatrix},\qquad
 Cu=0,\qquad H(u)=\tfrac12u^{\mathsf T}Xu.
\]
The two linear constraints $Cu=0$ are second class.''',
r'''Determine the $4\times4$ Dirac bracket matrix $J_D$ and the $4\times4$ matrix $M$ of the corresponding linear Hamiltonian flow $\dot u=Mu$. Also determine $CJ_D$ and the column $(a_3,a_2,a_1,a_0)^{\mathsf T}$ defined by
\[
 \det(\lambda I_4-M)=\lambda^4+a_3\lambda^3+a_2\lambda^2+a_1\lambda+a_0.
\]'''),
'HDV': (r'''The displayed autonomous polynomial is a Lagrangian $L(q_0,q_1,v_0,v_1,a_0,a_1)$. Treat all jet coordinates as independent, with total derivative $D$ specified by
\[
 Dq_i=v_i,\quad Dv_i=a_i,\quad Da_i=j_i,\quad Dj_i=k_i
 \qquad(i=0,1).
\]
Work off shell, impose no endpoint restrictions, and do not discard total derivatives before varying.''',
r'''Determine the two-component columns $E,P,R$ in the variational identity
\[
 \delta L=E^{\mathsf T}\delta q+
 D\!\left(P^{\mathsf T}\delta q+R^{\mathsf T}\delta v\right).
\]
Here $E$ is the Euler--Lagrange column, $P$ the momentum column, and $R$ the acceleration-momentum column. Determine also the Ostrogradsky energy
\[
 H_{\mathrm O}=P^{\mathsf T}v+R^{\mathsf T}a-L.
\]'''),
'RIC': (r'''Consider the local initial-value problem
\[
 \psi''(t)=V(t)\psi(t),\qquad \psi(0)=1,\qquad \psi'(0)=\alpha.
\]
The polynomial $V$ and initial value $\alpha$ are specified below. Define the logarithmic derivative $u=\psi'/\psi$. Only a local Taylor jet is requested.''',
r'''Determine $(c_1,\ldots,c_5)^{\mathsf T}$ in
\[
 u(t)=\alpha+\sum_{k=1}^{5}c_kt^k+O(t^6).
\]
Also give, in ascending order, the coefficients of $t^0,t^1,\ldots,t^4$ in $u'+u^2-V$, using consistent truncation.'''),
'DYS': (r'''Let $U(t)$ be a $2\times2$ matrix satisfying
\[
 U'(t)=A(t)U(t),\qquad U(0)=I_2,\qquad
 A(t)=A_0+A_1t+A_2t^2+A_3t^3.
\]
The generator multiplies on the \emph{left}. The matrices need not commute and need not be anti-Hermitian.''',
r'''Determine the ordered list $(U_1,U_2,U_3,U_4)$ in
\[
 U(t)=I_2+\sum_{k=1}^{4}U_kt^k+O(t^5).
\]
Also determine the five coefficients of $\det U(t)$ through order $t^4$, listed in ascending powers $t^0,\ldots,t^4$.'''),
'IMP': (r'''The displayed dimensionless equation of state is $h=\phi(r)$, with $\phi(0)=0$ and $\phi'(0)=1$. Select the formal inverse branch satisfying $r(0)=0$. No global inverse is requested.''',
r'''Determine $(c_2,\ldots,c_6)^{\mathsf T}$ in
\[
 r(h)=h+\sum_{k=2}^{6}c_kh^k+O(h^7).
\]
Also determine the five coefficients of the susceptibility $dr/dh$ at powers $h^1,\ldots,h^5$, in ascending order, excluding its constant term $1$.'''),
'DST': (r'''For $n>0$ and $x\geq0$, define
\[
 f_n(x)=n e^{-nx}P(nx),
\]
where the polynomial profile $P(t)$ is specified below. Test functions are arbitrary $\varphi\in C_c^\infty(\mathbb R)$. Signed profiles are allowed. The endpoint delta has full weight; no half-weight convention is used.''',
r'''Determine $(c_0,\ldots,c_5)^{\mathsf T}$ in the asymptotic expansion
\[
 \int_0^\infty f_n(x)\varphi(x)\,dx
 =\sum_{k=0}^{5}c_kn^{-k}\varphi^{(k)}(0)+O(n^{-6})
 \quad(n\to\infty).
\]
Also determine $(d_0,\ldots,d_5)^{\mathsf T}$ in the corresponding distributional expansion $\sum_{k=0}^{5}d_kn^{-k}\delta^{(k)}$, using
\[
 \langle\delta^{(k)},\varphi\rangle=(-1)^k\varphi^{(k)}(0).
\]'''),
'RGJ': (r'''At a fixed dimensionless coupling convention, let the formal renormalization flow satisfy
\[
 \frac{d g(t)}{dt}=\beta(g(t)),\qquad g(0)=g,
\]
where $t$ is logarithmic scale and $\beta$ is specified below. This is a formal flow problem; no microscopic quantum-field-theory derivation of $\beta$ is requested.''',
r'''Determine the coefficient polynomials $A(g)$ and $B(g)$ in
\[
 g(t)=g+\beta(g)t+A(g)t^2+B(g)t^3+O(t^4).
\]'''),
'ANM': (r'''Each row of the species table specifies a four-dimensional Weyl species by its signed multiplicity $\chi$, spectator dimension $d$, and charges $(q_1,q_2)$. The sign of $\chi$ distinguishes chirality. The dimensionless commuting symbols $F_1,F_2$ have form degree $2$ and $p_1$ has degree $4$. Use exactly the normalization
\[
 I_6=\left[\sum_{\text{species}}\chi d\,
 e^{q_1F_1+q_2F_2}\left(1-\frac{p_1}{24}\right)\right]_{\text{form degree }6}.
\]
Global anomalies are outside this calculation.''',
r'''Determine the six coefficients of $I_6$ in the ordered monomial basis
\[
 (F_1^3,\ F_1^2F_2,\ F_1F_2^2,\ F_2^3,\ p_1F_1,\ p_1F_2).
\]
Also evaluate the pure cubic polynomial at $(F_1,F_2)=(1,2)$ and evaluate the coefficient of $p_1$ at the same point.'''),
'MOY': (r'''Let $x,y$ be canonical phase-space coordinates, with $[\widehat x,\widehat y]=ih$, and use Weyl ordering. For the displayed polynomials $f(x,y)$ and $b(x,y)$, the star product is
\[
 f\star b=f\exp\!\left[\frac{ih}{2}
 \left(\overleftarrow\partial_x\overrightarrow\partial_y-
 \overleftarrow\partial_y\overrightarrow\partial_x\right)\right]b.
\]
The expansion terminates for these polynomials. The output variables $x,y,h$ commute.''',
r'''Determine the exact Weyl symbol $C(x,y,h)$ of $[\widehat f,\widehat b]/(ih)$. Also give its classical value $C(x,y,0)$ and the quantum correction $C(x,y,1)-C(x,y,0)$.'''),
'CON': (r'''On coordinates $(x,y,z)$, let $g_{ij}=e^{2\phi}\eta_{ij}$, where $\phi$ and the constant metric $\eta$ are specified below. Adopt
\[
 \begin{aligned}
 R^r{}_{s mn}&=\partial_m\Gamma^r{}_{ns}-\partial_n\Gamma^r{}_{ms}\\
 &\quad+\Gamma^r{}_{m\ell}\Gamma^\ell{}_{ns}
       -\Gamma^r{}_{n\ell}\Gamma^\ell{}_{ms},\\
 R_{sn}&=R^r{}_{s rn}.
 \end{aligned}
\]
Respect the signature of the displayed metric.''',
r'''Determine the ordinary coordinate gradient and Hessian of $\phi$, the lower-index Ricci matrix $(R_{ij})$, and $e^{2\phi}R$, where $R=g^{ij}R_{ij}$.'''),
'ADM': (r'''On a flat three-dimensional slice with coordinates $(x,y,z)$ and constant positive metric $\gamma$, let the displayed lower-index matrix $K=(K_{ij})$ be the extrinsic curvature. Define
\[
 P_{ij}=K_{ij}-\gamma_{ij}\operatorname{tr}_{\gamma}K,
 \qquad \operatorname{tr}_{\gamma}K=\gamma^{ij}K_{ij}.
\]
There is no density factor in $P$.''',
r'''Determine $P$ and the constraint left sides
\[
 \mathcal H=(\operatorname{tr}_{\gamma}K)^2-K_{ij}K^{ij},
 \qquad \mathcal M_i=\nabla^jP_{ji}.
\]
Raise indices and take the covariant derivative with $\gamma$. Give $\mathcal M$ as a three-component column. The constraints are not assumed to vanish.'''),
'HOD': (r'''The displayed antisymmetric matrix $F=(F_{ij})$ is a lower-index two-form. The diagonal four-metric $\eta$ satisfies $|\det\eta|=1$. Fix the orientation by the displayed value of $\epsilon_{0123}$ and define
\[
 (*F)_{ij}=\tfrac12\epsilon_{ijkl}\eta^{ka}\eta^{lb}F_{ab}.
\]
All indices range from $0$ to $3$ and are raised using $\eta$.''',
r'''Determine the Hodge dual $*F$, the contractions $F_{ij}F^{ij}$ and $F_{ij}(*F)^{ij}$, and the stress matrix
\[
 T_{ij}=F_{ik}\eta^{k\ell}F_{j\ell}
       -\tfrac14\eta_{ij}F_{ab}F^{ab}.
\]
Use this displayed algebraic stress convention in Euclidean signature as well.'''),
'KCS': (r'''Consider the integral, nondegenerate, symmetric Abelian level matrix $K$ with Chern--Simons action
\[
 S=\frac{1}{4\pi}\int K_{IJ}\,a_I\wedge da_J.
\]
Keep the displayed charge vector $t$ and anyon vector $\ell$ fixed. Odd diagonal levels require a spin theory; indefinite levels are permitted.''',
r'''Determine $K^{-1}$, the Hall response $\nu=t^{\mathsf T}K^{-1}t$, twice the spin $2s=\ell^{\mathsf T}K^{-1}\ell$, and the torus degeneracy $|\det K|$. Give $2s$ as an exact rational number, without reducing it modulo integers.'''),
'YMC': (r'''Let $A_0,A_1$ be the displayed constant traceless real connection matrices, with covariant derivatives $D_i=\partial_i+A_i$. No compact anti-Hermitian convention and no Yang--Mills equation of motion is imposed.''',
r'''Determine the curvature matrix $F_{01}=[D_0,D_1]$, its covariant derivatives $D_0F_{01}$ and $D_1F_{01}$ in the adjoint representation, and $\operatorname{tr}(F_{01}^{\,2})$.'''),
'QIN': (r'''The columns $w_a$ of the displayed matrix $W$ are unnormalized preparation amplitudes in the ordered basis
\[
 (|00\rangle,|01\rangle,|10\rangle,|11\rangle).
\]
The column label is classical and incoherent. Thus the unnormalized density matrix is $\widetilde\rho=\sum_a|w_a\rangle\langle w_a|$, not the projector onto a coherent sum of columns.''',
r'''Determine $\widetilde\rho$, its weight $Z=\operatorname{tr}\widetilde\rho$, the purity of the normalized state $\rho=\widetilde\rho/Z$, and the purity of the first-qubit reduced state $\rho_A=\operatorname{tr}_B\rho$. Also determine $\det(\rho^{T_B})$, with the partial transpose taken on the \emph{second} qubit of the normalized state.'''),
'LDB': (r'''With $\hbar=1$ and the standard Pauli matrices, the master equation is
\[
 \mathcal L(\rho)=-i[H,\rho]+\sum_a\gamma_a
 \left(L_a\rho L_a^\dagger-\tfrac12\{L_a^\dagger L_a,\rho\}\right).
\]
For $\rho=(I_2+\boldsymbol r\cdot\boldsymbol\sigma)/2$, write $\dot{\boldsymbol r}=A\boldsymbol r+c$. The displayed $A,c$ are consistent with the supplied Hamiltonian, rates and jump operators.''',
r'''Determine $A^{-1}$, the stationary Bloch column $\boldsymbol r_{\mathrm{ss}}$, the density-matrix purity of that stationary state, and $\det A$.'''),
'OUC': (r'''Consider a stable linear diffusion on $\mathbb R^3$ with drift matrix $B$ and noise covariance $N$. All coordinates are even under time reversal, and the Boltzmann constant is $1$. The Fokker--Planck diffusion matrix is $D=N/2$. For stationary covariance $\Sigma$, let $\rho$ be the normalized stationary Gaussian and write its probability current as
\[
 J(x)=(B+D\Sigma^{-1})x\,\rho(x).
\]
Do not assume detailed balance or matrix commutation.''',
r'''Determine $\Sigma$, the stationary-current matrix $B\Sigma-\Sigma B^{\mathsf T}$, and the entropy production
\[
 \dot S_{\mathrm{prod}}=\int_{\mathbb R^3}
 \frac{J(x)^{\mathsf T}D^{-1}J(x)}{\rho(x)}\,d^3x.
\]'''),
'ISM': (r'''The table specifies a finite ensemble of three spins $(s_0,s_1,s_2)\in\{-1,+1\}^3$ with positive unnormalized weights $w(s)$. Define Walsh moments by
\[
 M_m=\sum_s w(s)\prod_{i:\,\operatorname{bit}_i(m)=1}s_i,
 \qquad m=0,\ldots,7,
\]
where site $0$ is the least significant bit. Empty products equal $1$, and expectation values use the normalized weights.''',
r'''Determine the eight-component column $(M_0,\ldots,M_7)^{\mathsf T}$, the mean $\langle s_0\rangle$, the connected correlator $\langle s_0s_1\rangle-\langle s_0\rangle\langle s_1\rangle$, and the third joint cumulant of all three spins, $\langle s_0s_1s_2\rangle_c$.'''),
'NAR': (r'''On a two-torus with target metric $G$ and antisymmetric $B$, use the zero-mode energy
\[
 E(n,w)=(n-Bw)^{\mathsf T}G^{-1}(n-Bw)+w^{\mathsf T}Gw.
\]
The integer charge is ordered as $q=(n_0,n_1,w_0,w_1)^{\mathsf T}$. Oscillators and intercepts are excluded, and charges are kept fixed rather than relabelled by a duality.''',
r'''Determine the symmetric $4\times4$ matrix $\mathcal H$ representing this quadratic form on arbitrary charges in the specified order, $E(q)=q^{\mathsf T}\mathcal H q$. Also determine the energy of the displayed charge and the level pairing $n^{\mathsf T}w$.'''),
'SFT': (r'''Use the $\mathbb Z_2$-graded real $4\times4$ matrix algebra: the first two basis vectors are even and the last two are odd. The displayed matrix $D$ is odd and obeys $D^2=0$. On homogeneous matrices define
\[
 Q(A)=DA-(-1)^{|A|}AD.
\]
The field $\Psi$ and variation $V$ are odd. This finite graded algebra models a mechanism of cubic open string field theory; it is not its full infinite state space or a closed-string $L_\infty$ algebra.''',
r'''Determine the curvature $F(\Psi)=Q(\Psi)+\Psi^2$, the linearized curvature
\[
 \left.\frac{d}{ds}F(\Psi+sV)\right|_{s=0},
\]
and the Bianchi expression $Q(F)+\Psi F-F\Psi$.'''),
}

OBSERVATION = {
'marginal': r'''\textbf{Observation: marginalization.} Integrate over $u_2,u_3$ and observe $z=(u_0,u_1)^{\mathsf T}$. Determine its $2\times2$ effective precision, its two-component mean, and the determinant of the hidden block $X_{hh}$ with row and column indices $(2,3)$.''',
'conditional': r'''\textbf{Observation: conditioning.} Fix $(u_2,u_3)^{\mathsf T}=v_h$ to the displayed column. Determine the $2\times2$ effective precision and two-component mean of $(u_0,u_1)^{\mathsf T}$ under this conditional distribution.''',
'pushforward': r'''\textbf{Observation: linear pushforward.} Observe $z=Mu$ using the displayed $2\times4$ map $M$. Determine the $2\times2$ effective precision and two-component mean of $z$.''',
'restriction': r'''\textbf{Observation: subspace restriction.} Set $u=Mz$ using the displayed $4\times2$ map $M$ and use the induced Euclidean measure on this subspace. Determine the $2\times2$ effective precision and two-component mean of $z$, and the squared Jacobian of the induced measure relative to $dz$.''',
}

# Exact public-schema keys covered by the requested-quantity prose above.
OUTPUT_KEYS = {
'RBG': ['state','observables.response','observables.operator_determinant'],
'LAT': ['state','observables.response','observables.operator_determinant'],
'GBS': ['state','observables.effective_precision','observables.mean'],
'PFQ': ['state','observables.pfaffian','observables.partition_squared'],
'DRC': ['state.bracket','state.flow','observables.flow_characteristic','observables.constraint_annihilation'],
'HDV': ['state.euler','state.momentum','state.acceleration_momentum','observables.ostrogradsky_energy'],
'RIC': ['state','observables.residual_coefficients'],
'DYS': ['state','observables.determinant_jet'],
'IMP': ['state','observables.susceptibility_jet'],
'DST': ['state','observables.delta_derivative_coefficients'],
'RGJ': ['state','observables.time_order_three'],
'ANM': ['state','observables.cubic_at_1_2','observables.mixed_at_1_2'],
'MOY': ['state','observables.classical','observables.quantum_at_h1'],
'CON': ['state.gradient','state.hessian','observables.ricci','observables.scalar_times_exp_2phi'],
'ADM': ['state','observables.hamiltonian_constraint','observables.momentum_constraint'],
'HOD': ['state','observables.F_contraction','observables.dual_contraction','observables.stress'],
'KCS': ['state','observables.hall','observables.spin_times_two','observables.torus_degeneracy'],
'YMC': ['state','observables.covariant_derivative_0','observables.covariant_derivative_1','observables.curvature_trace_squared'],
'QIN': ['state','observables.weight','observables.purity','observables.reduced_purity','observables.partial_transpose_determinant'],
'LDB': ['state','observables.steady_bloch','observables.purity','observables.generator_determinant'],
'OUC': ['state','observables.stationary_current','observables.entropy_production'],
'ISM': ['state','observables.mean_0','observables.connected_01','observables.connected_012'],
'NAR': ['state','observables.charge_energy','observables.level_pairing'],
'SFT': ['state','observables.linearized_curvature','observables.bianchi'],
}
