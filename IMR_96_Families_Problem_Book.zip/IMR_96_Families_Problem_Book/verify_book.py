#!/usr/bin/env python3
"""Check public-source coverage, final PDF structure, and physical page bounds.

Usage: python verify_book.py /path/to/book.pdf [--log /path/to/main.log]
Requires pypdf and pdfplumber. Does not read answer-bearing bank files.
"""
import argparse
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from pypdf import PdfReader
import pdfplumber

ROOT=Path(__file__).resolve().parent

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('pdf',type=Path)
    parser.add_argument('--log',type=Path)
    parser.add_argument('--output',type=Path,default=ROOT/'pdf_verification.json')
    args=parser.parse_args()
    prompts=json.loads((ROOT/'source/model_prompts.json').read_text())
    audit=json.loads((ROOT/'conversion_audit.json').read_text())
    expected=[p['prompt_id'] for p in prompts]
    assert len(expected)==len(set(expected))==480
    assert audit['problems']==480 and audit['families']==96 and audit['constructions']==24
    for name,expected_hash in audit['source_files'].items():
        assert digest(ROOT/'source'/name)==expected_hash,name
    for a,p in zip(audit['problems_index'],prompts,strict=True):
        assert a['prompt_id']==p['prompt_id']
        assert a['prompt_sha256']==hashlib.sha256(p['prompt'].encode()).hexdigest()
        data=json.JSONDecoder().raw_decode(p['prompt'].split('Data (zero-based indices; I denotes the imaginary unit when present):\n',1)[1])[0]
        assert a['input_data_sha256']==hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
        for unit in a['rendered_input_units']:
            val=data
            for k in unit['path']: val=val[k]
            assert val==unit['value']
    reader=PdfReader(args.pdf)
    identifiers=[]; page_map=[]; urls=[]; fonts={}
    for n,page in enumerate(reader.pages,1):
        text=page.extract_text()
        found=re.findall(r'IMR-S3-[A-Z]{3}-\d\d/(?:canonical|T1|T2_after_T1|T2|paraphrase)',text)
        assert len(found)<=1,(n,found)
        identifiers.extend(found)
        if found:
            nums=re.findall(r'Problem\s+(\d{3})',text);assert len(nums)==1,(n,nums)
            assert 'Requested quantities' in text and 'Exact data' in text
            page_map.append({'pdf_page':n,'problem':int(nums[0]),'prompt_id':found[0]})
        assert '<exact expression>' not in text and '\ufffd' not in text
        for annot in page.get('/Annots',[]):
            a=annot.get_object().get('/A',{})
            if a.get('/S')=='/URI': urls.append(str(a['/URI']))
        for obj in page['/Resources'].get('/Font',{}).values():
            font=obj.get_object();name=str(font.get('/BaseFont'))
            desc=font.get('/FontDescriptor')
            if desc:
                desc=desc.get_object();embedded=any(k in desc for k in ('/FontFile','/FontFile2','/FontFile3'))
            else: embedded=False
            fonts[name]={'subtype':str(font['/Subtype']),'embedded':embedded}
    assert identifiers==expected
    assert [p['problem'] for p in page_map]==list(range(1,481))
    assert all(v['embedded'] for v in fonts.values()),fonts
    assert 'https://doi.org/10.1016/0550-3213(86)90155-0' in urls
    assert not any(u.endswith('(86') for u in urls)
    def flatten(x):
        for y in x:
            if isinstance(y,list): yield from flatten(y)
            else: yield y
    outline=list(flatten(reader.outline))
    problem_bookmarks=[x for x in outline if str(x.title).startswith('Problem ')]
    assert len(problem_bookmarks)==480
    assert [reader.get_destination_page_number(b)+1 for b in problem_bookmarks]==[p['pdf_page'] for p in page_map]
    outside=[]; chars=0; page_geometry=[]
    with pdfplumber.open(args.pdf) as pdf:
        for n,page in enumerate(pdf.pages,1):
            c=page.chars;chars+=len(c)
            for ch in c:
                if ch['x0'] < -0.5 or ch['x1'] > page.width+0.5 or ch['top'] < -0.5 or ch['bottom'] > page.height+0.5:
                    outside.append({'page':n,'text':ch['text']})
            page_geometry.append({'page':n,'characters':len(c),'min_x':min(x['x0'] for x in c),'max_x':max(x['x1'] for x in c),'min_top':min(x['top'] for x in c),'max_bottom':max(x['bottom'] for x in c)})
            page.close()
    assert not outside,outside
    log_checks=None
    if args.log:
        text=args.log.read_text()
        problems=re.findall(r'^.*(?:Overfull|Underfull|Missing character|LaTeX Warning|Package .* Warning|^!).*$',text,re.M)
        assert not problems,problems
        assert 'Output written on' in text
        log_checks={'sha256':digest(args.log),'overflow_warnings':0,'missing_character_warnings':0,'latex_errors':0,'latex_warnings':0}
    report={'pdf':args.pdf.name,'pdf_sha256':digest(args.pdf),'pdf_bytes':args.pdf.stat().st_size,
        'pages':len(reader.pages),'families':96,'constructions':24,'problems':480,
        'presentation_counts':dict(Counter(i.rsplit('/',1)[1] for i in identifiers)),
        'exact_source_identifier_sequence':True,'one_complete_problem_per_page':True,
        'input_scalar_leaves_accounted_for':audit['input_scalar_leaves'],
        'all_480_problem_bookmarks_target_correct_pages':True,'total_bookmarks':len(outline),
        'all_fonts_embedded':True,'fonts':fonts,'external_reference_links':len(urls),
        'characters_checked':chars,'characters_outside_page':outside,'latex_log':log_checks,
        'page_map':page_map,'page_geometry':page_geometry,
        'scope':'Structural and transcription checks; not a new scientific validation or empirical calibration.'}
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('page_map','page_geometry','fonts')},indent=2))

if __name__=='__main__': main()
