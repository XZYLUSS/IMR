#!/usr/bin/env python3
"""Build a problem-only LaTeX edition from public prompts, never from gold files."""
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
import sympy as s
from statements import STATEMENTS, OBSERVATION, OUTPUT_KEYS

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
DEST = ROOT / 'sections'
DEST.mkdir(exist_ok=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def esc(text):
    return ''.join({'&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_',
                    '{':r'\{','}':r'\}','~':r'\textasciitilde{}',
                    '^':r'\textasciicircum{}','\\':r'\textbackslash{}'}.get(c,c) for c in str(text))

def expr(x):
    return s.sympify(x, locals={'I':s.I})

def latex(x):
    return s.latex(expr(x), imaginary_unit=r'\mathrm{i}', order='lex')

def mat(x):
    assert isinstance(x,list) and all(isinstance(row,list) for row in x)
    assert len(set(map(len,x)))==1
    return r'\begin{pmatrix}'+r'\\'.join(' & '.join(latex(v) for v in row) for row in x)+r'\end{pmatrix}'

def eq(*parts):
    return '\\[\n'+r'\qquad '.join(parts)+'\n\\]\n'

def polynomial(name, x, max_terms=4):
    e=expr(x)
    terms=e.as_ordered_terms()
    chunks=[terms[i:i+max_terms] for i in range(0,len(terms),max_terms)]
    if len(chunks)==1:
        return eq(name+'='+latex(e))
    out=[]
    for i,c in enumerate(chunks):
        part=latex(s.Add(*c))
        if i and not part.startswith('-'): part='+ '+part
        out.append((name+'&=' if i==0 else r'&\quad ')+part)
    return eq(r'\begin{aligned}'+r'\\[3pt]'.join(out)+r'\end{aligned}')

def leaf_paths(x,path=()):
    if isinstance(x,dict):
        return set().union(*(leaf_paths(v,path+(k,)) for k,v in x.items())) if x else set()
    if isinstance(x,list):
        return set().union(*(leaf_paths(v,path+(i,)) for i,v in enumerate(x))) if x else set()
    return {path}

def schema_paths(x,path=''):
    if isinstance(x,dict):
        return set().union(*(schema_paths(v,f'{path}.{k}' if path else k) for k,v in x.items()))
    return {path}

class InputData:
    def __init__(self,data):
        self.data=data; self.used=set(); self.units=[]
    def get(self,*path):
        obj=self.data
        for p in path: obj=obj[p]
        leaves=leaf_paths(obj,path)
        assert not leaves & self.used, ('input rendered twice',path)
        self.used |= leaves
        self.units.append({'path':list(path),'value':obj})
        return obj
    def finish(self):
        assert self.used==leaf_paths(self.data), ('unrendered data',leaf_paths(self.data)-self.used)
        return len(self.used)

def render_data(kind,data):
    d=InputData(data)
    X=d.get('X')
    def c(name): return d.get('context',name)
    if kind in ('RBG','LAT'):
        out=eq('X='+mat(X),'j='+mat(c('source')))
    elif kind=='GBS':
        mode=c('mode'); out=eq('X='+mat(X),'j='+mat(c('source')))
        out+=OBSERVATION[mode]+'\n'
        if mode=='conditional': out+=eq('v_h='+mat(c('fixed_hidden')))
        if mode in ('restriction','pushforward'): out+=eq('M='+mat(c('map')))
    elif kind=='PFQ': out=eq('X='+mat(X))
    elif kind=='DRC': out=eq('X='+mat(X))+eq('C='+mat(c('C')))
    elif kind=='HDV': out=polynomial('L',X,3)
    elif kind=='RIC':
        t=s.Symbol('t'); V=sum(expr(v)*t**i for i,v in enumerate(X))
        assert [s.expand(V).coeff(t,i) for i in range(5)]==[expr(v) for v in X]
        out=eq('V(t)='+latex(V),r'\alpha='+latex(c('initial')))
    elif kind=='DYS':
        out=''.join(eq(*[f'A_{i}='+mat(X[i]) for i in pair]) for pair in [(0,1),(2,3)])
    elif kind=='IMP':
        r=s.Symbol('r'); phi=r+sum(expr(v[0])*r**(i+2) for i,v in enumerate(X))
        assert [s.expand(phi).coeff(r,i+2) for i in range(5)]==[expr(v[0]) for v in X]
        out=polynomial(r'\phi(r)',phi)
    elif kind=='DST': out=polynomial('P(t)',X)
    elif kind=='RGJ': out=polynomial(r'\beta(g)',X)
    elif kind=='ANM':
        out=eq(r'\begin{array}{c|rrrr}\text{species}&\chi&d&q_1&q_2\\\hline '+r'\\[2pt]'.join(str(i)+' & '+' & '.join(latex(v) for v in row) for i,row in enumerate(X))+r'\end{array}')
    elif kind=='MOY': out=polynomial('f(x,y)',X)+polynomial('b(x,y)',c('right_symbol'))
    elif kind=='CON': out=polynomial(r'\phi(x,y,z)',X)+eq(r'\eta='+mat(c('metric')))
    elif kind=='ADM': out=eq('K='+mat(X))+eq(r'\gamma='+mat(c('metric')))
    elif kind=='HOD': out=eq('F='+mat(X))+eq(r'\eta='+mat(c('metric')),r'\epsilon_{0123}='+latex(c('orientation')))
    elif kind=='KCS': out=eq('K='+mat(X),'t='+mat(c('charge')),r'\ell='+mat(c('anyon')))
    elif kind=='YMC': out=eq('A_0='+mat(X[0]),'A_1='+mat(X[1]))
    elif kind=='QIN': out=eq('W='+mat(X))
    elif kind=='LDB':
        out=eq('A='+mat(X),'c='+mat(c('forcing')),'H='+mat(c('H')))
        jumps=c('jumps')
        out+=r'The rate--operator pairs $(\gamma_a,L_a)$ are:'+'\n'
        out+=r'\begingroup\setlength{\arraycolsep}{4pt}'+'\n'
        for i in range(0,len(jumps),2):
            out+=eq(*[r'\gamma_{'+str(j)+r'}='+latex(jumps[j][0])+r',\quad L_{'+str(j)+'}='+mat(jumps[j][1]) for j in range(i,min(i+2,len(jumps)))])
        out+=r'\endgroup'+'\n'
    elif kind=='OUC': out=eq('N='+mat(X),'B='+mat(c('drift')))
    elif kind=='ISM':
        spins=c('spins'); assert len(spins)==len(X)==8
        out=eq(r'\begin{array}{rrr|r}s_0&s_1&s_2&w(s)\\\hline '+r'\\[2pt]'.join(' & '.join(latex(v) for v in (*spins[i],X[i])) for i in range(8))+r'\end{array}')
    elif kind=='NAR':
        assert set(X)=={'B','metric'}
        out=eq('G='+mat(X['metric']),'B='+mat(X['B']),'q='+mat(c('charge')))
    elif kind=='SFT': out=eq(r'\Psi='+mat(X),'D='+mat(c('D')))+eq('V='+mat(d.get('driver')))
    else: raise ValueError(kind)
    count=d.finish()
    return out,count,d.units

PREAMBLE = r'''\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{newtxtext,newtxmath}
\usepackage[a4paper,left=20mm,right=20mm,top=19mm,bottom=20mm,headheight=14pt,headsep=7mm,footskip=11mm]{geometry}
\usepackage{amsmath,mathtools,booktabs,array}
\usepackage[most]{tcolorbox}
\usepackage{microtype,fancyhdr,enumitem,etoolbox}
\usepackage{titlesec,tocloft,needspace}
\usepackage[colorlinks=true,linkcolor=ink,urlcolor=accent,bookmarksopen=false,pdfborder={0 0 0}]{hyperref}
\usepackage{bookmark}
\definecolor{ink}{HTML}{183343}
\definecolor{accent}{HTML}{197B83}
\definecolor{mist}{HTML}{F3F7F8}
\definecolor{rulegray}{HTML}{CAD6DB}
\hypersetup{pdftitle={IMR: 96 Families, 480 Problems},pdfauthor={IMR problem-bank edition},pdfsubject={Complete natural-language problem statements; semantic bank v3}}
\pdfstringdefDisableCommands{\def\quad{ }\def\enspace{ }}
\setlength{\parindent}{0pt}
\setlength{\parskip}{6pt}
\setlength{\abovedisplayskip}{9pt}
\setlength{\belowdisplayskip}{9pt}
\setlength{\emergencystretch}{2em}
\renewcommand{\arraystretch}{1.18}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small\sffamily\color{ink}IMR\enspace /\enspace 96 FAMILIES}
\fancyhead[R]{\small\sffamily\color{ink}PROBLEM STATEMENTS}
\fancyfoot[L]{\footnotesize\sffamily\color{ink}Semantic bank v3\enspace\textbullet\enspace Problem-only edition}
\fancyfoot[R]{\small\sffamily\thepage}
\renewcommand{\headrulewidth}{0.3pt}
\renewcommand{\footrulewidth}{0pt}
\setcounter{tocdepth}{2}
\setlength{\cftbeforesecskip}{9pt}
\setlength{\cftbeforesubsecskip}{2pt}
\renewcommand{\cftsecfont}{\sffamily\bfseries\small}
\renewcommand{\cftsubsecfont}{\small}
\renewcommand{\cftsubsecpagefont}{\small}
\renewcommand{\cftsecpagefont}{\sffamily\bfseries\small}
\setlength{\cftsubsecindent}{1em}
\titleformat{\section}{\Large\sffamily\bfseries\color{ink}}{}{0pt}{}
\newtcolorbox{problemBox}[1]{enhanced,breakable,colback=white,colframe=rulegray,
 colbacktitle=ink,coltitle=white,fonttitle=\sffamily\bfseries,
 title={#1},boxrule=0.6pt,arc=2mm,left=4mm,right=4mm,top=3mm,bottom=3mm,
 before skip=8pt,after skip=6pt,pad at break*=2mm}
\newcommand{\blocktitle}[1]{\par\smallskip{\sffamily\bfseries\color{ink}#1}\par\smallskip}
\newcommand{\problemheading}[4]{%
 {\small\sffamily\color{accent}CONSTRUCTION #1\quad /\quad #2}\par
 {\Large\sffamily\bfseries\color{ink}#3}\par
 {\normalsize\sffamily #4}\par\vspace{2pt}}
\begin{document}
\pagenumbering{roman}
\begin{titlepage}
\thispagestyle{empty}
\vspace*{17mm}
{\large\sffamily\bfseries\color{accent}IMR\quad /\quad SEMANTIC BANK V3}\par
\vspace{15mm}
{\fontsize{36}{41}\selectfont\sffamily\bfseries\color{ink}96 Families\\[5pt]480 Problems}\par
\vspace{9mm}
{\Large Mathematical and theoretical physics}\par
\vspace{9mm}
\begin{tcolorbox}[colback=mist,colframe=rulegray,boxrule=.6pt,arc=2mm,left=6mm,right=6mm,top=6mm,bottom=6mm]
{\large\sffamily\bfseries Complete problem-statement edition}\par\medskip
24 constructions\quad $\times$\quad 4 families\quad $\times$\quad 5 presentations\par
Natural-language statements, exact input data, and typeset mathematics.
\end{tcolorbox}
\vfill
Canonical\quad\textbullet\quad $T_1$\quad\textbullet\quad $T_2$\quad\textbullet\quad $T_2\circ T_1$\quad\textbullet\quad Paraphrase\par
\vspace{8mm}
{\sffamily 17 October 2026}\par
{\small Source: frozen IMR semantic bank v3. This edition contains problem statements only.}
\end{titlepage}
\section*{Reading this edition}
\addcontentsline{toc}{section}{Reading this edition}
This volume contains every public problem in the IMR 96-family semantic bank: 24 mathematical constructions, four named families per construction, and five complete presentations per family. Problems are numbered consecutively from 001 to 480. Each begins on its own page; its bank identifier is printed above the statement.

\textbf{The five presentations.} Canonical gives the base instance. $T_1$ and $T_2$ give two independently transformed instances, and $T_2\circ T_1$ applies $T_1$ first, then $T_2$. Their full data are printed separately. These transformations change mathematical inputs; they are not merely changes of notation. The paraphrase retains the canonical data and requests while changing the order of exposition. It is retained as a separate problem. Thus 480 presentations correspond to 384 distinct mathematical input specifications.

\textbf{Conventions.} Indices begin at zero unless explicitly stated otherwise. All displayed integers, fractions and polynomial coefficients are exact. The symbol $i$ denotes the imaginary unit; $I_n$ denotes the $n\times n$ identity. A superscript $\mathsf T$ denotes transpose and $\dagger$ denotes Hermitian adjoint. Matrix entries are ordered by rows, and vectors are columns. Repeated tensor indices are summed where tensor notation is used. Every requested matrix, coefficient column and scalar is part of the problem.

\textbf{Reading and answering.} The JSON syntax and serialization requirements of the machine-facing bank have been replaced by natural-language requests and mathematical notation. Give exact answers; decimal approximations do not replace exact rational or polynomial expressions. All local data, sign conventions, truncation orders and requested quantities are retained. No solution, answer transport, evaluator certificate or gold answer is reproduced here.

\textbf{Organization and references.} The contents and PDF bookmarks navigate by construction and family; each problem also has a bookmark. References at the end provide background for the constructions. The displayed definitions fix the convention used by each problem. Family names describe the base regime and remain the same across its transformed presentations.

\textbf{Scope.} This is a readable edition of the existing finite, symbolic problem bank. It does not assert that the problems are the hardest possible in their fields, or that the expanded bank has been empirically calibrated. Models of a physical mechanism are not claims to solve the full underlying field theory.

\clearpage
\tableofcontents
\clearpage
\pagenumbering{arabic}
'''

SLOTS=[('canonical','Canonical'),('T1',r'$T_1$'),('T2',r'$T_2$'),('T2_after_T1',r'$T_2\circ T_1$'),('paraphrase','Paraphrase')]

def main():
    prompts=json.loads((SOURCE/'model_prompts.json').read_text())
    families=json.loads((SOURCE/'FAMILY_INDEX.json').read_text())
    assert len(prompts)==480 and len(families)==96
    byid={p['prompt_id']:p for p in prompts}; assert len(byid)==480
    kinds=list(dict.fromkeys(f['cluster'] for f in families)); assert len(kinds)==24
    assert set(kinds)==set(STATEMENTS)==set(OUTPUT_KEYS)
    audit=[]; main=[PREAMBLE]; n=0
    for ki,kind in enumerate(kinds,1):
        section=[]; fams=[f for f in families if f['cluster']==kind]; assert len(fams)==4
        construction=fams[0]['title'].split(' / ')[0]
        for fi,family in enumerate(fams,1):
            fid=family['family_id']; regime=family['title'].split(' / ')[1]
            regime=regime[0].upper()+regime[1:]
            for old,new in [('robin','Robin'),('majorana','Majorana'),('euclidean','Euclidean'),('lorentzian','Lorentzian'),('jordan','Jordan')]:
                regime=re.sub(r'\b'+old+r'\b',new,regime,flags=re.I)
            for si,(slot,label) in enumerate(SLOTS,1):
                n+=1; pid=f'{fid}/{slot}'; prompt=byid[pid]['prompt']
                data=json.JSONDecoder().raw_decode(prompt.split('Data (zero-based indices; I denotes the imaginary unit when present):\n',1)[1])[0]
                schema=json.loads(prompt.split('Matrices are arrays of rows; columns have one entry per row.\n',1)[1])
                expected=set(OUTPUT_KEYS[kind])
                if kind=='GBS':
                    mode=data['context']['mode']
                    if mode=='marginal': expected.add('observables.hidden_determinant')
                    if mode=='restriction': expected.add('observables.induced_measure_factor_squared')
                assert expected==schema_paths(schema),(pid,expected^schema_paths(schema))
                rendered,leaf_count,units=render_data(kind,data)
                setup,request=STATEMENTS[kind]
                body=[]
                if n>1: body.append(r'\clearpage')
                if fi==1 and si==1:
                    body.append(r'\addtocontents{toc}{\protect\needspace{90pt}}')
                    body.append(r'\phantomsection\addcontentsline{toc}{section}{'+f'{ki:02d}'+r'\quad '+esc(construction)+'}')
                if si==1:
                    body.append(r'\phantomsection\addcontentsline{toc}{subsection}{'+esc(fid)+r'\quad '+esc(regime)+'}')
                body.append(r'\hypertarget{p'+str(n)+r'}{}\bookmark[level=3,dest=p'+str(n)+']{Problem '+f'{n:03d}: '+slot.replace('_',' ')+r'}')
                body.append(r'\problemheading{'+f'{ki:02d}'+'}{'+esc(kind)+'}{'+esc(construction)+'}{'+f'Family {fi:02d}'+r'\enspace /\enspace '+esc(regime)+'}')
                body.append(r'{\footnotesize\ttfamily '+esc(pid)+'}'+r'\hfill{\footnotesize\sffamily Presentation '+str(si)+' of 5}')
                body.append(r'\begin{problemBox}{Problem '+f'{n:03d}'+r'\hfill '+label+'}')
                if slot=='paraphrase':
                    body.extend([r'\blocktitle{Requested quantities}',request,r'\blocktitle{Defining setup}',setup])
                else:
                    body.extend([r'\blocktitle{Setup}',setup,r'\blocktitle{Requested quantities}',request])
                body.extend([r'\blocktitle{Exact data}',rendered,r'\end{problemBox}'])
                refs=family['reference_ids']+(['FERMION'] if kind=='PFQ' else [])
                body.append(r'{\footnotesize\sffamily\color{ink}Background: '+', '.join(r'\hyperlink{ref-'+x+'}{['+x+']}' for x in refs)+'.}')
                chunk='\n'.join(body)+'\n'
                section.append(chunk)
                audit.append({'number':n,'prompt_id':pid,'cluster':kind,'family':fid,'presentation':slot,
                    'prompt_sha256':sha(prompt.encode()),'input_data_sha256':sha(json.dumps(data,sort_keys=True).encode()),
                    'rendered_tex_sha256':sha(chunk.encode()),'input_scalar_leaves':leaf_count,
                    'rendered_input_units':units,'covered_output_fields':sorted(expected),
                    'public_output_schema':schema})
        fn=f'{ki:02d}-{kind}.tex'; (DEST/fn).write_text(''.join(section))
        main.append(r'\input{sections/'+fn+'}\n')
    # Reuse the bank's actual bibliographic entries, with no evaluator/proof content.
    refs=[]
    for line in (SOURCE/'REFERENCES.md').read_text().splitlines():
        if not line.startswith('| ') or line.startswith('| ID '): continue
        cols=line.split('|'); key=cols[1].strip(); source=cols[2].strip()
        if key not in {'DYN','STAT','QFT','GAUGE','GR','SFTSTAT','DLMF23','DLMF27','HARVEY','MOYAL','WEN','PRESKILL','LINDBLAD','KIRITSIS','WITTEN','FERMION','HENNEAUX','OU'}: continue
        tokens={}
        def link(m):
            token=f'LINKTOKEN{len(tokens)}X';tokens[token]=r'\href{'+m[2]+'}{'+esc(m[1].replace('*',''))+'}';return token
        source=re.sub(r'\[([^\]]+)\]\(((?:[^()]|\([^()]*\))*)\)',link,source)
        source=esc(source)
        source=re.sub(r'\*\*([^*]+)\*\*',r'\\textbf{\1}',source)
        source=re.sub(r'\*([^*]+)\*',r'\\emph{\1}',source)
        source=source.replace('“','``').replace('”',"''").replace('–','--').replace('§',r'\S{}')
        for token,linktext in tokens.items(): source=source.replace(token,linktext)
        source=source.replace('§',r'\S{}')
        refs.append(r'\hypertarget{ref-'+key+r'}{}\item[\textsf{['+key+']}] '+source)
    assert len(refs)==18
    main.append(r'''\clearpage
\section*{Background references}
\addcontentsline{toc}{section}{Background references}
These sources support the background concepts. The problem statements themselves specify the finite systems, normalizations, signatures and conventions used in this edition. Bibliographic entries are reproduced from the frozen bank's reference record; no difficulty ranking or empirical result is attributed to them.
\begin{description}[style=nextline,leftmargin=19mm,labelwidth=17mm,itemsep=7pt,font=\small]
\small
'''+ '\n'.join(refs)+r'\end{description}\end{document}'+'\n')
    (ROOT/'main.tex').write_text(''.join(main))
    assert n==480 and set(a['prompt_id'] for a in audit)==set(byid)
    counts=Counter(a['presentation'] for a in audit);assert set(counts.values())=={96}
    report={'source_files':{p.name:sha(p.read_bytes()) for p in SOURCE.iterdir() if p.is_file()},
        'families':len(families),'constructions':len(kinds),'problems':n,'presentation_counts':dict(counts),
        'input_scalar_leaves':sum(a['input_scalar_leaves'] for a in audit),
        'all_public_input_leaves_consumed':True,'all_requested_output_fields_covered':True,
        'solution_data_loaded':False,'conversion':'Natural-language LaTeX transcription; serialization syntax omitted; mathematical inputs preserved.',
        'problems_index':audit}
    (ROOT/'conversion_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='problems_index'},indent=2))

if __name__=='__main__': main()
