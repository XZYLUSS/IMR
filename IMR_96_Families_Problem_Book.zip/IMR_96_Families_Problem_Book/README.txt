IMR: 96 Families, 480 Problems
Natural-language LaTeX edition of IMR semantic bank v3
17 October 2026

CONTENTS
main.tex                 Main LaTeX document
sections/                24 construction files; all 480 complete problems
source/model_prompts.json  Frozen public inputs, with no gold answers
source/FAMILY_INDEX.json   Frozen family metadata
source/REFERENCES.md       Original background-reference record
statements.py            Natural-language mathematical task templates
build_book.py            Regenerates the TeX sections from public inputs
verify_book.py           Checks coverage, PDF identifiers, bookmarks and bounds
conversion_audit.json    Per-problem provenance and input/output-field coverage
pdf_verification.json    Verification of the delivered PDF and visual-review scope
source_preservation.json Hash check of all 608 frozen bank manifest members
pdflatex_build.log       Successful final pdfLaTeX build log

COMPILE
The already-generated TeX files require no Python to compile.
In this directory, run three times:
    pdflatex -interaction=nonstopmode -halt-on-error main.tex
Use a full TeX Live or MiKTeX installation with the packages in the preamble.
The delivered PDF was produced using pdfLaTeX / TeX Live 2024.
The optional Codex editor preview compiler timed out downloading dependencies;
this did not affect the successful installed-LaTeX build or the delivered PDF.

REGENERATE (optional)
Python 3 and SymPy 1.14.0:
    python build_book.py
Then compile main.tex as above.

VERIFY (optional)
Python 3, pypdf and pdfplumber:
    python verify_book.py main.pdf --log main.log
This checks structure and transcription coverage, not empirical difficulty.

EDITION POLICY
24 constructions x 4 families x 5 presentations = 480 numbered problems.
Every complete statement occupies its own page. The final PDF has 486 pages:
one cover, one reading guide, three contents pages, 480 problem pages and one
reference page. Problem pages are numbered 1-480; references are page 481.
Each family has canonical, T1, T2, T2_after_T1 and paraphrase presentations.
Paraphrases retain canonical inputs. There are 384 distinct input specifications.

Machine JSON formatting was replaced with natural-language mathematical requests.
No solutions, answer transports, symbolic certificates, or gold answers are in
this edition. All exact data, local conventions and requested quantities are
retained. Bibliographic entries are reproduced from the frozen bank.
The frozen source bank was not modified.
